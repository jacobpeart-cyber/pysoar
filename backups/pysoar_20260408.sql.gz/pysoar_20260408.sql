--
-- PostgreSQL database dump
--

\restrict wv5J7uNvAbqllU1xbqZl7dr9TTlZ2HgOrgquutl7oYbGaKHF6FjpcZ3BOMUFv9v

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: anomalytypeenum; Type: TYPE; Schema: public; Owner: pysoar
--

CREATE TYPE public.anomalytypeenum AS ENUM (
    'UNUSUAL_VOLUME',
    'UNUSUAL_PAYLOAD_SIZE',
    'UNUSUAL_ERROR_RATE',
    'UNUSUAL_SOURCE',
    'UNUSUAL_TIME',
    'SCHEMA_VIOLATION',
    'ENUMERATION_ATTEMPT',
    'CREDENTIAL_STUFFING',
    'DATA_SCRAPING',
    'PARAMETER_TAMPERING'
);


ALTER TYPE public.anomalytypeenum OWNER TO pysoar;

--
-- Name: authenticationtypeenum; Type: TYPE; Schema: public; Owner: pysoar
--

CREATE TYPE public.authenticationtypeenum AS ENUM (
    'NONE',
    'API_KEY',
    'OAUTH2',
    'JWT',
    'BASIC',
    'MTLS',
    'CUSTOM'
);


ALTER TYPE public.authenticationtypeenum OWNER TO pysoar;

--
-- Name: compliancechecktypeenum; Type: TYPE; Schema: public; Owner: pysoar
--

CREATE TYPE public.compliancechecktypeenum AS ENUM (
    'OWASP_API_TOP10',
    'OPENAPI_VALIDATION',
    'AUTHENTICATION_CHECK',
    'AUTHORIZATION_CHECK',
    'RATE_LIMIT_CHECK',
    'TLS_CHECK',
    'HEADER_CHECK',
    'PII_EXPOSURE_CHECK',
    'LOGGING_CHECK',
    'VERSIONING_CHECK'
);


ALTER TYPE public.compliancechecktypeenum OWNER TO pysoar;

--
-- Name: policytypeenum; Type: TYPE; Schema: public; Owner: pysoar
--

CREATE TYPE public.policytypeenum AS ENUM (
    'AUTHENTICATION',
    'RATE_LIMITING',
    'INPUT_VALIDATION',
    'OUTPUT_FILTERING',
    'CORS',
    'TLS_VERSION',
    'HEADER_SECURITY',
    'SCHEMA_VALIDATION',
    'SIZE_LIMIT',
    'IP_ALLOWLIST'
);


ALTER TYPE public.policytypeenum OWNER TO pysoar;

--
-- Name: vulnerabilitytypeenum; Type: TYPE; Schema: public; Owner: pysoar
--

CREATE TYPE public.vulnerabilitytypeenum AS ENUM (
    'BOLA',
    'BROKEN_AUTH',
    'EXCESSIVE_DATA_EXPOSURE',
    'LACK_OF_RESOURCES_RATE_LIMITING',
    'BROKEN_FUNCTION_LEVEL_AUTH',
    'MASS_ASSIGNMENT',
    'SECURITY_MISCONFIGURATION',
    'INJECTION',
    'IMPROPER_ASSETS_MANAGEMENT',
    'INSUFFICIENT_LOGGING'
);


ALTER TYPE public.vulnerabilitytypeenum OWNER TO pysoar;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_anomalies; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.access_anomalies (
    organization_id character varying(36) NOT NULL,
    identity_id character varying(36) NOT NULL,
    anomaly_type character varying(50) NOT NULL,
    baseline_data json,
    observed_data json,
    deviation_score double precision NOT NULL,
    is_reviewed boolean NOT NULL,
    reviewer_notes text,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.access_anomalies OWNER TO pysoar;

--
-- Name: access_decisions; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.access_decisions (
    policy_id character varying(36),
    subject_type character varying(50) NOT NULL,
    subject_id character varying(255) NOT NULL,
    resource_type character varying(50) NOT NULL,
    resource_id character varying(255) NOT NULL,
    decision character varying(20) NOT NULL,
    risk_score double precision NOT NULL,
    risk_factors text NOT NULL,
    context text NOT NULL,
    authentication_method character varying(50),
    mfa_completed boolean NOT NULL,
    device_trust_score double precision,
    session_id character varying(255),
    decision_reason text NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.access_decisions OWNER TO pysoar;

--
-- Name: action_items; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.action_items (
    organization_id character varying(36) NOT NULL,
    room_id character varying(36) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    assigned_to character varying(36),
    assigned_by character varying(36) NOT NULL,
    priority character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    due_date timestamp with time zone,
    completed_at timestamp with time zone,
    linked_alert_id character varying(36),
    linked_incident_id character varying(36),
    notes text,
    checklist text,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.action_items OWNER TO pysoar;

--
-- Name: adversary_profiles; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.adversary_profiles (
    name character varying(255) NOT NULL,
    description text,
    threat_actor_ref character varying(36),
    sophistication character varying(50) NOT NULL,
    attack_chain json NOT NULL,
    objectives json NOT NULL,
    ttps json NOT NULL,
    target_sectors json NOT NULL,
    tools_used json NOT NULL,
    is_builtin boolean NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.adversary_profiles OWNER TO pysoar;

--
-- Name: COLUMN adversary_profiles.sophistication; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.adversary_profiles.sophistication IS 'script_kiddie, intermediate, advanced, apt';


--
-- Name: COLUMN adversary_profiles.attack_chain; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.adversary_profiles.attack_chain IS 'ordered technique IDs representing their typical attack flow';


--
-- Name: COLUMN adversary_profiles.objectives; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.adversary_profiles.objectives IS 'attack objectives (e.g., data exfiltration, disruption)';


--
-- Name: COLUMN adversary_profiles.ttps; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.adversary_profiles.ttps IS 'MITRE technique IDs';


--
-- Name: agent_actions; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.agent_actions (
    investigation_id character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL,
    action_type character varying(50) NOT NULL,
    target character varying(255) NOT NULL,
    parameters json,
    requires_approval boolean NOT NULL,
    approved_by character varying(36),
    approval_timestamp character varying(50),
    execution_status character varying(50) NOT NULL,
    result json,
    rollback_available boolean NOT NULL,
    rollback_executed boolean NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.agent_actions OWNER TO pysoar;

--
-- Name: agent_memories; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.agent_memories (
    agent_id character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL,
    memory_type character varying(50) NOT NULL,
    key character varying(255) NOT NULL,
    value json,
    confidence double precision NOT NULL,
    access_count integer NOT NULL,
    last_accessed character varying(50),
    decay_rate double precision NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.agent_memories OWNER TO pysoar;

--
-- Name: ai_analyses; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.ai_analyses (
    analysis_type character varying(50) NOT NULL,
    source_type character varying(50) NOT NULL,
    source_id character varying(36),
    input_data json NOT NULL,
    prompt_used text,
    ai_response text NOT NULL,
    structured_output json NOT NULL,
    confidence double precision NOT NULL,
    model_used character varying(100) NOT NULL,
    tokens_used integer NOT NULL,
    latency_ms integer NOT NULL,
    feedback_score integer,
    feedback_notes text,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_analyses OWNER TO pysoar;

--
-- Name: COLUMN ai_analyses.analysis_type; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.ai_analyses.analysis_type IS 'alert_triage, incident_summary, threat_assessment, response_recommendation, playbook_generation, root_cause, impact_analysis, natural_language_query';


--
-- Name: COLUMN ai_analyses.source_type; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.ai_analyses.source_type IS 'alert, incident, hunt_finding, log_pattern, query';


--
-- Name: COLUMN ai_analyses.model_used; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.ai_analyses.model_used IS 'gpt-4, claude, local-llm, ensemble';


--
-- Name: alerts; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.alerts (
    title character varying(500) NOT NULL,
    description text,
    severity character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    source character varying(100) NOT NULL,
    source_id character varying(255),
    source_url text,
    alert_type character varying(100),
    category character varying(100),
    tags text,
    priority integer NOT NULL,
    confidence integer NOT NULL,
    raw_data text,
    enrichment_data text,
    source_ip character varying(45),
    destination_ip character varying(45),
    hostname character varying(255),
    username character varying(255),
    file_hash character varying(128),
    url text,
    domain character varying(255),
    assigned_to character varying(36),
    incident_id character varying(36),
    resolution_notes text,
    resolved_at character varying(50),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.alerts OWNER TO pysoar;

--
-- Name: anomaly_detections; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.anomaly_detections (
    model_id character varying(36) NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id character varying(255) NOT NULL,
    anomaly_type character varying(100) NOT NULL,
    anomaly_score double precision NOT NULL,
    confidence double precision NOT NULL,
    severity character varying(20) NOT NULL,
    features json NOT NULL,
    baseline json NOT NULL,
    deviation json NOT NULL,
    description text NOT NULL,
    is_confirmed boolean,
    is_false_positive boolean NOT NULL,
    related_alerts json NOT NULL,
    mitre_techniques json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.anomaly_detections OWNER TO pysoar;

--
-- Name: COLUMN anomaly_detections.entity_type; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.anomaly_detections.entity_type IS 'user, host, network, process, application';


--
-- Name: COLUMN anomaly_detections.anomaly_type; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.anomaly_detections.anomaly_type IS 'behavioral, statistical, temporal, volumetric, structural';


--
-- Name: COLUMN anomaly_detections.severity; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.anomaly_detections.severity IS 'critical, high, medium, low, info';


--
-- Name: COLUMN anomaly_detections.features; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.anomaly_detections.features IS 'feature values that triggered the anomaly';


--
-- Name: COLUMN anomaly_detections.baseline; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.anomaly_detections.baseline IS 'expected normal values';


--
-- Name: COLUMN anomaly_detections.deviation; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.anomaly_detections.deviation IS 'how far from normal';


--
-- Name: COLUMN anomaly_detections.description; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.anomaly_detections.description IS 'AI-generated explanation';


--
-- Name: api_anomaly_detection; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.api_anomaly_detection (
    endpoint_id character varying(36) NOT NULL,
    anomaly_type public.anomalytypeenum NOT NULL,
    baseline_value double precision NOT NULL,
    observed_value double precision NOT NULL,
    deviation_percentage double precision NOT NULL,
    severity character varying(20) NOT NULL,
    source_ips json NOT NULL,
    sample_requests json NOT NULL,
    status character varying(50) NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.api_anomaly_detection OWNER TO pysoar;

--
-- Name: api_compliance_checks; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.api_compliance_checks (
    endpoint_id character varying(36) NOT NULL,
    check_type public.compliancechecktypeenum NOT NULL,
    passed boolean NOT NULL,
    details json NOT NULL,
    last_checked timestamp with time zone NOT NULL,
    remediation_steps text,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.api_compliance_checks OWNER TO pysoar;

--
-- Name: api_endpoint_inventory; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.api_endpoint_inventory (
    service_name character varying(255) NOT NULL,
    base_url character varying(512) NOT NULL,
    path character varying(512) NOT NULL,
    method character varying(10) NOT NULL,
    api_version character varying(50),
    authentication_type public.authenticationtypeenum NOT NULL,
    authorization_model character varying(255),
    data_classification character varying(50) NOT NULL,
    is_public boolean NOT NULL,
    is_documented boolean NOT NULL,
    is_shadow boolean NOT NULL,
    is_deprecated boolean NOT NULL,
    rate_limit_configured boolean NOT NULL,
    input_validation_enabled boolean NOT NULL,
    response_encryption boolean NOT NULL,
    last_seen timestamp with time zone NOT NULL,
    request_count_24h integer NOT NULL,
    error_rate double precision NOT NULL,
    owner_team character varying(255),
    openapi_spec_url character varying(512),
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.api_endpoint_inventory OWNER TO pysoar;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.api_keys (
    name character varying(255) NOT NULL,
    description text,
    key_prefix character varying(8) NOT NULL,
    key_hash character varying(255) NOT NULL,
    permissions text,
    allowed_ips text,
    rate_limit integer NOT NULL,
    is_active boolean NOT NULL,
    expires_at character varying(50),
    last_used_at character varying(50),
    last_used_ip character varying(45),
    usage_count integer NOT NULL,
    owner_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.api_keys OWNER TO pysoar;

--
-- Name: api_security_policies; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.api_security_policies (
    name character varying(255) NOT NULL,
    description text,
    policy_type public.policytypeenum NOT NULL,
    rules json NOT NULL,
    enforcement_level character varying(50) NOT NULL,
    applies_to json NOT NULL,
    violations_count integer NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.api_security_policies OWNER TO pysoar;

--
-- Name: api_vulnerabilities; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.api_vulnerabilities (
    endpoint_id character varying(36) NOT NULL,
    vulnerability_type public.vulnerabilitytypeenum NOT NULL,
    severity character varying(20) NOT NULL,
    description text NOT NULL,
    evidence json NOT NULL,
    remediation text,
    status character varying(50) NOT NULL,
    cwe_id character varying(50),
    detected_by character varying(255),
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.api_vulnerabilities OWNER TO pysoar;

--
-- Name: asset_vulnerabilities; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.asset_vulnerabilities (
    asset_id character varying(36) NOT NULL,
    vulnerability_id character varying(36) NOT NULL,
    status character varying(50) NOT NULL,
    detected_at timestamp with time zone NOT NULL,
    remediated_at timestamp with time zone,
    due_date timestamp with time zone,
    assigned_to character varying(255),
    remediation_notes text,
    compensating_controls json NOT NULL,
    risk_score double precision NOT NULL,
    exploitability_score double precision NOT NULL,
    impact_score double precision NOT NULL,
    detected_by character varying(255),
    scan_reference character varying(255),
    verification_status character varying(50) NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.asset_vulnerabilities OWNER TO pysoar;

--
-- Name: assets; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.assets (
    name character varying(255) NOT NULL,
    hostname character varying(255),
    asset_type character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    ip_address character varying(45),
    mac_address character varying(17),
    fqdn character varying(255),
    criticality character varying(50) NOT NULL,
    business_unit character varying(255),
    department character varying(255),
    owner character varying(255),
    location character varying(255),
    operating_system character varying(255),
    os_version character varying(100),
    installed_software text,
    open_ports text,
    services text,
    cloud_provider character varying(50),
    cloud_region character varying(100),
    cloud_instance_id character varying(255),
    security_score integer,
    vulnerabilities text,
    compliance_status text,
    last_scan character varying(50),
    description text,
    tags text,
    custom_fields text,
    is_monitored boolean NOT NULL,
    agent_installed boolean NOT NULL,
    last_seen character varying(50),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.assets OWNER TO pysoar;

--
-- Name: attack_simulations; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.attack_simulations (
    name character varying(255) NOT NULL,
    description text,
    simulation_type character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    target_environment character varying(100) NOT NULL,
    scope json NOT NULL,
    mitre_tactics json NOT NULL,
    mitre_techniques json NOT NULL,
    scheduled_at timestamp without time zone,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    duration_seconds integer,
    total_tests integer NOT NULL,
    passed_tests integer NOT NULL,
    failed_tests integer NOT NULL,
    blocked_tests integer NOT NULL,
    detection_rate double precision,
    overall_score double precision,
    created_by character varying(36) NOT NULL,
    approved_by character varying(36),
    tags json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.attack_simulations OWNER TO pysoar;

--
-- Name: COLUMN attack_simulations.simulation_type; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.attack_simulations.simulation_type IS 'atomic_test, attack_chain, adversary_emulation, purple_team, continuous_validation';


--
-- Name: COLUMN attack_simulations.status; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.attack_simulations.status IS 'draft, scheduled, running, paused, completed, failed, cancelled';


--
-- Name: COLUMN attack_simulations.target_environment; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.attack_simulations.target_environment IS 'production, staging, lab, isolated';


--
-- Name: COLUMN attack_simulations.detection_rate; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.attack_simulations.detection_rate IS 'blocked / total * 100';


--
-- Name: COLUMN attack_simulations.overall_score; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.attack_simulations.overall_score IS '0-100 security posture score';


--
-- Name: COLUMN attack_simulations.approved_by; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.attack_simulations.approved_by IS 'required for production simulations';


--
-- Name: attack_surfaces; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.attack_surfaces (
    name character varying(255) NOT NULL,
    surface_type character varying(50) NOT NULL,
    description text,
    total_assets integer NOT NULL,
    exposed_assets integer NOT NULL,
    critical_exposures integer NOT NULL,
    risk_score double precision NOT NULL,
    last_assessed_at timestamp with time zone,
    findings json NOT NULL,
    metrics json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.attack_surfaces OWNER TO pysoar;

--
-- Name: attack_techniques; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.attack_techniques (
    mitre_id character varying(20) NOT NULL,
    name character varying(255) NOT NULL,
    tactic character varying(100) NOT NULL,
    description text,
    platform json NOT NULL,
    test_commands json NOT NULL,
    detection_sources json NOT NULL,
    expected_detection text,
    risk_level character varying(20) NOT NULL,
    requires_privileges character varying(50) NOT NULL,
    is_safe boolean NOT NULL,
    is_enabled boolean NOT NULL,
    atomic_test_ref character varying(255),
    tags json NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.attack_techniques OWNER TO pysoar;

--
-- Name: COLUMN attack_techniques.platform; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.attack_techniques.platform IS 'windows, linux, macos, cloud, network';


--
-- Name: COLUMN attack_techniques.test_commands; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.attack_techniques.test_commands IS 'list of {platform, command, cleanup, executor}';


--
-- Name: COLUMN attack_techniques.detection_sources; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.attack_techniques.detection_sources IS 'where detection should trigger';


--
-- Name: COLUMN attack_techniques.expected_detection; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.attack_techniques.expected_detection IS 'what the SIEM rule should catch';


--
-- Name: COLUMN attack_techniques.risk_level; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.attack_techniques.risk_level IS 'low, medium, high, critical';


--
-- Name: COLUMN attack_techniques.requires_privileges; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.attack_techniques.requires_privileges IS 'user, admin, system, root';


--
-- Name: COLUMN attack_techniques.atomic_test_ref; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.attack_techniques.atomic_test_ref IS 'Atomic Red Team reference';


--
-- Name: attack_trees; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.attack_trees (
    organization_id character varying(36) NOT NULL,
    model_id character varying(36) NOT NULL,
    name character varying(500) NOT NULL,
    description text,
    root_goal text NOT NULL,
    tree_structure json,
    total_attack_paths integer NOT NULL,
    minimum_cost_path_usd integer,
    minimum_skill_path character varying(100),
    highest_probability_path text,
    generated_from_stride boolean NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.attack_trees OWNER TO pysoar;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.audit_logs (
    user_id character varying(36),
    action character varying(100) NOT NULL,
    resource_type character varying(100) NOT NULL,
    resource_id character varying(36),
    description text,
    old_value text,
    new_value text,
    ip_address character varying(45),
    user_agent text,
    request_id character varying(36),
    success boolean NOT NULL,
    error_message text,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO pysoar;

--
-- Name: audit_trails; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.audit_trails (
    event_type character varying(100) NOT NULL,
    action character varying(100) NOT NULL,
    actor_type character varying(50) NOT NULL,
    actor_id character varying(255) NOT NULL,
    actor_ip character varying(45),
    resource_type character varying(100) NOT NULL,
    resource_id character varying(255) NOT NULL,
    description text NOT NULL,
    old_value json,
    new_value json,
    result character varying(20) NOT NULL,
    risk_level character varying(20) NOT NULL,
    session_id character varying(255),
    request_id character varying(255),
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_trails OWNER TO pysoar;

--
-- Name: automated_evidence_rules; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.automated_evidence_rules (
    name character varying(255) NOT NULL,
    control_ids json NOT NULL,
    evidence_type character varying(50) NOT NULL,
    collection_method character varying(50) NOT NULL,
    collection_config json NOT NULL,
    schedule character varying(50) NOT NULL,
    is_enabled boolean NOT NULL,
    last_collected_at timestamp with time zone,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.automated_evidence_rules OWNER TO pysoar;

--
-- Name: automation_rules; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.automation_rules (
    name character varying(255) NOT NULL,
    description text,
    is_enabled boolean NOT NULL,
    trigger_type character varying(50) NOT NULL,
    trigger_conditions json,
    actions json,
    priority integer NOT NULL,
    cooldown_minutes integer NOT NULL,
    last_triggered_at timestamp with time zone,
    execution_count integer NOT NULL,
    created_by character varying(36),
    organization_id character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.automation_rules OWNER TO pysoar;

--
-- Name: behavior_baselines; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.behavior_baselines (
    entity_profile_id character varying(36) NOT NULL,
    behavior_type character varying(100) NOT NULL,
    baseline_period_days integer NOT NULL,
    statistical_model json NOT NULL,
    typical_values json NOT NULL,
    time_patterns json NOT NULL,
    peer_comparison json NOT NULL,
    confidence double precision NOT NULL,
    sample_count integer NOT NULL,
    last_updated_at timestamp without time zone NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.behavior_baselines OWNER TO pysoar;

--
-- Name: behavior_events; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.behavior_events (
    entity_profile_id character varying(36) NOT NULL,
    event_type character varying(100) NOT NULL,
    event_data json NOT NULL,
    source_ip character varying(45),
    destination character varying(255),
    geo_location json,
    device_info json,
    risk_contribution double precision NOT NULL,
    is_anomalous boolean NOT NULL,
    anomaly_reasons json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.behavior_events OWNER TO pysoar;

--
-- Name: business_impact_assessments; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.business_impact_assessments (
    organization_id character varying(36) NOT NULL,
    asset_name character varying(255) NOT NULL,
    asset_type character varying(50) NOT NULL,
    business_unit character varying(255) NOT NULL,
    criticality character varying(50) NOT NULL,
    rto_hours double precision NOT NULL,
    rpo_hours double precision NOT NULL,
    mtpd_hours double precision NOT NULL,
    financial_impact_per_hour_usd double precision NOT NULL,
    reputational_impact_score double precision NOT NULL,
    regulatory_impact_score double precision NOT NULL,
    dependencies text,
    single_point_of_failure boolean NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.business_impact_assessments OWNER TO pysoar;

--
-- Name: campaign_events; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.campaign_events (
    campaign_id character varying(36) NOT NULL,
    target_email character varying(255) NOT NULL,
    target_name character varying(255),
    event_type character varying(50) NOT NULL,
    event_timestamp timestamp without time zone NOT NULL,
    ip_address character varying(45),
    user_agent text,
    geo_location json,
    device_type character varying(50),
    time_to_action_seconds integer,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.campaign_events OWNER TO pysoar;

--
-- Name: case_attachments; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.case_attachments (
    filename character varying(255) NOT NULL,
    original_filename character varying(255) NOT NULL,
    file_path character varying(500) NOT NULL,
    file_size integer NOT NULL,
    mime_type character varying(100) NOT NULL,
    file_hash character varying(64),
    attachment_type character varying(50) NOT NULL,
    description text,
    is_malware boolean NOT NULL,
    is_encrypted boolean NOT NULL,
    incident_id character varying(36) NOT NULL,
    uploaded_by character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.case_attachments OWNER TO pysoar;

--
-- Name: case_notes; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.case_notes (
    content text NOT NULL,
    note_type character varying(50) NOT NULL,
    is_internal boolean NOT NULL,
    is_pinned boolean NOT NULL,
    incident_id character varying(36) NOT NULL,
    author_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.case_notes OWNER TO pysoar;

--
-- Name: case_tasks; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.case_tasks (
    title character varying(255) NOT NULL,
    description text,
    status character varying(50) NOT NULL,
    priority integer NOT NULL,
    due_date character varying(50),
    completed_at character varying(50),
    incident_id character varying(36) NOT NULL,
    assigned_to character varying(36),
    created_by character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.case_tasks OWNER TO pysoar;

--
-- Name: case_timeline; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.case_timeline (
    event_type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    old_value text,
    new_value text,
    event_metadata text,
    incident_id character varying(36) NOT NULL,
    actor_id character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.case_timeline OWNER TO pysoar;

--
-- Name: cisa_directives; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.cisa_directives (
    directive_id character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    directive_type character varying(50) NOT NULL,
    effective_date timestamp without time zone NOT NULL,
    compliance_deadline timestamp without time zone NOT NULL,
    status character varying(50) NOT NULL,
    requirements json NOT NULL,
    compliance_status character varying(50) NOT NULL,
    actions_taken json NOT NULL,
    evidence_ids json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.cisa_directives OWNER TO pysoar;

--
-- Name: compliance_assessments; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.compliance_assessments (
    framework_id character varying(36) NOT NULL,
    assessment_type character varying(50) NOT NULL,
    assessor character varying(255) NOT NULL,
    assessment_date timestamp without time zone NOT NULL,
    status character varying(50) NOT NULL,
    scope text,
    findings_count integer NOT NULL,
    satisfied_count integer NOT NULL,
    other_than_satisfied_count integer NOT NULL,
    overall_result character varying(50),
    report_path character varying(500),
    next_steps json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.compliance_assessments OWNER TO pysoar;

--
-- Name: compliance_controls; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.compliance_controls (
    framework_id character varying(36) NOT NULL,
    control_id character varying(50) NOT NULL,
    control_family character varying(100) NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    priority character varying(20) NOT NULL,
    baseline character varying(50),
    status character varying(50) NOT NULL,
    implementation_status double precision NOT NULL,
    implementation_details text,
    responsible_party character varying(255),
    assessment_method character varying(50) NOT NULL,
    assessment_frequency character varying(50) NOT NULL,
    last_assessed_at timestamp without time zone,
    last_assessment_result character varying(50),
    evidence_ids json NOT NULL,
    related_controls json NOT NULL,
    mitre_techniques json NOT NULL,
    automated_check_id character varying(255),
    risk_if_not_implemented character varying(20) NOT NULL,
    remediation_guidance text,
    poam_id character varying(36),
    tags json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.compliance_controls OWNER TO pysoar;

--
-- Name: compliance_evidence; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.compliance_evidence (
    control_id_ref character varying(36) NOT NULL,
    evidence_type character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    file_path character varying(500),
    file_hash character varying(128),
    content text,
    source_system character varying(255),
    collected_at timestamp without time zone NOT NULL,
    collected_by character varying(255) NOT NULL,
    is_automated boolean NOT NULL,
    is_valid boolean NOT NULL,
    expires_at timestamp without time zone,
    review_status character varying(50) NOT NULL,
    reviewed_by character varying(255),
    reviewed_at timestamp without time zone,
    tags json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.compliance_evidence OWNER TO pysoar;

--
-- Name: compliance_frameworks; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.compliance_frameworks (
    name character varying(255) NOT NULL,
    short_name character varying(50) NOT NULL,
    version character varying(50) NOT NULL,
    description text,
    authority character varying(255) NOT NULL,
    total_controls integer NOT NULL,
    implemented_controls integer NOT NULL,
    compliance_score double precision NOT NULL,
    status character varying(50) NOT NULL,
    last_assessment_at timestamp without time zone,
    next_assessment_due timestamp without time zone,
    certification_level character varying(100),
    is_enabled boolean NOT NULL,
    extra_metadata json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.compliance_frameworks OWNER TO pysoar;

--
-- Name: consent_records; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.consent_records (
    organization_id character varying(36) NOT NULL,
    subject_id character varying(255) NOT NULL,
    purpose character varying(255) NOT NULL,
    legal_basis character varying(50) NOT NULL,
    consent_given boolean NOT NULL,
    consent_date character varying(50),
    withdrawal_date character varying(50),
    consent_mechanism character varying(50) NOT NULL,
    evidence_location character varying(500),
    granularity text,
    version integer NOT NULL,
    privacy_policy_version character varying(50),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.consent_records OWNER TO pysoar;

--
-- Name: container_images; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.container_images (
    registry character varying(255) NOT NULL,
    repository character varying(255) NOT NULL,
    tag character varying(255) NOT NULL,
    digest_sha256 character varying(255) NOT NULL,
    image_size_mb double precision,
    os character varying(100),
    architecture character varying(50),
    created_at_source timestamp with time zone,
    scanned_at timestamp with time zone NOT NULL,
    vulnerability_count_critical integer NOT NULL,
    vulnerability_count_high integer NOT NULL,
    vulnerability_count_medium integer NOT NULL,
    vulnerability_count_low integer NOT NULL,
    is_signed boolean NOT NULL,
    signature_verified boolean NOT NULL,
    base_image character varying(255),
    sbom_generated boolean NOT NULL,
    compliance_status character varying(50) NOT NULL,
    risk_score integer NOT NULL,
    labels json NOT NULL,
    last_deployed timestamp with time zone,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.container_images OWNER TO pysoar;

--
-- Name: correlation_events; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.correlation_events (
    correlation_id character varying(100) NOT NULL,
    name character varying(500) NOT NULL,
    description text,
    severity character varying(50) NOT NULL,
    rule_id character varying(36),
    log_entry_ids text,
    source_addresses text,
    usernames text,
    hostnames text,
    timespan_start character varying(50) NOT NULL,
    timespan_end character varying(50) NOT NULL,
    event_count integer NOT NULL,
    mitre_tactics text,
    mitre_techniques text,
    alert_generated boolean NOT NULL,
    alert_id character varying(36),
    status character varying(50) NOT NULL,
    organization_id character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.correlation_events OWNER TO pysoar;

--
-- Name: credential_exposures; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.credential_exposures (
    organization_id character varying(36) NOT NULL,
    identity_id character varying(36) NOT NULL,
    exposure_source character varying(50) NOT NULL,
    credential_type character varying(50) NOT NULL,
    exposure_date character varying(50),
    discovery_date character varying(50),
    breach_name character varying(500),
    is_remediated boolean NOT NULL,
    remediation_date character varying(50),
    remediation_action character varying(500),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.credential_exposures OWNER TO pysoar;

--
-- Name: cui_markings; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.cui_markings (
    asset_id character varying(255) NOT NULL,
    asset_type character varying(50) NOT NULL,
    cui_category character varying(100) NOT NULL,
    cui_designation character varying(50) NOT NULL,
    dissemination_controls json NOT NULL,
    handling_instructions text,
    classification_authority character varying(255) NOT NULL,
    declassification_date timestamp without time zone,
    access_list json NOT NULL,
    is_active boolean NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.cui_markings OWNER TO pysoar;

--
-- Name: darkweb_brand_threats; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.darkweb_brand_threats (
    organization_id character varying(36) NOT NULL,
    finding_id character varying(36) NOT NULL,
    threat_type character varying(50) NOT NULL,
    target_brand character varying(255),
    target_domain character varying(255),
    malicious_domain character varying(255),
    registrar character varying(255),
    registration_date character varying(50),
    ssl_certificate_info json,
    takedown_status character varying(50) NOT NULL,
    takedown_provider character varying(255),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.darkweb_brand_threats OWNER TO pysoar;

--
-- Name: darkweb_credential_leaks; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.darkweb_credential_leaks (
    organization_id character varying(36) NOT NULL,
    finding_id character varying(36) NOT NULL,
    email character varying(255),
    username character varying(255),
    password_hash text,
    password_type character varying(50) NOT NULL,
    breach_source character varying(255),
    breach_date character varying(50),
    is_valid boolean NOT NULL,
    is_remediated boolean NOT NULL,
    remediation_action character varying(50),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.darkweb_credential_leaks OWNER TO pysoar;

--
-- Name: darkweb_findings; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.darkweb_findings (
    organization_id character varying(36) NOT NULL,
    monitor_id character varying(36) NOT NULL,
    finding_type character varying(50) NOT NULL,
    source_platform character varying(50) NOT NULL,
    source_url_hash character varying(128),
    title character varying(500),
    description text,
    raw_data_hash character varying(128),
    affected_assets json,
    affected_count integer NOT NULL,
    severity character varying(50) NOT NULL,
    confidence_score integer NOT NULL,
    status character varying(50) NOT NULL,
    discovered_date character varying(50),
    analyst_notes text,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.darkweb_findings OWNER TO pysoar;

--
-- Name: darkweb_monitors; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.darkweb_monitors (
    organization_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    monitor_type character varying(50) NOT NULL,
    search_terms json,
    domains_watched json,
    emails_watched json,
    enabled boolean NOT NULL,
    alert_severity character varying(50) NOT NULL,
    last_check character varying(50),
    findings_count integer NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.darkweb_monitors OWNER TO pysoar;

--
-- Name: data_classifications; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.data_classifications (
    organization_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    classification_level character varying(50) NOT NULL,
    description text,
    handling_rules text,
    retention_days integer,
    encryption_required boolean NOT NULL,
    dlp_policies text,
    auto_classification_rules text,
    color_code character varying(7),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.data_classifications OWNER TO pysoar;

--
-- Name: data_partitions; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.data_partitions (
    organization_id character varying(36) NOT NULL,
    source_id character varying(36) NOT NULL,
    partition_key character varying(255) NOT NULL,
    time_range_start character varying(50),
    time_range_end character varying(50),
    record_count integer NOT NULL,
    size_bytes integer NOT NULL,
    storage_tier character varying(50) NOT NULL,
    format character varying(50) NOT NULL,
    compression character varying(50) NOT NULL,
    location character varying(512) NOT NULL,
    is_indexed boolean NOT NULL,
    index_columns json,
    query_count_30d integer NOT NULL,
    last_accessed character varying(50),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.data_partitions OWNER TO pysoar;

--
-- Name: COLUMN data_partitions.partition_key; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.data_partitions.partition_key IS 'Partition identifier (e.g., source_siem_2024_03_21)';


--
-- Name: COLUMN data_partitions.time_range_start; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.data_partitions.time_range_start IS 'ISO timestamp start of data range';


--
-- Name: COLUMN data_partitions.time_range_end; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.data_partitions.time_range_end IS 'ISO timestamp end of data range';


--
-- Name: COLUMN data_partitions.location; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.data_partitions.location IS 'Storage path (S3, GCS, local path, etc.)';


--
-- Name: COLUMN data_partitions.index_columns; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.data_partitions.index_columns IS 'Columns with indexes for query optimization';


--
-- Name: COLUMN data_partitions.query_count_30d; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.data_partitions.query_count_30d IS 'Queries against this partition in last 30 days';


--
-- Name: COLUMN data_partitions.last_accessed; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.data_partitions.last_accessed IS 'ISO timestamp of last query';


--
-- Name: data_pipelines; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.data_pipelines (
    organization_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    pipeline_type character varying(50) NOT NULL,
    source_id character varying(36),
    destination character varying(255) NOT NULL,
    transform_rules json NOT NULL,
    schedule_cron character varying(100),
    status character varying(50) NOT NULL,
    last_run character varying(50),
    next_run character varying(50),
    avg_processing_time_ms integer NOT NULL,
    records_processed_total integer NOT NULL,
    error_count integer NOT NULL,
    last_error text,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.data_pipelines OWNER TO pysoar;

--
-- Name: COLUMN data_pipelines.destination; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.data_pipelines.destination IS 'Target system/data lake path';


--
-- Name: COLUMN data_pipelines.transform_rules; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.data_pipelines.transform_rules IS 'List of transformation operations with configs';


--
-- Name: COLUMN data_pipelines.schedule_cron; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.data_pipelines.schedule_cron IS 'Cron expression for scheduled execution';


--
-- Name: COLUMN data_pipelines.last_run; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.data_pipelines.last_run IS 'ISO timestamp of last execution';


--
-- Name: COLUMN data_pipelines.next_run; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.data_pipelines.next_run IS 'ISO timestamp of next scheduled execution';


--
-- Name: data_processing_records; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.data_processing_records (
    organization_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    purpose character varying(500) NOT NULL,
    legal_basis character varying(100) NOT NULL,
    data_categories text,
    data_subjects text,
    recipients text,
    cross_border_transfers text,
    retention_period_days integer,
    technical_measures text,
    organizational_measures text,
    dpo_contact character varying(255),
    processor_agreements text,
    last_reviewed character varying(50),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.data_processing_records OWNER TO pysoar;

--
-- Name: data_sources; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.data_sources (
    organization_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    source_type character varying(50) NOT NULL,
    description text,
    connection_config_encrypted json NOT NULL,
    ingestion_type character varying(50) NOT NULL,
    format character varying(50) NOT NULL,
    schema_definition json NOT NULL,
    normalization_mapping json NOT NULL,
    status character varying(50) NOT NULL,
    ingestion_rate_eps integer,
    total_events_ingested integer NOT NULL,
    storage_size_bytes integer NOT NULL,
    retention_days integer NOT NULL,
    last_event_received character varying(50),
    last_error text,
    is_enabled boolean NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.data_sources OWNER TO pysoar;

--
-- Name: COLUMN data_sources.connection_config_encrypted; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.data_sources.connection_config_encrypted IS 'Encrypted connection details (API keys, credentials, endpoints)';


--
-- Name: COLUMN data_sources.schema_definition; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.data_sources.schema_definition IS 'Field definitions and data types';


--
-- Name: COLUMN data_sources.normalization_mapping; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.data_sources.normalization_mapping IS 'Mapping to unified data model fields';


--
-- Name: COLUMN data_sources.ingestion_rate_eps; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.data_sources.ingestion_rate_eps IS 'Events per second ingestion rate';


--
-- Name: COLUMN data_sources.last_event_received; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.data_sources.last_event_received IS 'ISO timestamp of last event';


--
-- Name: data_subject_requests; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.data_subject_requests (
    organization_id character varying(36) NOT NULL,
    request_type character varying(50) NOT NULL,
    regulation character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    subject_name character varying(255) NOT NULL,
    subject_email character varying(255) NOT NULL,
    subject_identifier character varying(255),
    deadline character varying(50),
    response_sent character varying(50),
    data_systems_searched text,
    data_found text,
    denial_reason text,
    processing_notes text,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.data_subject_requests OWNER TO pysoar;

--
-- Name: deception_campaigns; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.deception_campaigns (
    name character varying(255) NOT NULL,
    description text,
    status character varying(50) NOT NULL,
    objective character varying(100) NOT NULL,
    decoy_ids json NOT NULL,
    coverage_zones json NOT NULL,
    total_interactions integer NOT NULL,
    unique_attackers integer NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    findings json NOT NULL,
    effectiveness_score double precision,
    created_by character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.deception_campaigns OWNER TO pysoar;

--
-- Name: decoy_interactions; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.decoy_interactions (
    decoy_id character varying(36) NOT NULL,
    interaction_type character varying(50) NOT NULL,
    source_ip character varying(45) NOT NULL,
    source_port integer,
    source_hostname character varying(255),
    source_user character varying(255),
    protocol character varying(50),
    credentials_captured json,
    commands_captured json NOT NULL,
    payloads_captured json NOT NULL,
    files_accessed json NOT NULL,
    session_duration_seconds integer,
    geo_location json,
    threat_assessment character varying(20) NOT NULL,
    is_automated_scan boolean NOT NULL,
    raw_traffic text,
    alert_generated boolean NOT NULL,
    alert_id character varying(36),
    mitre_techniques json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.decoy_interactions OWNER TO pysoar;

--
-- Name: decoys; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.decoys (
    name character varying(255) NOT NULL,
    decoy_type character varying(50) NOT NULL,
    category character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    deployment_target character varying(255),
    configuration json NOT NULL,
    emulated_service character varying(100),
    emulated_os character varying(100),
    ip_address character varying(45),
    hostname character varying(255),
    fidelity_level character varying(50) NOT NULL,
    interaction_count integer NOT NULL,
    last_interaction_at timestamp without time zone,
    alert_on_interaction boolean NOT NULL,
    capture_credentials boolean NOT NULL,
    capture_payloads boolean NOT NULL,
    deployed_at timestamp without time zone,
    deployed_by character varying(36),
    tags json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.decoys OWNER TO pysoar;

--
-- Name: detection_rules; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.detection_rules (
    name character varying(255) NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    author character varying(255),
    status character varying(50) NOT NULL,
    severity character varying(50) NOT NULL,
    log_types text,
    detection_logic text,
    condition character varying(500),
    timewindow integer,
    threshold integer,
    group_by text,
    mitre_tactics text,
    mitre_techniques text,
    tags text,
    false_positive_notes text,
    "references" text,
    rule_yaml text,
    enabled boolean NOT NULL,
    last_matched_at character varying(50),
    match_count bigint NOT NULL,
    organization_id character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.detection_rules OWNER TO pysoar;

--
-- Name: device_trust_profiles; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.device_trust_profiles (
    device_id character varying(255) NOT NULL,
    device_type character varying(50) NOT NULL,
    hostname character varying(255),
    os_type character varying(50),
    os_version character varying(100),
    trust_score double precision NOT NULL,
    trust_level character varying(20) NOT NULL,
    compliance_status text NOT NULL,
    last_patch_date timestamp with time zone,
    encryption_enabled boolean NOT NULL,
    antivirus_active boolean NOT NULL,
    firewall_enabled boolean NOT NULL,
    jailbroken boolean NOT NULL,
    certificate_valid boolean NOT NULL,
    last_seen_at timestamp with time zone,
    last_assessment_at timestamp with time zone,
    risk_factors text NOT NULL,
    owner_id character varying(255),
    enrolled_at timestamp with time zone,
    tags text NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.device_trust_profiles OWNER TO pysoar;

--
-- Name: dlp_incidents; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.dlp_incidents (
    organization_id character varying(36) NOT NULL,
    violation_ids text,
    incident_title character varying(255) NOT NULL,
    description text,
    severity character varying(20) NOT NULL,
    status character varying(50) NOT NULL,
    affected_data_subjects_count integer,
    data_types_involved text,
    regulatory_implications text,
    breach_notification_required boolean NOT NULL,
    notification_deadline timestamp with time zone,
    notification_sent timestamp with time zone,
    incident_commander character varying(255),
    remediation_steps text,
    lessons_learned text,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dlp_incidents OWNER TO pysoar;

--
-- Name: dlp_policies; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.dlp_policies (
    organization_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    policy_type character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    enabled boolean NOT NULL,
    data_patterns text,
    file_types_monitored text,
    channels_monitored text,
    response_actions text,
    exceptions text,
    last_triggered timestamp with time zone,
    trigger_count integer NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dlp_policies OWNER TO pysoar;

--
-- Name: dlp_violations; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.dlp_violations (
    organization_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL,
    violation_type character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    source_user character varying(255),
    source_device character varying(255),
    source_application character varying(255),
    destination character varying(255),
    data_classification character varying(50),
    sensitive_data_types text,
    file_name character varying(255),
    file_hash character varying(128),
    data_volume_bytes integer,
    action_taken character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    justification text,
    reviewed_by character varying(255),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dlp_violations OWNER TO pysoar;

--
-- Name: entity_profiles; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.entity_profiles (
    entity_type character varying(50) NOT NULL,
    entity_id character varying(255) NOT NULL,
    display_name character varying(255),
    department character varying(255),
    role character varying(255),
    manager character varying(255),
    peer_group character varying(255),
    risk_score double precision NOT NULL,
    risk_level character varying(20) NOT NULL,
    baseline_data json NOT NULL,
    current_behavior json NOT NULL,
    anomaly_count_30d integer NOT NULL,
    last_activity_at timestamp without time zone,
    last_anomaly_at timestamp without time zone,
    is_watched boolean NOT NULL,
    watch_reason text,
    tags json NOT NULL,
    extra_metadata json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.entity_profiles OWNER TO pysoar;

--
-- Name: evidence_packages; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.evidence_packages (
    name character varying(255) NOT NULL,
    description text,
    package_type character varying(50) NOT NULL,
    framework_id character varying(36),
    status character varying(50) NOT NULL,
    evidence_items json NOT NULL,
    control_mappings json NOT NULL,
    assessor character varying(255),
    due_date timestamp with time zone,
    submitted_at timestamp with time zone,
    package_hash character varying(128),
    extra_metadata json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.evidence_packages OWNER TO pysoar;

--
-- Name: exposure_assets; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.exposure_assets (
    hostname character varying(255),
    ip_address character varying(45),
    mac_address character varying(17),
    asset_type character varying(50) NOT NULL,
    os_type character varying(100),
    os_version character varying(100),
    environment character varying(50) NOT NULL,
    criticality character varying(20) NOT NULL,
    business_unit character varying(255),
    owner character varying(255),
    location character varying(255),
    cloud_provider character varying(50),
    cloud_region character varying(100),
    cloud_account_id character varying(255),
    cloud_resource_id character varying(500),
    is_internet_facing boolean NOT NULL,
    is_active boolean NOT NULL,
    last_seen timestamp with time zone,
    last_scan_at timestamp with time zone,
    services json NOT NULL,
    software_inventory json NOT NULL,
    tags json NOT NULL,
    risk_score double precision NOT NULL,
    vulnerability_count integer NOT NULL,
    open_ports json NOT NULL,
    network_zone character varying(100),
    compliance_status json NOT NULL,
    extra_metadata json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.exposure_assets OWNER TO pysoar;

--
-- Name: exposure_scans; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.exposure_scans (
    scan_type character varying(50) NOT NULL,
    scan_name character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    target_assets json NOT NULL,
    scanner character varying(100) NOT NULL,
    scan_profile character varying(255),
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    total_hosts integer NOT NULL,
    hosts_scanned integer NOT NULL,
    vulnerabilities_found integer NOT NULL,
    critical_count integer NOT NULL,
    high_count integer NOT NULL,
    medium_count integer NOT NULL,
    low_count integer NOT NULL,
    error_message text,
    results_summary json NOT NULL,
    initiated_by character varying(36),
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.exposure_scans OWNER TO pysoar;

--
-- Name: exposure_vulnerabilities; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.exposure_vulnerabilities (
    cve_id character varying(20),
    title character varying(500) NOT NULL,
    description text,
    severity character varying(20) NOT NULL,
    cvss_v3_score double precision,
    cvss_v3_vector character varying(100),
    cvss_v2_score double precision,
    epss_score double precision,
    epss_percentile double precision,
    is_exploited_in_wild boolean NOT NULL,
    exploit_available boolean NOT NULL,
    exploit_maturity character varying(50) NOT NULL,
    affected_products json NOT NULL,
    affected_versions json NOT NULL,
    patch_available boolean NOT NULL,
    patch_url text,
    vendor_advisory_url text,
    "references" json NOT NULL,
    mitre_techniques json NOT NULL,
    published_at timestamp with time zone,
    modified_at timestamp with time zone,
    tags json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.exposure_vulnerabilities OWNER TO pysoar;

--
-- Name: fair_analyses; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.fair_analyses (
    organization_id character varying(36) NOT NULL,
    scenario_id character varying(36) NOT NULL,
    tef_min double precision NOT NULL,
    tef_mode double precision NOT NULL,
    tef_max double precision NOT NULL,
    vuln_min double precision NOT NULL,
    vuln_mode double precision NOT NULL,
    vuln_max double precision NOT NULL,
    tcap_min double precision NOT NULL,
    tcap_mode double precision NOT NULL,
    tcap_max double precision NOT NULL,
    rs_min double precision NOT NULL,
    rs_mode double precision NOT NULL,
    rs_max double precision NOT NULL,
    lm_min double precision NOT NULL,
    lm_mode double precision NOT NULL,
    lm_max double precision NOT NULL,
    primary_loss_min double precision NOT NULL,
    primary_loss_mode double precision NOT NULL,
    primary_loss_max double precision NOT NULL,
    secondary_loss_min double precision NOT NULL,
    secondary_loss_mode double precision NOT NULL,
    secondary_loss_max double precision NOT NULL,
    secondary_loss_event_frequency double precision NOT NULL,
    simulation_iterations integer NOT NULL,
    ale_mean double precision,
    ale_p10 double precision,
    ale_p50 double precision,
    ale_p90 double precision,
    ale_p99 double precision,
    loss_exceedance_curve text,
    completed_at timestamp with time zone,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.fair_analyses OWNER TO pysoar;

--
-- Name: forensic_artifacts; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.forensic_artifacts (
    case_id character varying(36) NOT NULL,
    evidence_id character varying(36) NOT NULL,
    artifact_type character varying(100) NOT NULL,
    artifact_data json NOT NULL,
    analysis_notes text,
    ioc_extracted json NOT NULL,
    mitre_mapping text,
    risk_score double precision NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.forensic_artifacts OWNER TO pysoar;

--
-- Name: forensic_cases; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.forensic_cases (
    case_number character varying(100) NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    case_type character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    severity character varying(50) NOT NULL,
    lead_investigator_id character varying(36),
    assigned_team text,
    legal_hold_active boolean NOT NULL,
    chain_of_custody_hash character varying(255),
    classification_level character varying(50),
    court_admissible boolean NOT NULL,
    created_by character varying(255),
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.forensic_cases OWNER TO pysoar;

--
-- Name: forensic_evidence; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.forensic_evidence (
    case_id character varying(36) NOT NULL,
    evidence_type character varying(50) NOT NULL,
    source_device character varying(255) NOT NULL,
    source_ip character varying(50),
    acquisition_method character varying(50) NOT NULL,
    original_hash_md5 character varying(32),
    original_hash_sha256 character varying(64),
    chain_of_custody_log json NOT NULL,
    storage_location text NOT NULL,
    file_size_bytes integer,
    is_verified boolean NOT NULL,
    verified_by character varying(255),
    verification_date character varying(50),
    handling_notes text,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.forensic_evidence OWNER TO pysoar;

--
-- Name: forensic_timeline; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.forensic_timeline (
    case_id character varying(36) NOT NULL,
    event_timestamp character varying(50) NOT NULL,
    event_type character varying(100) NOT NULL,
    source character varying(255) NOT NULL,
    source_evidence_id character varying(36),
    description text,
    artifact_data json NOT NULL,
    mitre_technique_id character varying(50),
    severity_score double precision NOT NULL,
    is_pivotal boolean NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.forensic_timeline OWNER TO pysoar;

--
-- Name: honey_tokens; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.honey_tokens (
    name character varying(255) NOT NULL,
    token_type character varying(50) NOT NULL,
    token_value character varying(500) NOT NULL,
    token_hash character varying(64) NOT NULL,
    deployment_location character varying(500),
    deployment_context text,
    status character varying(50) NOT NULL,
    triggered_count integer NOT NULL,
    last_triggered_at timestamp without time zone,
    last_triggered_by character varying(255),
    expires_at timestamp without time zone,
    alert_severity character varying(20) NOT NULL,
    notification_channels json NOT NULL,
    deployed_by character varying(36),
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.honey_tokens OWNER TO pysoar;

--
-- Name: hunt_findings; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.hunt_findings (
    session_id character varying(36) NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    severity character varying(50) NOT NULL,
    classification character varying(50) NOT NULL,
    evidence json,
    affected_assets json,
    iocs_found json,
    mitre_techniques json,
    log_entry_ids json,
    analyst_notes text,
    escalated_to_case boolean NOT NULL,
    case_id character varying(36),
    created_by character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.hunt_findings OWNER TO pysoar;

--
-- Name: hunt_hypotheses; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.hunt_hypotheses (
    title character varying(500) NOT NULL,
    description text,
    status character varying(50) NOT NULL,
    priority character varying(50) NOT NULL,
    hunt_type character varying(100) NOT NULL,
    mitre_tactics json,
    mitre_techniques json,
    data_sources json,
    expected_evidence text,
    tags json,
    created_by character varying(36),
    assigned_to character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.hunt_hypotheses OWNER TO pysoar;

--
-- Name: hunt_notebooks; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.hunt_notebooks (
    session_id character varying(36) NOT NULL,
    title character varying(500) NOT NULL,
    content json,
    version integer NOT NULL,
    is_published boolean NOT NULL,
    published_at timestamp with time zone,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.hunt_notebooks OWNER TO pysoar;

--
-- Name: hunt_sessions; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.hunt_sessions (
    hypothesis_id character varying(36) NOT NULL,
    status character varying(50) NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    duration_seconds integer,
    query_count integer NOT NULL,
    events_analyzed integer NOT NULL,
    findings_count integer NOT NULL,
    queries_executed json,
    parameters json,
    error_message text,
    created_by character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.hunt_sessions OWNER TO pysoar;

--
-- Name: hunt_templates; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.hunt_templates (
    name character varying(500) NOT NULL,
    description text,
    category character varying(100),
    hunt_type character varying(100) NOT NULL,
    hypothesis_template text,
    default_queries json,
    mitre_tactics json,
    mitre_techniques json,
    data_sources_required json,
    estimated_duration_minutes integer,
    difficulty character varying(50) NOT NULL,
    tags json,
    is_builtin boolean NOT NULL,
    enabled boolean NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.hunt_templates OWNER TO pysoar;

--
-- Name: identified_threats; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.identified_threats (
    organization_id character varying(36) NOT NULL,
    model_id character varying(36) NOT NULL,
    component_id character varying(36),
    stride_category character varying(50),
    pasta_stage character varying(50),
    threat_description text NOT NULL,
    attack_vector text,
    preconditions text,
    impact_description text,
    likelihood character varying(50) NOT NULL,
    impact character varying(50) NOT NULL,
    risk_score integer NOT NULL,
    mitre_technique_ids json,
    cwe_ids json,
    status character varying(50) NOT NULL,
    priority integer NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.identified_threats OWNER TO pysoar;

--
-- Name: identity_profiles; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.identity_profiles (
    organization_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    username character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    display_name character varying(500),
    identity_provider character varying(50) NOT NULL,
    role_assignments json,
    group_memberships json,
    privilege_level character varying(50) NOT NULL,
    mfa_enabled boolean NOT NULL,
    mfa_methods json,
    last_authentication character varying(50),
    last_password_change character varying(50),
    authentication_methods json,
    is_service_account boolean NOT NULL,
    is_dormant boolean NOT NULL,
    risk_score double precision NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.identity_profiles OWNER TO pysoar;

--
-- Name: identity_threats; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.identity_threats (
    organization_id character varying(36) NOT NULL,
    identity_id character varying(36),
    threat_type character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    confidence_score double precision NOT NULL,
    source_ip character varying(45),
    source_location character varying(500),
    target_resource character varying(500),
    mitre_technique_id character varying(20),
    evidence json,
    status character varying(50) NOT NULL,
    response_actions json,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.identity_threats OWNER TO pysoar;

--
-- Name: identity_verifications; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.identity_verifications (
    user_id character varying(255) NOT NULL,
    verification_type character varying(50) NOT NULL,
    method character varying(50) NOT NULL,
    result character varying(20) NOT NULL,
    risk_score_before double precision NOT NULL,
    risk_score_after double precision NOT NULL,
    trigger_reason character varying(255),
    device_id character varying(255),
    source_ip character varying(45),
    geo_location text,
    session_id character varying(255),
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.identity_verifications OWNER TO pysoar;

--
-- Name: image_vulnerabilities; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.image_vulnerabilities (
    image_id character varying(36) NOT NULL,
    cve_id character varying(100) NOT NULL,
    package_name character varying(255) NOT NULL,
    package_version character varying(100) NOT NULL,
    fixed_version character varying(100),
    severity character varying(50) NOT NULL,
    cvss_score double precision,
    exploit_available boolean NOT NULL,
    description text,
    layer_introduced character varying(255),
    remediation text,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.image_vulnerabilities OWNER TO pysoar;

--
-- Name: incident_timeline; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.incident_timeline (
    organization_id character varying(36) NOT NULL,
    room_id character varying(36) NOT NULL,
    event_time timestamp with time zone NOT NULL,
    event_type character varying(50) NOT NULL,
    description text NOT NULL,
    created_by character varying(36) NOT NULL,
    evidence_ids text,
    is_key_event boolean NOT NULL,
    mitre_technique character varying(255),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.incident_timeline OWNER TO pysoar;

--
-- Name: incidents; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.incidents (
    title character varying(500) NOT NULL,
    description text,
    severity character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    incident_type character varying(100) NOT NULL,
    priority integer NOT NULL,
    impact text,
    affected_systems text,
    affected_users text,
    detected_at character varying(50),
    contained_at character varying(50),
    resolved_at character varying(50),
    assigned_to character varying(36),
    root_cause text,
    indicators text,
    evidence text,
    resolution text,
    lessons_learned text,
    recommendations text,
    external_id character varying(255),
    ticket_url text,
    tags text,
    mitre_tactics text,
    mitre_techniques text,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.incidents OWNER TO pysoar;

--
-- Name: indicator_sightings; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.indicator_sightings (
    indicator_id character varying(36) NOT NULL,
    source character varying(255) NOT NULL,
    source_ref character varying(255),
    sighting_type character varying(50) NOT NULL,
    context json NOT NULL,
    raw_data json,
    organization_id character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.indicator_sightings OWNER TO pysoar;

--
-- Name: installed_integrations; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.installed_integrations (
    organization_id character varying(36) NOT NULL,
    connector_id character varying(36) NOT NULL,
    display_name character varying(255) NOT NULL,
    config_encrypted text NOT NULL,
    auth_credentials_encrypted text NOT NULL,
    status character varying(50) NOT NULL,
    health_status character varying(50) NOT NULL,
    last_health_check character varying(50),
    last_successful_action character varying(50),
    error_message text,
    rate_limit_remaining integer,
    rate_limit_reset character varying(50),
    webhook_url text,
    webhook_secret_hash character varying(256),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.installed_integrations OWNER TO pysoar;

--
-- Name: integration_actions; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.integration_actions (
    connector_id character varying(36) NOT NULL,
    action_name character varying(255) NOT NULL,
    display_name character varying(255) NOT NULL,
    description text,
    action_type character varying(50) NOT NULL,
    input_schema text NOT NULL,
    output_schema text NOT NULL,
    requires_approval boolean NOT NULL,
    timeout_seconds integer NOT NULL,
    retry_policy text NOT NULL,
    is_idempotent boolean NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.integration_actions OWNER TO pysoar;

--
-- Name: integration_connectors; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.integration_connectors (
    name character varying(255) NOT NULL,
    display_name character varying(255) NOT NULL,
    description text,
    vendor character varying(255),
    category character varying(50) NOT NULL,
    version character varying(50) NOT NULL,
    icon_url text,
    documentation_url text,
    supported_actions text NOT NULL,
    supported_triggers text NOT NULL,
    auth_type character varying(50) NOT NULL,
    config_schema text NOT NULL,
    is_builtin boolean NOT NULL,
    is_community boolean NOT NULL,
    rating double precision,
    install_count integer NOT NULL,
    last_updated character varying(50),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.integration_connectors OWNER TO pysoar;

--
-- Name: integration_executions; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.integration_executions (
    organization_id character varying(36) NOT NULL,
    installed_id character varying(36) NOT NULL,
    action_id character varying(36) NOT NULL,
    triggered_by character varying(50) NOT NULL,
    playbook_run_id character varying(36),
    input_data text NOT NULL,
    output_data text,
    status character varying(50) NOT NULL,
    started_at character varying(50),
    completed_at character varying(50),
    duration_ms integer,
    error_message text,
    retry_count integer NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.integration_executions OWNER TO pysoar;

--
-- Name: intel_reports; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.intel_reports (
    title character varying(500) NOT NULL,
    report_type character varying(50) NOT NULL,
    tlp character varying(20) NOT NULL,
    severity character varying(20) NOT NULL,
    executive_summary text,
    detailed_analysis text,
    recommendations json NOT NULL,
    associated_actors json NOT NULL,
    associated_campaigns json NOT NULL,
    associated_indicators json NOT NULL,
    mitre_techniques json NOT NULL,
    affected_sectors json NOT NULL,
    affected_products json NOT NULL,
    "references" json NOT NULL,
    tags json NOT NULL,
    author_id character varying(36),
    status character varying(50) NOT NULL,
    published_at timestamp with time zone,
    organization_id character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.intel_reports OWNER TO pysoar;

--
-- Name: investigations; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.investigations (
    agent_id character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL,
    trigger_type character varying(50) NOT NULL,
    trigger_source_id character varying(255),
    title character varying(500) NOT NULL,
    hypothesis text,
    status character varying(50) NOT NULL,
    priority integer NOT NULL,
    confidence_score double precision NOT NULL,
    reasoning_chain json,
    evidence_collected json,
    actions_taken json,
    findings_summary text,
    recommendations json,
    mitre_techniques json,
    affected_assets json,
    resolution_type character varying(50),
    human_feedback text,
    feedback_rating integer,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.investigations OWNER TO pysoar;

--
-- Name: iocs; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.iocs (
    value character varying(2048) NOT NULL,
    ioc_type character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    threat_level character varying(50) NOT NULL,
    confidence integer NOT NULL,
    description text,
    tags text,
    category character varying(100),
    source character varying(255),
    source_url text,
    source_reference character varying(255),
    malware_family character varying(255),
    threat_actor character varying(255),
    campaign character varying(255),
    mitre_tactics text,
    mitre_techniques text,
    enrichment_data text,
    last_enriched character varying(50),
    first_seen character varying(50),
    last_seen character varying(50),
    expires_at character varying(50),
    sighting_count integer NOT NULL,
    last_sighting character varying(50),
    is_whitelisted boolean NOT NULL,
    is_internal boolean NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.iocs OWNER TO pysoar;

--
-- Name: k8s_security_findings; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.k8s_security_findings (
    cluster_id character varying(36) NOT NULL,
    finding_type character varying(100) NOT NULL,
    namespace character varying(255) NOT NULL,
    resource_type character varying(100) NOT NULL,
    resource_name character varying(255) NOT NULL,
    severity character varying(50) NOT NULL,
    description text NOT NULL,
    remediation text,
    cis_benchmark_id character varying(100),
    status character varying(50) NOT NULL,
    detected_at timestamp with time zone NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.k8s_security_findings OWNER TO pysoar;

--
-- Name: kubernetes_clusters; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.kubernetes_clusters (
    name character varying(255) NOT NULL,
    version character varying(50) NOT NULL,
    provider character varying(50) NOT NULL,
    endpoint character varying(255) NOT NULL,
    node_count integer NOT NULL,
    namespace_count integer NOT NULL,
    pod_count integer NOT NULL,
    rbac_enabled boolean NOT NULL,
    network_policy_enabled boolean NOT NULL,
    pod_security_standards character varying(50) NOT NULL,
    audit_logging_enabled boolean NOT NULL,
    encryption_at_rest boolean NOT NULL,
    secrets_encrypted boolean NOT NULL,
    admission_controllers json NOT NULL,
    last_audit timestamp with time zone,
    compliance_score integer NOT NULL,
    risk_score integer NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.kubernetes_clusters OWNER TO pysoar;

--
-- Name: legal_holds; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.legal_holds (
    case_id character varying(36) NOT NULL,
    hold_type character varying(50) NOT NULL,
    custodians json NOT NULL,
    data_sources json NOT NULL,
    issued_by character varying(255) NOT NULL,
    issued_date character varying(50) NOT NULL,
    expiry_date character varying(50),
    acknowledgments json NOT NULL,
    status character varying(50) NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.legal_holds OWNER TO pysoar;

--
-- Name: log_entries; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.log_entries (
    "timestamp" character varying(50) NOT NULL,
    received_at character varying(50) NOT NULL,
    source_type character varying(50) NOT NULL,
    source_name character varying(255) NOT NULL,
    source_ip character varying(45) NOT NULL,
    log_type character varying(50) NOT NULL,
    severity character varying(50) NOT NULL,
    raw_log text NOT NULL,
    parsed_fields text,
    normalized_fields text,
    message text,
    source_address character varying(45),
    destination_address character varying(45),
    source_port integer,
    destination_port integer,
    protocol character varying(50),
    username character varying(255),
    hostname character varying(255),
    process_name character varying(500),
    action character varying(100),
    outcome character varying(50),
    rule_matches text,
    tags text,
    organization_id character varying(36),
    partition_key character varying(10),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.log_entries OWNER TO pysoar;

--
-- Name: micro_segments; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.micro_segments (
    name character varying(255) NOT NULL,
    segment_type character varying(50) NOT NULL,
    description text,
    cidr_ranges text NOT NULL,
    allowed_protocols text NOT NULL,
    allowed_ports text NOT NULL,
    allowed_services text NOT NULL,
    ingress_policies text NOT NULL,
    egress_policies text NOT NULL,
    member_assets text NOT NULL,
    trust_level character varying(20) NOT NULL,
    is_active boolean NOT NULL,
    traffic_stats text NOT NULL,
    violation_count integer NOT NULL,
    last_violation_at timestamp with time zone,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.micro_segments OWNER TO pysoar;

--
-- Name: ml_models; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.ml_models (
    name character varying(255) NOT NULL,
    model_type character varying(50) NOT NULL,
    algorithm character varying(100) NOT NULL,
    version character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    description text,
    feature_columns json NOT NULL,
    hyperparameters json NOT NULL,
    training_metrics json NOT NULL,
    model_path character varying(500),
    training_data_size integer NOT NULL,
    last_trained_at timestamp with time zone,
    last_prediction_at timestamp with time zone,
    prediction_count integer NOT NULL,
    drift_score double precision NOT NULL,
    tags json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ml_models OWNER TO pysoar;

--
-- Name: COLUMN ml_models.model_type; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.ml_models.model_type IS 'anomaly_detection, classification, clustering, nlp, time_series, threat_scoring';


--
-- Name: COLUMN ml_models.algorithm; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.ml_models.algorithm IS 'isolation_forest, autoencoder, lstm, random_forest, xgboost, transformer, statistical';


--
-- Name: COLUMN ml_models.status; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.ml_models.status IS 'training, ready, deployed, retired, failed';


--
-- Name: COLUMN ml_models.training_metrics; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.ml_models.training_metrics IS 'accuracy, precision, recall, f1, auc';


--
-- Name: nl_queries; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.nl_queries (
    natural_language text NOT NULL,
    interpreted_intent character varying(100) NOT NULL,
    generated_query text NOT NULL,
    query_parameters json NOT NULL,
    results_summary text,
    result_count integer NOT NULL,
    execution_time_ms integer NOT NULL,
    user_id character varying(36) NOT NULL,
    was_helpful boolean,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.nl_queries OWNER TO pysoar;

--
-- Name: organization_members; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.organization_members (
    organization_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    role character varying(50) NOT NULL,
    is_primary boolean NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.organization_members OWNER TO pysoar;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.organizations (
    name character varying(255) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    email character varying(255),
    phone character varying(50),
    website character varying(255),
    address text,
    city character varying(100),
    country character varying(100),
    logo_url text,
    primary_color character varying(7),
    plan character varying(50) NOT NULL,
    max_users integer NOT NULL,
    max_alerts_per_month integer NOT NULL,
    max_storage_gb integer NOT NULL,
    settings text,
    is_active boolean NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.organizations OWNER TO pysoar;

--
-- Name: ot_alerts; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.ot_alerts (
    organization_id character varying(36) NOT NULL,
    asset_id character varying(36) NOT NULL,
    alert_type character varying(50) NOT NULL,
    severity character varying(50) NOT NULL,
    source_ip character varying(45),
    destination_ip character varying(45),
    protocol_used character varying(50),
    command_function_code character varying(100),
    description text NOT NULL,
    raw_data json NOT NULL,
    mitre_ics_technique character varying(100),
    status character varying(50) NOT NULL,
    response_action text,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ot_alerts OWNER TO pysoar;

--
-- Name: ot_assets; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.ot_assets (
    organization_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    asset_type character varying(50) NOT NULL,
    vendor character varying(255),
    model character varying(255),
    firmware_version character varying(100),
    protocol character varying(50),
    ip_address character varying(45),
    mac_address character varying(17),
    serial_number character varying(255),
    purdue_level character varying(50) NOT NULL,
    zone character varying(255),
    cell_area character varying(255),
    criticality character varying(50) NOT NULL,
    last_seen timestamp without time zone,
    is_online boolean NOT NULL,
    firmware_current boolean NOT NULL,
    known_vulnerabilities_count integer NOT NULL,
    risk_score double precision NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ot_assets OWNER TO pysoar;

--
-- Name: ot_incidents; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.ot_incidents (
    organization_id character varying(36) NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    affected_assets json NOT NULL,
    affected_zones json NOT NULL,
    incident_type character varying(50) NOT NULL,
    severity character varying(50) NOT NULL,
    physical_impact_risk character varying(50) NOT NULL,
    operational_impact character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    containment_strategy character varying(50),
    safe_shutdown_initiated boolean NOT NULL,
    detected_at timestamp without time zone NOT NULL,
    contained_at timestamp without time zone,
    resolved_at timestamp without time zone,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ot_incidents OWNER TO pysoar;

--
-- Name: ot_policy_rules; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.ot_policy_rules (
    organization_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    rule_type character varying(50) NOT NULL,
    purdue_levels_applied json NOT NULL,
    conditions json NOT NULL,
    enforcement_action character varying(50) NOT NULL,
    enabled boolean NOT NULL,
    violations_count integer NOT NULL,
    last_violation timestamp without time zone,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ot_policy_rules OWNER TO pysoar;

--
-- Name: ot_zones; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.ot_zones (
    organization_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    purdue_level character varying(50) NOT NULL,
    network_cidr character varying(50) NOT NULL,
    allowed_protocols json NOT NULL,
    allowed_communications json NOT NULL,
    assets_count integer NOT NULL,
    compliance_status character varying(50) NOT NULL,
    last_audit timestamp without time zone,
    firewall_rules json NOT NULL,
    segmentation_verified boolean NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ot_zones OWNER TO pysoar;

--
-- Name: patch_operations; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.patch_operations (
    vulnerability_instance_id character varying(36) NOT NULL,
    patch_type character varying(50) NOT NULL,
    patch_id character varying(255),
    patch_name character varying(500),
    deployment_status character varying(50) NOT NULL,
    deployment_date character varying(50),
    verification_date character varying(50),
    rollback_available boolean NOT NULL,
    change_ticket_id character varying(255),
    approved_by character varying(36),
    deployment_notes text,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.patch_operations OWNER TO pysoar;

--
-- Name: peer_groups; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.peer_groups (
    name character varying(255) NOT NULL,
    description text,
    group_type character varying(50) NOT NULL,
    member_count integer NOT NULL,
    baseline_data json NOT NULL,
    risk_threshold double precision NOT NULL,
    members json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.peer_groups OWNER TO pysoar;

--
-- Name: phishing_campaigns; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.phishing_campaigns (
    name character varying(255) NOT NULL,
    description text,
    campaign_type character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    template_id character varying(36),
    target_group_id character varying(36),
    send_schedule json NOT NULL,
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    total_targets integer NOT NULL,
    emails_sent integer NOT NULL,
    emails_opened integer NOT NULL,
    links_clicked integer NOT NULL,
    credentials_submitted integer NOT NULL,
    attachments_opened integer NOT NULL,
    reported_count integer NOT NULL,
    difficulty_level character varying(50) NOT NULL,
    created_by character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.phishing_campaigns OWNER TO pysoar;

--
-- Name: phishing_templates; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.phishing_templates (
    name character varying(255) NOT NULL,
    description text,
    category character varying(50) NOT NULL,
    difficulty character varying(50) NOT NULL,
    subject_line character varying(255) NOT NULL,
    sender_name character varying(255) NOT NULL,
    sender_email character varying(255) NOT NULL,
    html_body text NOT NULL,
    text_body text,
    landing_page_html text,
    has_attachment boolean NOT NULL,
    attachment_name character varying(255),
    indicators_of_phishing json NOT NULL,
    training_content_on_fail text,
    language character varying(10) NOT NULL,
    is_seasonal boolean NOT NULL,
    usage_count integer NOT NULL,
    average_click_rate double precision NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.phishing_templates OWNER TO pysoar;

--
-- Name: playbook_edges; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.playbook_edges (
    playbook_id character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL,
    source_node_id character varying(100) NOT NULL,
    target_node_id character varying(100) NOT NULL,
    edge_type character varying(50) NOT NULL,
    condition_expression text,
    label character varying(255),
    priority integer NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.playbook_edges OWNER TO pysoar;

--
-- Name: playbook_executions; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.playbook_executions (
    playbook_id character varying(36) NOT NULL,
    incident_id character varying(36),
    status character varying(50) NOT NULL,
    current_step integer NOT NULL,
    total_steps integer NOT NULL,
    started_at character varying(50),
    completed_at character varying(50),
    input_data text,
    output_data text,
    step_results text,
    error_message text,
    error_step integer,
    triggered_by character varying(36),
    trigger_source character varying(100),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.playbook_executions OWNER TO pysoar;

--
-- Name: playbook_node_executions; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.playbook_node_executions (
    execution_id character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL,
    node_id character varying(100) NOT NULL,
    status character varying(50) NOT NULL,
    started_at character varying(50),
    completed_at character varying(50),
    duration_ms integer,
    input_data text,
    output_data text,
    error_message text,
    retry_attempt integer NOT NULL,
    approved_by character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.playbook_node_executions OWNER TO pysoar;

--
-- Name: playbook_nodes; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.playbook_nodes (
    playbook_id character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL,
    node_id character varying(100) NOT NULL,
    node_type character varying(50) NOT NULL,
    display_name character varying(255) NOT NULL,
    description text,
    position_x double precision NOT NULL,
    position_y double precision NOT NULL,
    config text,
    input_schema text,
    output_schema text,
    timeout_seconds integer NOT NULL,
    retry_count integer NOT NULL,
    on_error character varying(50) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.playbook_nodes OWNER TO pysoar;

--
-- Name: playbooks; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.playbooks (
    name character varying(255) NOT NULL,
    description text,
    status character varying(50) NOT NULL,
    trigger_type character varying(50) NOT NULL,
    trigger_conditions text,
    steps text NOT NULL,
    variables text,
    version integer NOT NULL,
    category character varying(100),
    tags text,
    is_enabled boolean NOT NULL,
    timeout_seconds integer NOT NULL,
    max_retries integer NOT NULL,
    created_by character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.playbooks OWNER TO pysoar;

--
-- Name: poams; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.poams (
    control_id_ref character varying(36) NOT NULL,
    weakness_name character varying(500) NOT NULL,
    weakness_description text,
    weakness_source character varying(100) NOT NULL,
    risk_level character varying(20) NOT NULL,
    original_risk_rating double precision,
    residual_risk_rating double precision,
    status character varying(50) NOT NULL,
    milestone_changes json NOT NULL,
    scheduled_completion_date timestamp without time zone NOT NULL,
    actual_completion_date timestamp without time zone,
    milestones json NOT NULL,
    resources_required text,
    cost_estimate double precision,
    compensating_controls text,
    vendor_dependencies json NOT NULL,
    assigned_to character varying(255),
    approved_by character varying(255),
    comments json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.poams OWNER TO pysoar;

--
-- Name: privacy_impact_assessments; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.privacy_impact_assessments (
    organization_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    project_name character varying(255) NOT NULL,
    assessment_type character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    data_types_processed text,
    processing_purposes text,
    legal_basis character varying(100),
    data_subjects_affected integer,
    cross_border_transfers text,
    risk_level character varying(50) NOT NULL,
    mitigations text,
    dpo_review boolean NOT NULL,
    dpo_approval_date character varying(50),
    supervisory_authority_consulted boolean NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.privacy_impact_assessments OWNER TO pysoar;

--
-- Name: privacy_incidents; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.privacy_incidents (
    organization_id character varying(36) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    incident_type character varying(50) NOT NULL,
    severity character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    data_types_affected text,
    subjects_affected_count integer,
    regulations_implicated text,
    notification_required boolean NOT NULL,
    notification_deadline character varying(50),
    supervisory_authority_notified boolean NOT NULL,
    subjects_notified boolean NOT NULL,
    containment_actions text,
    root_cause text,
    remediation_steps text,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.privacy_incidents OWNER TO pysoar;

--
-- Name: privileged_access_events; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.privileged_access_events (
    organization_id character varying(36) NOT NULL,
    identity_id character varying(36) NOT NULL,
    event_type character varying(50) NOT NULL,
    target_resource character varying(500),
    justification text,
    approved_by character varying(255),
    approval_timestamp character varying(50),
    expiry_timestamp character varying(50),
    was_revoked boolean NOT NULL,
    revocation_reason character varying(500),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.privileged_access_events OWNER TO pysoar;

--
-- Name: query_jobs; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.query_jobs (
    organization_id character varying(36) NOT NULL,
    query_text text NOT NULL,
    query_language character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    data_sources_queried json NOT NULL,
    time_range_start character varying(50),
    time_range_end character varying(50),
    records_scanned integer NOT NULL,
    records_returned integer NOT NULL,
    execution_time_ms integer NOT NULL,
    result_location character varying(512),
    cost_estimate double precision,
    submitted_by character varying(36) NOT NULL,
    cached boolean NOT NULL,
    error_message text,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.query_jobs OWNER TO pysoar;

--
-- Name: COLUMN query_jobs.data_sources_queried; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.query_jobs.data_sources_queried IS 'IDs of data sources included in query';


--
-- Name: COLUMN query_jobs.time_range_start; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.query_jobs.time_range_start IS 'ISO timestamp query start';


--
-- Name: COLUMN query_jobs.time_range_end; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.query_jobs.time_range_end IS 'ISO timestamp query end';


--
-- Name: COLUMN query_jobs.result_location; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.query_jobs.result_location IS 'Path to query results (S3, GCS, etc.)';


--
-- Name: COLUMN query_jobs.cost_estimate; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.query_jobs.cost_estimate IS 'Estimated query cost in USD';


--
-- Name: COLUMN query_jobs.submitted_by; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.query_jobs.submitted_by IS 'User ID who submitted the query';


--
-- Name: COLUMN query_jobs.cached; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.query_jobs.cached IS 'Whether result was served from cache';


--
-- Name: reasoning_steps; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.reasoning_steps (
    investigation_id character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL,
    step_number integer NOT NULL,
    step_type character varying(50) NOT NULL,
    thought_process text,
    action_taken text,
    action_tool character varying(50),
    action_parameters json,
    observation text,
    confidence_delta double precision NOT NULL,
    duration_ms integer NOT NULL,
    tokens_used integer NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.reasoning_steps OWNER TO pysoar;

--
-- Name: remediation_actions; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.remediation_actions (
    name character varying(255) NOT NULL,
    description text,
    action_type character varying(50) NOT NULL,
    target_type character varying(50) NOT NULL,
    parameters json NOT NULL,
    integration character varying(100),
    integration_config json NOT NULL,
    timeout_seconds integer NOT NULL,
    retry_count integer NOT NULL,
    is_reversible boolean NOT NULL,
    reverse_action_type character varying(50),
    reverse_parameters json NOT NULL,
    risk_level character varying(20) NOT NULL,
    requires_confirmation boolean NOT NULL,
    tags json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.remediation_actions OWNER TO pysoar;

--
-- Name: COLUMN remediation_actions.action_type; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.remediation_actions.action_type IS 'firewall_block, host_isolate, account_disable, account_lock, password_reset, session_terminate, process_kill, file_quarantine, patch_deploy, config_change, dns_sinkhole, email_quarantine, token_revoke, webhook, script, notification, ticket_create';


--
-- Name: COLUMN remediation_actions.target_type; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.remediation_actions.target_type IS 'ip, host, user, process, file, domain, url, email, service, application';


--
-- Name: COLUMN remediation_actions.integration; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.remediation_actions.integration IS 'Which system executes: firewall, edr, ad, email_gateway, etc.';


--
-- Name: COLUMN remediation_actions.risk_level; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.remediation_actions.risk_level IS 'low, medium, high, critical';


--
-- Name: remediation_executions; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.remediation_executions (
    policy_id character varying(36),
    trigger_source character varying(50) NOT NULL,
    trigger_id character varying(36),
    trigger_details json NOT NULL,
    status character varying(50) NOT NULL,
    approval_status character varying(50),
    approved_by character varying(36),
    approved_at timestamp without time zone,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    target_entity character varying(255) NOT NULL,
    target_type character varying(50) NOT NULL,
    actions_planned json NOT NULL,
    actions_completed json NOT NULL,
    current_action_index integer NOT NULL,
    overall_result character varying(50),
    error_message text,
    rollback_status character varying(50),
    rolled_back_at timestamp without time zone,
    metrics json NOT NULL,
    notes text,
    created_by character varying(36),
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.remediation_executions OWNER TO pysoar;

--
-- Name: COLUMN remediation_executions.trigger_source; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.remediation_executions.trigger_source IS 'alert, anomaly, threat_intel, vulnerability, ueba, deception, manual, scheduled';


--
-- Name: COLUMN remediation_executions.status; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.remediation_executions.status IS 'pending, awaiting_approval, approved, running, completed, failed, rolled_back, cancelled, timed_out';


--
-- Name: COLUMN remediation_executions.approval_status; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.remediation_executions.approval_status IS 'pending, approved, rejected, auto_approved';


--
-- Name: COLUMN remediation_executions.overall_result; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.remediation_executions.overall_result IS 'success, partial_success, failure';


--
-- Name: COLUMN remediation_executions.rollback_status; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.remediation_executions.rollback_status IS 'pending, in_progress, completed, failed';


--
-- Name: remediation_integrations; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.remediation_integrations (
    name character varying(255) NOT NULL,
    integration_type character varying(50) NOT NULL,
    vendor character varying(255),
    endpoint_url text,
    auth_type character varying(50) NOT NULL,
    auth_config json NOT NULL,
    capabilities json NOT NULL,
    is_connected boolean NOT NULL,
    last_health_check timestamp without time zone,
    health_status character varying(50) NOT NULL,
    rate_limit integer NOT NULL,
    tags json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.remediation_integrations OWNER TO pysoar;

--
-- Name: COLUMN remediation_integrations.integration_type; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.remediation_integrations.integration_type IS 'firewall, edr, siem, email_gateway, active_directory, cloud_provider, ticketing, dns, waf, proxy, custom_api';


--
-- Name: COLUMN remediation_integrations.auth_type; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.remediation_integrations.auth_type IS 'api_key, oauth, basic, certificate, aws_iam';


--
-- Name: COLUMN remediation_integrations.auth_config; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.remediation_integrations.auth_config IS 'Encrypted reference to credentials';


--
-- Name: COLUMN remediation_integrations.capabilities; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.remediation_integrations.capabilities IS 'Actions this integration supports';


--
-- Name: COLUMN remediation_integrations.health_status; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.remediation_integrations.health_status IS 'unknown, healthy, degraded, unavailable';


--
-- Name: remediation_playbooks; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.remediation_playbooks (
    name character varying(255) NOT NULL,
    description text,
    playbook_type character varying(50) NOT NULL,
    trigger_conditions json NOT NULL,
    steps json NOT NULL,
    decision_points json NOT NULL,
    parallel_actions json NOT NULL,
    estimated_duration_minutes integer,
    is_template boolean NOT NULL,
    is_enabled boolean NOT NULL,
    success_count integer NOT NULL,
    failure_count integer NOT NULL,
    avg_execution_minutes double precision,
    tags json NOT NULL,
    created_by character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.remediation_playbooks OWNER TO pysoar;

--
-- Name: COLUMN remediation_playbooks.playbook_type; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.remediation_playbooks.playbook_type IS 'incident_response, vulnerability_remediation, compliance_fix, threat_containment, recovery';


--
-- Name: COLUMN remediation_playbooks.steps; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.remediation_playbooks.steps IS 'Ordered list of {action_id, conditions, on_success, on_failure, timeout}';


--
-- Name: COLUMN remediation_playbooks.decision_points; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.remediation_playbooks.decision_points IS 'Human decision gates';


--
-- Name: COLUMN remediation_playbooks.parallel_actions; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.remediation_playbooks.parallel_actions IS 'Actions that can run simultaneously';


--
-- Name: remediation_policies; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.remediation_policies (
    name character varying(255) NOT NULL,
    description text,
    policy_type character varying(50) NOT NULL,
    trigger_type character varying(50) NOT NULL,
    trigger_conditions json NOT NULL,
    actions json NOT NULL,
    is_enabled boolean NOT NULL,
    requires_approval boolean NOT NULL,
    approval_timeout_minutes integer NOT NULL,
    auto_approve_after_timeout boolean NOT NULL,
    cooldown_minutes integer NOT NULL,
    max_executions_per_hour integer NOT NULL,
    scope json NOT NULL,
    exclusions json NOT NULL,
    priority integer NOT NULL,
    risk_level character varying(20) NOT NULL,
    rollback_enabled boolean NOT NULL,
    rollback_actions json NOT NULL,
    execution_count integer NOT NULL,
    last_executed_at timestamp without time zone,
    success_rate double precision,
    tags json NOT NULL,
    created_by character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.remediation_policies OWNER TO pysoar;

--
-- Name: COLUMN remediation_policies.policy_type; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.remediation_policies.policy_type IS 'auto_block, auto_isolate, auto_patch, auto_disable, auto_quarantine, auto_reset, auto_revoke, escalation, notification, custom';


--
-- Name: COLUMN remediation_policies.trigger_type; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.remediation_policies.trigger_type IS 'alert_severity, anomaly_score, threat_intel_match, vulnerability_score, ueba_risk, deception_interaction, detection_rule, manual';


--
-- Name: COLUMN remediation_policies.risk_level; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.remediation_policies.risk_level IS 'low, medium, high, critical';


--
-- Name: remediation_tickets; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.remediation_tickets (
    title character varying(500) NOT NULL,
    description text,
    status character varying(50) NOT NULL,
    priority character varying(20) NOT NULL,
    assigned_to character varying(255),
    assigned_team character varying(255),
    asset_vulnerabilities json NOT NULL,
    affected_assets json NOT NULL,
    remediation_type character varying(50) NOT NULL,
    remediation_steps json NOT NULL,
    due_date timestamp with time zone,
    sla_breach boolean NOT NULL,
    resolved_at timestamp with time zone,
    verification_status character varying(50) NOT NULL,
    verified_at timestamp with time zone,
    verified_by character varying(36),
    external_ticket_id character varying(255),
    external_ticket_url text,
    tags json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.remediation_tickets OWNER TO pysoar;

--
-- Name: risk_controls; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.risk_controls (
    organization_id character varying(36) NOT NULL,
    risk_register_id character varying(36) NOT NULL,
    control_name character varying(255) NOT NULL,
    control_type character varying(50) NOT NULL,
    implementation_status character varying(50) NOT NULL,
    effectiveness_score double precision NOT NULL,
    cost_annual_usd double precision NOT NULL,
    roi_percentage double precision,
    frameworks_mapped text,
    last_tested timestamp with time zone,
    test_result character varying(50),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.risk_controls OWNER TO pysoar;

--
-- Name: risk_registers; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.risk_registers (
    organization_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    risk_category character varying(50) NOT NULL,
    inherent_risk_score double precision NOT NULL,
    residual_risk_score double precision NOT NULL,
    risk_treatment character varying(50) NOT NULL,
    treatment_plan text,
    control_effectiveness double precision NOT NULL,
    owner_id character varying(36) NOT NULL,
    review_frequency_days integer NOT NULL,
    last_review timestamp with time zone,
    next_review timestamp with time zone,
    ale_annual_usd double precision NOT NULL,
    risk_appetite_threshold_usd double precision NOT NULL,
    is_within_appetite boolean NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.risk_registers OWNER TO pysoar;

--
-- Name: risk_scenarios; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.risk_scenarios (
    organization_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    asset_id character varying(36),
    asset_name character varying(255) NOT NULL,
    asset_value_usd double precision NOT NULL,
    threat_actor character varying(50) NOT NULL,
    threat_type character varying(255) NOT NULL,
    vulnerability_exploited character varying(255) NOT NULL,
    loss_type character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    analyst_id character varying(36) NOT NULL,
    review_date timestamp with time zone,
    confidence_level double precision NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.risk_scenarios OWNER TO pysoar;

--
-- Name: runtime_alerts; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.runtime_alerts (
    cluster_id character varying(36) NOT NULL,
    alert_type character varying(100) NOT NULL,
    namespace character varying(255) NOT NULL,
    pod_name character varying(255) NOT NULL,
    container_name character varying(255),
    process_name character varying(255),
    process_args text,
    severity character varying(50) NOT NULL,
    description text NOT NULL,
    source_ip character varying(45),
    destination_ip character varying(45),
    destination_port integer,
    mitre_technique character varying(100),
    status character varying(50) NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.runtime_alerts OWNER TO pysoar;

--
-- Name: sbom_components; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.sbom_components (
    organization_id character varying(36) NOT NULL,
    sbom_id character varying(36) NOT NULL,
    component_id character varying(36) NOT NULL,
    relationship_type character varying(50) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sbom_components OWNER TO pysoar;

--
-- Name: sboms; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.sboms (
    organization_id character varying(36) NOT NULL,
    name character varying(500) NOT NULL,
    application_name character varying(500) NOT NULL,
    application_version character varying(100) NOT NULL,
    sbom_format character varying(50) NOT NULL,
    spec_version character varying(50) NOT NULL,
    created_by_tool character varying(255),
    created_by_user character varying(36),
    components_count integer NOT NULL,
    total_dependencies integer NOT NULL,
    direct_dependencies integer NOT NULL,
    transitive_dependencies integer NOT NULL,
    license_risk_score double precision NOT NULL,
    vulnerability_risk_score double precision NOT NULL,
    compliance_status character varying(100),
    sbom_content text,
    last_generated timestamp without time zone,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sboms OWNER TO pysoar;

--
-- Name: scan_profiles; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.scan_profiles (
    name character varying(255) NOT NULL,
    description text,
    scanner_type character varying(100) NOT NULL,
    target_ranges json,
    scan_policy text,
    credentials_encrypted boolean NOT NULL,
    schedule_cron character varying(255),
    last_scan_date character varying(50),
    next_scan_date character varying(50),
    enabled boolean NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.scan_profiles OWNER TO pysoar;

--
-- Name: scap_profiles; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.scap_profiles (
    name character varying(255) NOT NULL,
    profile_type character varying(50) NOT NULL,
    description text,
    content_path character varying(500),
    content_hash character varying(128),
    platform_applicable json NOT NULL,
    check_count integer NOT NULL,
    is_enabled boolean NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.scap_profiles OWNER TO pysoar;

--
-- Name: security_awareness_scores; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.security_awareness_scores (
    user_email character varying(255) NOT NULL,
    user_name character varying(255) NOT NULL,
    department character varying(255),
    overall_score integer NOT NULL,
    phishing_score integer NOT NULL,
    training_completion_rate double precision NOT NULL,
    campaigns_participated integer NOT NULL,
    times_clicked integer NOT NULL,
    times_reported integer NOT NULL,
    times_submitted_credentials integer NOT NULL,
    last_failed_campaign timestamp without time zone,
    risk_category character varying(50) NOT NULL,
    training_assignments json NOT NULL,
    certifications json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.security_awareness_scores OWNER TO pysoar;

--
-- Name: security_posture_scores; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.security_posture_scores (
    simulation_id character varying(36),
    score_type character varying(50) NOT NULL,
    score double precision NOT NULL,
    max_score double precision NOT NULL,
    breakdown json NOT NULL,
    comparison_to_previous double precision,
    recommendations json NOT NULL,
    assessed_at timestamp without time zone NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.security_posture_scores OWNER TO pysoar;

--
-- Name: COLUMN security_posture_scores.score_type; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.security_posture_scores.score_type IS 'overall, detection, prevention, response, by_tactic, by_kill_chain';


--
-- Name: COLUMN security_posture_scores.breakdown; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.security_posture_scores.breakdown IS 'per-tactic/technique scores';


--
-- Name: COLUMN security_posture_scores.comparison_to_previous; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.security_posture_scores.comparison_to_previous IS 'delta from previous score';


--
-- Name: sensitive_data_discoveries; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.sensitive_data_discoveries (
    organization_id character varying(36) NOT NULL,
    scan_id character varying(36) NOT NULL,
    scan_type character varying(50) NOT NULL,
    target character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    total_files_scanned integer NOT NULL,
    sensitive_files_found integer NOT NULL,
    classification_breakdown text,
    findings text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    next_scheduled_scan timestamp with time zone,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sensitive_data_discoveries OWNER TO pysoar;

--
-- Name: shared_artifacts; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.shared_artifacts (
    organization_id character varying(36) NOT NULL,
    room_id character varying(36) NOT NULL,
    uploaded_by character varying(36) NOT NULL,
    artifact_type character varying(50) NOT NULL,
    file_name character varying(255) NOT NULL,
    file_hash character varying(128) NOT NULL,
    file_size_bytes integer NOT NULL,
    description text,
    classification_level character varying(50) NOT NULL,
    access_restricted_to text,
    download_count integer NOT NULL,
    analysis_status character varying(50) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.shared_artifacts OWNER TO pysoar;

--
-- Name: siem_data_sources; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.siem_data_sources (
    name character varying(255) NOT NULL,
    description text,
    source_type character varying(50) NOT NULL,
    connection_config text,
    parser_config text,
    enabled boolean NOT NULL,
    last_event_at character varying(50),
    events_today bigint NOT NULL,
    error_count integer NOT NULL,
    last_error text,
    organization_id character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.siem_data_sources OWNER TO pysoar;

--
-- Name: siem_saved_searches; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.siem_saved_searches (
    name character varying(255) NOT NULL,
    description text,
    query text NOT NULL,
    filters text,
    time_range character varying(50),
    is_alert boolean NOT NULL,
    alert_threshold integer,
    schedule_cron character varying(100),
    last_run_at character varying(50),
    last_result_count integer NOT NULL,
    organization_id character varying(36),
    created_by character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.siem_saved_searches OWNER TO pysoar;

--
-- Name: simulation_tests; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.simulation_tests (
    simulation_id character varying(36) NOT NULL,
    technique_id character varying(36) NOT NULL,
    test_name character varying(255) NOT NULL,
    test_order integer NOT NULL,
    status character varying(50) NOT NULL,
    target_host character varying(255),
    executor character varying(50) NOT NULL,
    command_executed text,
    cleanup_command text,
    cleanup_status character varying(50),
    output text,
    error_output text,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    was_detected boolean,
    detection_time_seconds integer,
    detection_source character varying(255),
    detection_details json,
    notes text,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.simulation_tests OWNER TO pysoar;

--
-- Name: COLUMN simulation_tests.status; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.simulation_tests.status IS 'pending, running, passed, failed, blocked, error, skipped';


--
-- Name: COLUMN simulation_tests.executor; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.simulation_tests.executor IS 'powershell, bash, cmd, python, manual';


--
-- Name: COLUMN simulation_tests.detection_source; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.simulation_tests.detection_source IS 'which SIEM rule/system detected it';


--
-- Name: soc_agents; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.soc_agents (
    name character varying(255) NOT NULL,
    agent_type character varying(50) NOT NULL,
    organization_id character varying(36) NOT NULL,
    status character varying(50) NOT NULL,
    current_task_id character varying(36),
    capabilities json,
    llm_model character varying(100) NOT NULL,
    temperature double precision NOT NULL,
    max_reasoning_steps integer NOT NULL,
    autonomy_level character varying(50) NOT NULL,
    total_investigations integer NOT NULL,
    avg_resolution_time_minutes double precision NOT NULL,
    accuracy_score double precision NOT NULL,
    false_positive_rate double precision NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.soc_agents OWNER TO pysoar;

--
-- Name: software_components; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.software_components (
    organization_id character varying(36) NOT NULL,
    name character varying(500) NOT NULL,
    version character varying(100) NOT NULL,
    vendor character varying(255),
    package_type character varying(50) NOT NULL,
    license_type character varying(100),
    license_spdx_id character varying(50),
    purl character varying(2048),
    cpe character varying(500),
    checksum_sha256 character varying(64),
    source_url text,
    is_direct_dependency boolean NOT NULL,
    parent_component_id character varying(36),
    depth_level integer NOT NULL,
    known_vulnerabilities_count integer NOT NULL,
    risk_score double precision NOT NULL,
    last_scanned timestamp without time zone,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.software_components OWNER TO pysoar;

--
-- Name: stig_benchmarks; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.stig_benchmarks (
    benchmark_id character varying(255) NOT NULL,
    title character varying(500),
    version character varying(50),
    release character varying(50),
    description text,
    platform character varying(100),
    total_rules integer NOT NULL,
    category_1_count integer NOT NULL,
    category_2_count integer NOT NULL,
    category_3_count integer NOT NULL,
    status character varying(50) NOT NULL,
    last_scan_at timestamp with time zone,
    tags json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.stig_benchmarks OWNER TO pysoar;

--
-- Name: stig_rules; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.stig_rules (
    benchmark_id_ref character varying(36) NOT NULL,
    rule_id character varying(100) NOT NULL,
    stig_id character varying(100),
    group_id character varying(100),
    severity character varying(20) NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    check_text text,
    fix_text text,
    cci json NOT NULL,
    nist_controls json NOT NULL,
    automated_check json,
    is_automatable boolean NOT NULL,
    default_status character varying(50) NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.stig_rules OWNER TO pysoar;

--
-- Name: stig_scan_results; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.stig_scan_results (
    benchmark_id_ref character varying(36) NOT NULL,
    target_host character varying(255) NOT NULL,
    target_ip character varying(45),
    scan_type character varying(50) NOT NULL,
    scanner character varying(100),
    status character varying(50) NOT NULL,
    started_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    total_checks integer NOT NULL,
    open_findings integer NOT NULL,
    not_a_finding integer NOT NULL,
    not_applicable integer NOT NULL,
    not_reviewed integer NOT NULL,
    compliance_percentage double precision NOT NULL,
    cat1_open integer NOT NULL,
    cat2_open integer NOT NULL,
    cat3_open integer NOT NULL,
    findings json NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.stig_scan_results OWNER TO pysoar;

--
-- Name: supply_chain_risks; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.supply_chain_risks (
    organization_id character varying(36) NOT NULL,
    component_id character varying(36) NOT NULL,
    risk_type character varying(100) NOT NULL,
    severity character varying(50) NOT NULL,
    description text NOT NULL,
    evidence text,
    cve_ids text,
    remediation_advice text,
    status character varying(50) NOT NULL,
    detected_date timestamp without time zone NOT NULL,
    remediation_date timestamp without time zone,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.supply_chain_risks OWNER TO pysoar;

--
-- Name: target_groups; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.target_groups (
    name character varying(255) NOT NULL,
    description text,
    department character varying(255),
    members json NOT NULL,
    member_count integer NOT NULL,
    risk_level character varying(50) NOT NULL,
    avg_click_rate double precision NOT NULL,
    campaigns_participated integer NOT NULL,
    last_campaign_date timestamp without time zone,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.target_groups OWNER TO pysoar;

--
-- Name: team_members; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.team_members (
    team_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    role character varying(50) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.team_members OWNER TO pysoar;

--
-- Name: teams; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.teams (
    name character varying(255) NOT NULL,
    description text,
    organization_id character varying(36) NOT NULL,
    is_default boolean NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.teams OWNER TO pysoar;

--
-- Name: threat_actors; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.threat_actors (
    name character varying(255) NOT NULL,
    aliases json NOT NULL,
    description text,
    actor_type character varying(50),
    sophistication character varying(50),
    country_of_origin character varying(100),
    first_observed timestamp with time zone,
    last_observed timestamp with time zone,
    primary_motivation character varying(100),
    secondary_motivations json NOT NULL,
    mitre_groups json NOT NULL,
    known_ttps json NOT NULL,
    target_sectors json NOT NULL,
    target_countries json NOT NULL,
    associated_campaigns json NOT NULL,
    confidence integer NOT NULL,
    "references" json NOT NULL,
    tags json NOT NULL,
    organization_id character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.threat_actors OWNER TO pysoar;

--
-- Name: threat_campaigns; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.threat_campaigns (
    name character varying(255) NOT NULL,
    description text,
    status character varying(50) NOT NULL,
    actor_id character varying(36),
    first_observed timestamp with time zone,
    last_observed timestamp with time zone,
    objectives json NOT NULL,
    target_sectors json NOT NULL,
    target_countries json NOT NULL,
    associated_indicators json NOT NULL,
    mitre_techniques json NOT NULL,
    confidence integer NOT NULL,
    "references" json NOT NULL,
    tags json NOT NULL,
    organization_id character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.threat_campaigns OWNER TO pysoar;

--
-- Name: threat_feeds; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.threat_feeds (
    name character varying(255) NOT NULL,
    feed_type character varying(50) NOT NULL,
    url text,
    provider character varying(255),
    description text,
    is_enabled boolean NOT NULL,
    is_builtin boolean NOT NULL,
    auth_type character varying(50),
    auth_config json,
    poll_interval_minutes integer NOT NULL,
    last_poll_at timestamp with time zone,
    last_success_at timestamp with time zone,
    last_error text,
    total_indicators integer NOT NULL,
    confidence_weight double precision NOT NULL,
    tags json NOT NULL,
    organization_id character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.threat_feeds OWNER TO pysoar;

--
-- Name: threat_indicators; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.threat_indicators (
    indicator_type character varying(50) NOT NULL,
    value text NOT NULL,
    feed_id character varying(36),
    source character varying(255),
    confidence integer,
    severity character varying(20),
    tlp character varying(20),
    first_seen timestamp with time zone,
    last_seen timestamp with time zone,
    expires_at timestamp with time zone,
    is_active boolean NOT NULL,
    is_whitelisted boolean NOT NULL,
    kill_chain_phase character varying(100),
    mitre_tactics json NOT NULL,
    mitre_techniques json NOT NULL,
    tags json NOT NULL,
    context json NOT NULL,
    related_indicators json NOT NULL,
    sighting_count integer NOT NULL,
    last_sighting_at timestamp with time zone,
    false_positive_count integer NOT NULL,
    organization_id character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.threat_indicators OWNER TO pysoar;

--
-- Name: threat_mitigations; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.threat_mitigations (
    organization_id character varying(36) NOT NULL,
    threat_id character varying(36) NOT NULL,
    mitigation_type character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    implementation_status character varying(50) NOT NULL,
    control_reference json,
    effectiveness_score integer NOT NULL,
    cost_estimate_usd integer,
    assigned_to character varying(36),
    deadline character varying(50),
    verification_method text,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.threat_mitigations OWNER TO pysoar;

--
-- Name: threat_model_components; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.threat_model_components (
    organization_id character varying(36) NOT NULL,
    model_id character varying(36) NOT NULL,
    component_type character varying(100) NOT NULL,
    name character varying(500) NOT NULL,
    description text,
    technology_stack character varying(500),
    data_classification character varying(100),
    trust_level character varying(50) NOT NULL,
    "position" json,
    connections json,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.threat_model_components OWNER TO pysoar;

--
-- Name: threat_models; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.threat_models (
    organization_id character varying(36) NOT NULL,
    name character varying(500) NOT NULL,
    description text,
    application_name character varying(500) NOT NULL,
    version character varying(50) NOT NULL,
    methodology character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    scope text,
    architecture_description text,
    data_flow_diagram json,
    created_by character varying(36),
    reviewed_by character varying(36),
    review_date character varying(50),
    risk_score integer NOT NULL,
    threats_count integer NOT NULL,
    mitigations_count integer NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.threat_models OWNER TO pysoar;

--
-- Name: threat_predictions; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.threat_predictions (
    prediction_type character varying(50) NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id character varying(255) NOT NULL,
    risk_score double precision NOT NULL,
    probability double precision NOT NULL,
    time_horizon_hours integer NOT NULL,
    contributing_factors json NOT NULL,
    recommended_actions json NOT NULL,
    mitre_techniques json NOT NULL,
    model_id character varying(36),
    expires_at timestamp with time zone NOT NULL,
    was_accurate boolean,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.threat_predictions OWNER TO pysoar;

--
-- Name: COLUMN threat_predictions.prediction_type; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.threat_predictions.prediction_type IS 'attack_probability, vulnerability_exploitation, lateral_movement, data_exfiltration, insider_threat';


--
-- Name: ticket_activities; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.ticket_activities (
    source_type character varying(50) NOT NULL,
    source_id character varying(36) NOT NULL,
    activity_type character varying(50) NOT NULL,
    actor_id character varying(36),
    description character varying(500) NOT NULL,
    old_value text,
    new_value text,
    metadata json,
    organization_id character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ticket_activities OWNER TO pysoar;

--
-- Name: ticket_comments; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.ticket_comments (
    source_type character varying(50) NOT NULL,
    source_id character varying(36) NOT NULL,
    content text NOT NULL,
    author_id character varying(36) NOT NULL,
    parent_comment_id character varying(36),
    mentioned_users json,
    is_edited boolean NOT NULL,
    edited_at timestamp with time zone,
    organization_id character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ticket_comments OWNER TO pysoar;

--
-- Name: ticket_links; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.ticket_links (
    source_type_a character varying(50) NOT NULL,
    source_id_a character varying(36) NOT NULL,
    source_type_b character varying(50) NOT NULL,
    source_id_b character varying(36) NOT NULL,
    link_type character varying(50) NOT NULL,
    created_by character varying(36),
    organization_id character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ticket_links OWNER TO pysoar;

--
-- Name: ueba_risk_alerts; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.ueba_risk_alerts (
    entity_profile_id character varying(36) NOT NULL,
    alert_type character varying(100) NOT NULL,
    severity character varying(20) NOT NULL,
    risk_score_delta double precision NOT NULL,
    description text NOT NULL,
    evidence json NOT NULL,
    contributing_events json NOT NULL,
    mitre_techniques json NOT NULL,
    status character varying(50) NOT NULL,
    analyst_notes text,
    escalated_to_incident character varying(36),
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ueba_risk_alerts OWNER TO pysoar;

--
-- Name: unified_data_models; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.unified_data_models (
    organization_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    entity_type character varying(50) NOT NULL,
    schema_version character varying(20) NOT NULL,
    field_definitions json NOT NULL,
    normalization_rules json NOT NULL,
    enrichment_rules json NOT NULL,
    sample_data json,
    is_active boolean NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.unified_data_models OWNER TO pysoar;

--
-- Name: COLUMN unified_data_models.field_definitions; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.unified_data_models.field_definitions IS 'Array of {name, type, description, source_mapping, required}';


--
-- Name: COLUMN unified_data_models.normalization_rules; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.unified_data_models.normalization_rules IS 'Rules for normalizing raw data to unified model';


--
-- Name: COLUMN unified_data_models.enrichment_rules; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.unified_data_models.enrichment_rules IS 'Rules for enriching data with context (geo, threat intel, assets)';


--
-- Name: COLUMN unified_data_models.sample_data; Type: COMMENT; Schema: public; Owner: pysoar
--

COMMENT ON COLUMN public.unified_data_models.sample_data IS 'Example normalized event for validation';


--
-- Name: users; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.users (
    email character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    full_name character varying(255),
    role character varying(50) NOT NULL,
    is_active boolean NOT NULL,
    is_superuser boolean NOT NULL,
    phone character varying(50),
    department character varying(100),
    avatar_url text,
    last_login character varying(50),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    force_password_change boolean DEFAULT false NOT NULL,
    mfa_enabled boolean DEFAULT false NOT NULL,
    mfa_secret text,
    mfa_backup_codes text,
    organization_id character varying(36)
);


ALTER TABLE public.users OWNER TO pysoar;

--
-- Name: vendor_assessments; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.vendor_assessments (
    organization_id character varying(36) NOT NULL,
    vendor_name character varying(500) NOT NULL,
    vendor_url character varying(500),
    assessment_type character varying(100) NOT NULL,
    assessment_date timestamp without time zone NOT NULL,
    security_score double precision NOT NULL,
    questionnaire_responses text,
    certifications text,
    last_incident_date timestamp without time zone,
    incident_count integer NOT NULL,
    contract_expiry timestamp without time zone,
    data_handling_classification character varying(100) NOT NULL,
    third_party_subprocessors text,
    risk_tier character varying(50) NOT NULL,
    notes text,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.vendor_assessments OWNER TO pysoar;

--
-- Name: visual_playbook_executions; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.visual_playbook_executions (
    playbook_id character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL,
    parent_execution_id character varying(36),
    trigger_event text,
    status character varying(50) NOT NULL,
    current_node_id character varying(100),
    started_at character varying(50),
    completed_at character varying(50),
    duration_ms integer,
    execution_path text,
    variables text,
    error_message text,
    triggered_by character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.visual_playbook_executions OWNER TO pysoar;

--
-- Name: visual_playbooks; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.visual_playbooks (
    organization_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    version integer NOT NULL,
    category character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    trigger_type character varying(50) NOT NULL,
    trigger_config text,
    canvas_data text,
    execution_count integer NOT NULL,
    avg_execution_time_ms double precision NOT NULL,
    success_rate double precision NOT NULL,
    last_executed character varying(50),
    created_by character varying(36),
    is_template boolean NOT NULL,
    template_category character varying(100),
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.visual_playbooks OWNER TO pysoar;

--
-- Name: vulnerabilities; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.vulnerabilities (
    cve_id character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    cvss_v3_score numeric(4,1),
    cvss_v3_vector character varying(255),
    epss_score numeric(5,4),
    severity character varying(50) NOT NULL,
    vulnerability_type character varying(50),
    cwe_id character varying(50),
    mitre_technique_ids json,
    affected_software text,
    affected_versions json,
    published_date character varying(50),
    modified_date character varying(50),
    exploit_available boolean NOT NULL,
    exploit_maturity character varying(50) NOT NULL,
    patch_available boolean NOT NULL,
    patch_url text,
    "references" json,
    kev_listed boolean NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.vulnerabilities OWNER TO pysoar;

--
-- Name: vulnerability_exceptions; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.vulnerability_exceptions (
    vulnerability_instance_id character varying(36) NOT NULL,
    exception_type character varying(50) NOT NULL,
    justification text NOT NULL,
    approved_by character varying(36),
    approval_date character varying(50),
    expiry_date character varying(50),
    review_date character varying(50),
    compensating_control_description text,
    risk_acceptance_level character varying(50),
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.vulnerability_exceptions OWNER TO pysoar;

--
-- Name: vulnerability_instances; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.vulnerability_instances (
    vulnerability_id character varying(36) NOT NULL,
    asset_id character varying(36),
    asset_name character varying(255),
    asset_ip character varying(45),
    asset_type character varying(100),
    discovered_by character varying(50) NOT NULL,
    scan_id character varying(36),
    first_seen character varying(50),
    last_seen character varying(50),
    status character varying(50) NOT NULL,
    risk_score numeric(5,2),
    exploitability_score numeric(5,2),
    business_criticality integer,
    assigned_to character varying(36),
    remediation_deadline character varying(50),
    sla_status character varying(50) NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.vulnerability_instances OWNER TO pysoar;

--
-- Name: war_room_messages; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.war_room_messages (
    organization_id character varying(36) NOT NULL,
    room_id character varying(36) NOT NULL,
    sender_id character varying(36) NOT NULL,
    sender_name character varying(255) NOT NULL,
    message_type character varying(50) NOT NULL,
    content text NOT NULL,
    attachments text,
    mentioned_users text,
    is_pinned boolean NOT NULL,
    is_edited boolean NOT NULL,
    edited_at timestamp with time zone,
    parent_message_id character varying(36),
    reactions text,
    metadata text,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.war_room_messages OWNER TO pysoar;

--
-- Name: war_rooms; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.war_rooms (
    organization_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    incident_id character varying(36),
    room_type character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    severity_level character varying(50) NOT NULL,
    commander_id character varying(36),
    participants text,
    max_participants integer NOT NULL,
    auto_archive_hours integer,
    created_by character varying(36) NOT NULL,
    pinned_items text,
    tags text,
    is_encrypted boolean NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.war_rooms OWNER TO pysoar;

--
-- Name: webhook_endpoints; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.webhook_endpoints (
    organization_id character varying(36) NOT NULL,
    installed_id character varying(36) NOT NULL,
    endpoint_path character varying(255) NOT NULL,
    http_method character varying(10) NOT NULL,
    secret_hash character varying(256) NOT NULL,
    event_types text NOT NULL,
    transform_template text,
    is_active boolean NOT NULL,
    last_received character varying(50),
    received_count integer NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.webhook_endpoints OWNER TO pysoar;

--
-- Name: zero_trust_policies; Type: TABLE; Schema: public; Owner: pysoar
--

CREATE TABLE public.zero_trust_policies (
    name character varying(255) NOT NULL,
    policy_type character varying(50) NOT NULL,
    description text,
    conditions text NOT NULL,
    actions text NOT NULL,
    risk_threshold double precision NOT NULL,
    requires_mfa boolean NOT NULL,
    requires_device_trust boolean NOT NULL,
    minimum_device_trust_score double precision NOT NULL,
    allowed_locations text NOT NULL,
    blocked_locations text NOT NULL,
    time_restrictions text NOT NULL,
    data_classification_required character varying(50),
    microsegment_id character varying(36),
    is_enabled boolean NOT NULL,
    priority integer NOT NULL,
    hit_count integer NOT NULL,
    last_triggered_at timestamp with time zone,
    tags text NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.zero_trust_policies OWNER TO pysoar;

--
-- Data for Name: access_anomalies; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.access_anomalies (organization_id, identity_id, anomaly_type, baseline_data, observed_data, deviation_score, is_reviewed, reviewer_notes, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: access_decisions; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.access_decisions (policy_id, subject_type, subject_id, resource_type, resource_id, decision, risk_score, risk_factors, context, authentication_method, mfa_completed, device_trust_score, session_id, decision_reason, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: action_items; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.action_items (organization_id, room_id, title, description, assigned_to, assigned_by, priority, status, due_date, completed_at, linked_alert_id, linked_incident_id, notes, checklist, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: adversary_profiles; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.adversary_profiles (name, description, threat_actor_ref, sophistication, attack_chain, objectives, ttps, target_sectors, tools_used, is_builtin, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_actions; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.agent_actions (investigation_id, organization_id, action_type, target, parameters, requires_approval, approved_by, approval_timestamp, execution_status, result, rollback_available, rollback_executed, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_memories; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.agent_memories (agent_id, organization_id, memory_type, key, value, confidence, access_count, last_accessed, decay_rate, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_analyses; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.ai_analyses (analysis_type, source_type, source_id, input_data, prompt_used, ai_response, structured_output, confidence, model_used, tokens_used, latency_ms, feedback_score, feedback_notes, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.alerts (title, description, severity, status, source, source_id, source_url, alert_type, category, tags, priority, confidence, raw_data, enrichment_data, source_ip, destination_ip, hostname, username, file_hash, url, domain, assigned_to, incident_id, resolution_notes, resolved_at, id, created_at, updated_at) FROM stdin;
Brute force SSH login detected	Multiple failed SSH login attempts from external IP	critical	acknowledged	siem	\N	\N	\N	ids	\N	4	58	\N	\N	94.200.79.160	169.249.48.27	host-316.corp.local	\N	\N	\N	\N	\N	\N	\N	\N	3aa89995-6a99-41ea-89a1-102e80e6b589	2026-03-11 15:37:36.352246+00	2026-03-31 03:11:42.35227+00
Suspicious PowerShell execution	Encoded PowerShell command detected on workstation	high	resolved	edr	\N	\N	\N	malware	\N	3	65	\N	\N	151.244.31.7	153.158.228.227	host-207.corp.local	\N	\N	\N	\N	\N	\N	\N	\N	20320a5c-8078-4155-ae6a-7f2e20d23711	2026-03-17 05:04:47.352579+00	2026-03-31 03:11:42.352585+00
Outbound C2 communication detected	Beaconing traffic to known C2 infrastructure	critical	closed	firewall	\N	\N	\N	malware	\N	5	48	\N	\N	52.48.47.67	141.159.207.45	host-333.corp.local	\N	\N	\N	\N	\N	\N	\N	\N	68d27fb8-6a26-4336-8305-6d139d2272a8	2026-03-13 18:24:58.35268+00	2026-03-31 03:11:42.352683+00
Phishing email with malicious attachment	Employee received email with weaponized Excel macro	high	closed	email_gateway	\N	\N	\N	phishing	\N	2	98	\N	\N	67.193.221.18	16.190.27.166	host-638.corp.local	\N	\N	\N	\N	\N	\N	\N	\N	5fee4f4f-02cf-4af1-a816-d0d1f6e25156	2026-03-04 01:37:20.352791+00	2026-03-31 03:11:42.352794+00
Unauthorized admin account created	New domain admin account created outside change window	critical	acknowledged	siem	\N	\N	\N	unauthorized_access	\N	1	47	\N	\N	103.208.110.216	104.181.133.88	host-852.corp.local	\N	\N	\N	\N	\N	\N	\N	\N	84dee26b-f1ad-4be8-8fd4-d817f0c575bb	2026-03-24 12:40:35.352862+00	2026-03-31 03:11:42.352864+00
AWS S3 bucket made public	Production S3 bucket ACL changed to public-read	high	new	cloud	\N	\N	\N	misconfiguration	\N	3	70	\N	\N	219.10.149.47	139.254.45.40	host-712.corp.local	\N	\N	\N	\N	\N	\N	\N	\N	d821e26b-90a2-4cbe-bfb7-8343e16a2fb1	2026-03-23 16:52:56.352925+00	2026-03-31 03:11:42.352927+00
Lateral movement via RDP	Unusual RDP connections between workstations	high	closed	edr	\N	\N	\N	lateral_movement	\N	3	54	\N	\N	22.100.75.7	149.57.96.147	host-606.corp.local	\N	\N	\N	\N	\N	\N	\N	\N	faba96bf-35e3-407e-aafd-cf67a79c1b7c	2026-03-09 00:07:34.35299+00	2026-03-31 03:11:42.352992+00
Data exfiltration to external storage	Large data transfer to cloud storage service	critical	acknowledged	firewall	\N	\N	\N	data_exfiltration	\N	2	44	\N	\N	19.85.179.210	107.132.89.171	host-629.corp.local	\N	\N	\N	\N	\N	\N	\N	\N	99199f1e-2ae7-4cfa-a55d-173174bffb6c	2026-03-05 13:45:20.353054+00	2026-03-31 03:11:42.353057+00
Ransomware encryption activity	Mass file encryption detected on file server	critical	closed	edr	\N	\N	\N	ransomware	\N	3	84	\N	\N	93.172.131.19	114.34.54.19	host-425.corp.local	\N	\N	\N	\N	\N	\N	\N	\N	da26749b-9735-4d9d-b0ff-7351a2ece695	2026-03-18 11:38:54.353152+00	2026-03-31 03:11:42.353155+00
SQL injection attempt on web app	SQL injection payload detected in HTTP POST request	medium	acknowledged	ids	\N	\N	\N	web_attack	\N	4	60	\N	\N	174.177.114.239	70.138.40.21	host-488.corp.local	\N	\N	\N	\N	\N	\N	\N	\N	e28c9622-5f22-49c3-90b1-d87ce2b7e25c	2026-03-18 02:45:34.353211+00	2026-03-31 03:11:42.353213+00
Expired SSL certificate detected	SSL certificate expired on customer-facing API gateway	low	resolved	cloud	\N	\N	\N	misconfiguration	\N	1	43	\N	\N	110.117.169.76	135.17.108.83	host-166.corp.local	\N	\N	\N	\N	\N	\N	\N	\N	058d06f8-36db-45ee-8dd9-3ac744e24f90	2026-03-15 19:25:10.353395+00	2026-03-31 03:11:42.353399+00
Unusual login from foreign country	Admin login from IP geolocated to unexpected region	medium	resolved	siem	\N	\N	\N	suspicious_login	\N	3	48	\N	\N	83.85.198.11	145.39.92.82	host-886.corp.local	\N	\N	\N	\N	\N	\N	\N	\N	db805425-7d71-4dc4-bb52-90e738f1253a	2026-03-02 22:45:18.353484+00	2026-03-31 03:11:42.353487+00
Firewall rule modification	Allow-all rule added to production firewall	medium	in_progress	firewall	\N	\N	\N	policy_violation	\N	1	81	\N	\N	127.196.121.113	174.54.203.229	host-405.corp.local	\N	\N	\N	\N	\N	\N	\N	\N	e506eb31-62bf-4568-b7d8-3466575d94dc	2026-03-04 10:23:35.353543+00	2026-03-31 03:11:42.353544+00
Malware detected in email quarantine	Known Emotet variant blocked by email gateway	low	in_progress	email_gateway	\N	\N	\N	malware	\N	5	72	\N	\N	76.208.124.157	73.204.240.85	host-672.corp.local	\N	\N	\N	\N	\N	\N	\N	\N	764a483d-27e1-47a2-bfd2-3054200d412f	2026-03-04 17:42:21.353601+00	2026-03-31 03:11:42.353603+00
DNS tunneling attempt	Suspicious DNS queries with encoded data payloads	high	closed	ids	\N	\N	\N	data_exfiltration	\N	2	61	\N	\N	19.139.195.128	151.9.221.72	host-236.corp.local	\N	\N	\N	\N	\N	\N	\N	\N	91fe988d-ccbc-44af-ae30-af5b66f0c212	2026-03-07 16:01:09.353657+00	2026-03-31 03:11:42.353658+00
Privilege escalation on Linux server	User gained root access via kernel exploit	high	new	edr	\N	\N	\N	privilege_escalation	\N	2	59	\N	\N	60.24.190.7	14.165.169.4	host-286.corp.local	\N	\N	\N	\N	\N	\N	\N	\N	3ea99fd1-c3c9-4e60-8e52-e261c8502a74	2026-03-18 02:28:58.353746+00	2026-03-31 03:11:42.353749+00
New scheduled task created	Suspicious scheduled task created for persistence	medium	in_progress	siem	\N	\N	\N	persistence	\N	2	93	\N	\N	194.97.42.76	81.98.47.167	host-657.corp.local	\N	\N	\N	\N	\N	\N	\N	\N	d560270b-359c-44aa-8034-6a6043d76cad	2026-03-08 16:00:47.353804+00	2026-03-31 03:11:42.353806+00
Cloud IAM policy change	IAM role permissions expanded beyond least privilege	medium	resolved	cloud	\N	\N	\N	policy_violation	\N	3	95	\N	\N	10.238.208.100	147.81.230.191	host-787.corp.local	\N	\N	\N	\N	\N	\N	\N	\N	f4b5c075-b594-4fce-b356-19292b4c5988	2026-03-12 20:15:52.353862+00	2026-03-31 03:11:42.353863+00
Web shell uploaded to server	PHP web shell detected in web server uploads directory	critical	acknowledged	edr	\N	\N	\N	web_attack	\N	3	57	\N	\N	82.43.108.149	129.229.35.65	host-723.corp.local	\N	\N	\N	\N	\N	\N	\N	\N	60d02867-618b-4425-9e14-69c878de9c4a	2026-03-27 16:52:38.353914+00	2026-03-31 03:11:42.353915+00
VPN connection from compromised IP	VPN login from IP on threat intelligence blocklist	low	resolved	firewall	\N	\N	\N	suspicious_login	\N	5	50	\N	\N	92.136.136.242	98.238.97.228	host-921.corp.local	\N	\N	\N	\N	\N	\N	\N	\N	8ca84831-cb01-4452-830a-71331518aa8e	2026-03-17 05:27:27.353968+00	2026-03-31 03:11:42.35397+00
Test Alert	Testing save	high	new	manual	\N	\N	\N	\N	\N	3	50	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	520a23f6-8375-4d4d-a537-78220c58a1c6	2026-04-06 00:47:20.610569+00	2026-04-06 00:47:20.610574+00
Save Test Alert	Testing save	high	new	manual_test	\N	\N	\N	\N	\N	3	50	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	c9b5b674-4268-431f-af85-cc959c8f9b44	2026-04-06 00:52:42.925556+00	2026-04-06 00:52:42.925561+00
T	\N	high	new	t	\N	\N	\N	\N	\N	3	50	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	73bbb2be-e76f-4794-9083-4ebc990f246c	2026-04-06 01:03:42.565511+00	2026-04-06 01:03:42.565516+00
SaveTest	\N	high	new	test	\N	\N	\N	\N	\N	3	50	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	668bddce-9782-42fc-a10e-5206ce499601	2026-04-06 01:06:35.861733+00	2026-04-06 01:06:35.86174+00
FinalTest	\N	high	new	t	\N	\N	\N	\N	\N	3	50	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	9c1f8952-6b62-499a-82e1-62fc61d6c04c	2026-04-06 01:13:09.767611+00	2026-04-06 01:13:09.767617+00
X	\N	high	new	t	\N	\N	\N	\N	\N	3	50	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	869d0e31-de99-443c-a0b0-042aa5679309	2026-04-06 01:30:04.456233+00	2026-04-06 01:30:04.456239+00
F	\N	high	new	t	\N	\N	\N	\N	\N	3	50	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ddb75aeb-4e75-47ec-8c6e-7114e22de94b	2026-04-06 01:39:35.591729+00	2026-04-06 01:39:35.591735+00
\.


--
-- Data for Name: anomaly_detections; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.anomaly_detections (model_id, entity_type, entity_id, anomaly_type, anomaly_score, confidence, severity, features, baseline, deviation, description, is_confirmed, is_false_positive, related_alerts, mitre_techniques, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: api_anomaly_detection; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.api_anomaly_detection (endpoint_id, anomaly_type, baseline_value, observed_value, deviation_percentage, severity, source_ips, sample_requests, status, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: api_compliance_checks; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.api_compliance_checks (endpoint_id, check_type, passed, details, last_checked, remediation_steps, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: api_endpoint_inventory; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.api_endpoint_inventory (service_name, base_url, path, method, api_version, authentication_type, authorization_model, data_classification, is_public, is_documented, is_shadow, is_deprecated, rate_limit_configured, input_validation_enabled, response_encryption, last_seen, request_count_24h, error_rate, owner_team, openapi_spec_url, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.api_keys (name, description, key_prefix, key_hash, permissions, allowed_ips, rate_limit, is_active, expires_at, last_used_at, last_used_ip, usage_count, owner_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: api_security_policies; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.api_security_policies (name, description, policy_type, rules, enforcement_level, applies_to, violations_count, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: api_vulnerabilities; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.api_vulnerabilities (endpoint_id, vulnerability_type, severity, description, evidence, remediation, status, cwe_id, detected_by, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: asset_vulnerabilities; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.asset_vulnerabilities (asset_id, vulnerability_id, status, detected_at, remediated_at, due_date, assigned_to, remediation_notes, compensating_controls, risk_score, exploitability_score, impact_score, detected_by, scan_reference, verification_status, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.assets (name, hostname, asset_type, status, ip_address, mac_address, fqdn, criticality, business_unit, department, owner, location, operating_system, os_version, installed_software, open_ports, services, cloud_provider, cloud_region, cloud_instance_id, security_score, vulnerabilities, compliance_status, last_scan, description, tags, custom_fields, is_monitored, agent_installed, last_seen, id, created_at, updated_at) FROM stdin;
DC01	\N	server	active	10.0.1.10	\N	\N	critical	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Active Directory Domain Controller	\N	\N	t	f	\N	19988881-ef5f-4523-8693-f943a5dc27d5	2026-01-30 00:29:12.355945+00	2026-03-31 03:11:42.355949+00
WEB-PROD-01	\N	server	active	10.0.2.20	\N	\N	high	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Production Web Application Server	\N	\N	t	f	\N	d58ef866-76e5-4a1a-a3eb-88d4d9c7ddbf	2026-03-13 18:34:22.356054+00	2026-03-31 03:11:42.356058+00
FW-EDGE-01	\N	network	active	10.0.0.1	\N	\N	critical	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Perimeter Firewall - Palo Alto	\N	\N	t	f	\N	7c403bd0-c58b-47e8-94b9-36aedc5ee83b	2025-11-20 20:58:18.356123+00	2026-03-31 03:11:42.356127+00
LAPTOP-EXEC-042	\N	workstation	active	10.0.10.42	\N	\N	high	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	CFO Laptop - Windows 11	\N	\N	t	f	\N	9920ae91-85c0-4dbe-9b4c-da5e29643dab	2025-10-14 16:46:06.35619+00	2026-03-31 03:11:42.356194+00
DB-PROD-01	\N	server	active	10.0.3.30	\N	\N	critical	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Production PostgreSQL Database	\N	\N	t	f	\N	319573ea-82db-4894-97bb-944292ca8626	2025-12-06 01:44:48.356248+00	2026-03-31 03:11:42.356252+00
test-server-01	test-server-01	server	active	192.168.1.100	\N	\N	high	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	\N	6f94b34b-9b43-49d5-a10d-83ad43af6787	2026-04-06 00:53:07.675758+00	2026-04-06 00:53:07.675764+00
web01	web01	server	active	10.0.1.1	\N	\N	medium	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	\N	8cc3807e-a871-456c-a606-378185eb036e	2026-04-06 01:06:36.560251+00	2026-04-06 01:06:36.560256+00
gdsfg	gsdfg	server	active	gsgf		\N	medium	gfdg					\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	\N	t	f	\N	859ffb06-266d-42e9-830f-6dc35f860cde	2026-04-06 01:17:21.408184+00	2026-04-06 01:17:21.40819+00
z1	z1	server	active	10.99.0.1	\N	\N	medium	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	\N	4ee65105-c084-4739-9b90-6870d209297e	2026-04-06 01:30:05.282981+00	2026-04-06 01:30:05.282987+00
f1	f1	server	active	10.88.0.1	\N	\N	medium	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	\N	fb87cd15-afd6-4502-837b-380b599ee716	2026-04-06 01:39:36.349942+00	2026-04-06 01:39:36.349948+00
\.


--
-- Data for Name: attack_simulations; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.attack_simulations (name, description, simulation_type, status, target_environment, scope, mitre_tactics, mitre_techniques, scheduled_at, started_at, completed_at, duration_seconds, total_tests, passed_tests, failed_tests, blocked_tests, detection_rate, overall_score, created_by, approved_by, tags, organization_id, id, created_at, updated_at) FROM stdin;
BAS Real	Test	atomic_test	draft	lab	{}	[]	[]	\N	\N	\N	\N	0	0	0	0	\N	\N	765b349b-c587-4281-b9ce-8506bf3738a2	\N	[]	1489f1c5-9a2e-4189-8bde-89e1148ca606	10922257-87cc-400a-8818-2082ed3200ba	2026-04-06 04:06:47.396994+00	2026-04-06 04:06:47.396998+00
test	test	attack_chain	draft	production	{}	[]	[]	\N	\N	\N	\N	0	0	0	0	\N	\N	765b349b-c587-4281-b9ce-8506bf3738a2	\N	[]	1489f1c5-9a2e-4189-8bde-89e1148ca606	edfec86d-377e-4629-a425-d7372047a8c2	2026-04-06 04:09:35.988825+00	2026-04-06 04:09:35.988829+00
\.


--
-- Data for Name: attack_surfaces; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.attack_surfaces (name, surface_type, description, total_assets, exposed_assets, critical_exposures, risk_score, last_assessed_at, findings, metrics, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: attack_techniques; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.attack_techniques (mitre_id, name, tactic, description, platform, test_commands, detection_sources, expected_detection, risk_level, requires_privileges, is_safe, is_enabled, atomic_test_ref, tags, id, created_at, updated_at) FROM stdin;
T1059.001	PowerShell	Execution	Execution via PowerShell	["windows"]	[{"platform": "windows", "executor": "powershell", "command": "Get-Process | Select-Object ProcessName, Id", "cleanup": "# No cleanup needed"}]	["EDR", "Endpoint Logging"]	PowerShell process execution detected	medium	user	t	t	T1059.001-1	[]	4f57bc48-48b0-48e1-a84f-ee2937a01842	2026-04-02 03:08:28.90097+00	2026-04-02 03:08:28.900975+00
T1059.004	Unix Shell	Execution	Execution via Unix shell	["linux", "macos"]	[{"platform": "linux", "executor": "bash", "command": "ps aux | grep bash", "cleanup": "# No cleanup"}]	["Auditd", "Syslog"]	Shell command execution detected	medium	user	t	t	T1059.004-1	[]	b18e3091-2b2c-4b05-94d6-2c48d3fe2e78	2026-04-02 03:08:28.902384+00	2026-04-02 03:08:28.902388+00
T1053.005	Scheduled Task/Job	Persistence	Create scheduled task for persistence	["windows"]	[{"platform": "windows", "executor": "powershell", "command": "Get-ScheduledTask -TaskName test_task -ErrorAction SilentlyContinue", "cleanup": "Unregister-ScheduledTask -TaskName test_task -Confirm:$false -ErrorAction SilentlyContinue"}]	["Sysmon", "Windows Event Log"]	Scheduled task creation detected	high	admin	t	t	T1053.005-1	[]	ee7ef319-1245-488b-a205-fe52dd3b31af	2026-04-02 03:08:28.903578+00	2026-04-02 03:08:28.903582+00
T1547.001	Registry Run Keys / Startup Folder	Persistence	Modify registry run keys for persistence	["windows"]	[{"platform": "windows", "executor": "powershell", "command": "Get-Item 'HKLM:\\\\Software\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Run' | Select-Object Property", "cleanup": "# Removal would require admin"}]	["Sysmon", "EDR"]	Registry modification detected	high	admin	t	t	T1547.001-1	[]	8bb689f5-0d62-4c33-a01b-53b1cc0f5cbc	2026-04-02 03:08:28.904711+00	2026-04-02 03:08:28.904714+00
T1003.001	LSASS Memory Dump	Credential Access	Simulated LSASS memory dump (safe test)	["windows"]	[{"platform": "windows", "executor": "powershell", "command": "# Simulated: tasklist | findstr lsass", "cleanup": "# No cleanup"}]	["EDR", "Sysmon"]	LSASS dump attempt detected	critical	admin	t	t	T1003.001-1	[]	eb2e81cd-f68d-4321-b6ce-885de7794987	2026-04-02 03:08:28.905777+00	2026-04-02 03:08:28.90578+00
T1021.001	Remote Desktop Protocol	Lateral Movement	Test RDP lateral movement detection	["windows"]	[{"platform": "windows", "executor": "cmd", "command": "mstsc /v:127.0.0.1 /admin", "cleanup": "# Connection would close"}]	["Network IDS", "Endpoint Logging"]	RDP connection attempt detected	high	user	t	t	T1021.001-1	[]	c3837a27-ccff-46db-8975-06acb29f0a6b	2026-04-02 03:08:28.906765+00	2026-04-02 03:08:28.906769+00
T1021.006	WinRM	Lateral Movement	Test WinRM lateral movement detection	["windows"]	[{"platform": "windows", "executor": "powershell", "command": "Invoke-Command -ComputerName localhost -ScriptBlock { whoami }", "cleanup": "# No cleanup"}]	["WinRM Event Logs", "EDR"]	WinRM remote execution detected	high	admin	t	t	T1021.006-1	[]	d60919bd-231d-4ee3-af96-757ee3d12384	2026-04-02 03:08:28.907551+00	2026-04-02 03:08:28.907553+00
T1048.003	Exfiltration Over DNS	Exfiltration	Test DNS-based data exfiltration detection	["windows", "linux"]	[{"platform": "windows", "executor": "powershell", "command": "[System.Net.Dns]::GetHostByName('exfil.test.local')", "cleanup": "# No cleanup"}]	["DNS Sinkhole", "Network IDS"]	Suspicious DNS query detected	high	user	t	t	T1048.003-1	[]	8754e989-f1d4-4928-9af6-47cd42d9334b	2026-04-02 03:08:28.908193+00	2026-04-02 03:08:28.908195+00
T1071.001	Application Layer Protocol: HTTP/HTTPS	Command and Control	Test HTTP/HTTPS C2 communication detection	["windows", "linux"]	[{"platform": "windows", "executor": "powershell", "command": "Invoke-WebRequest -Uri 'http://test.local/beacon' -UseBasicParsing", "cleanup": "# No cleanup"}]	["Web Proxy", "Network IDS"]	Suspicious HTTP communication detected	high	user	t	t	T1071.001-1	[]	f410ef32-a079-47de-9e7d-9cba547289bd	2026-04-02 03:08:28.908821+00	2026-04-02 03:08:28.908823+00
T1110.001	Brute Force: Password Guessing	Credential Access	Simulated brute force password attack	["windows", "linux"]	[{"platform": "windows", "executor": "powershell", "command": "# Simulated brute force - no actual attempts", "cleanup": "# No cleanup"}]	["Auth Logs", "WAF"]	Multiple failed authentication attempts detected	high	user	t	t	T1110.001-1	[]	d2dda5db-172b-4338-a485-d2c2d7fbc24a	2026-04-02 03:08:28.909422+00	2026-04-02 03:08:28.909424+00
T1136.001	Create Account: Local Account	Persistence	Create a local user account for persistence	["windows"]	[{"platform": "windows", "executor": "powershell", "command": "Get-LocalUser | Select-Object Name", "cleanup": "# Account removal requires admin"}]	["EDR", "Event Logs"]	Local account creation detected	high	admin	t	t	T1136.001-1	[]	451c289d-52d2-4fa1-bc2c-4b282be094fa	2026-04-02 03:08:28.910022+00	2026-04-02 03:08:28.910024+00
T1070.001	Indicator Removal: Clear Windows Event Logs	Defense Evasion	Test clearing Windows Event Logs detection	["windows"]	[{"platform": "windows", "executor": "powershell", "command": "Get-EventLog -LogName Application -Newest 1", "cleanup": "# No cleanup"}]	["EDR", "SIEM"]	Event log clearing attempt detected	high	admin	t	t	T1070.001-1	[]	32546257-8437-46fd-959d-5a043917181c	2026-04-02 03:08:28.910594+00	2026-04-02 03:08:28.910596+00
T1055.001	Process Injection: Dynamic-link Library Injection	Defense Evasion	Simulated DLL injection test (safe version)	["windows"]	[{"platform": "windows", "executor": "powershell", "command": "Get-Process -Name explorer | Select-Object ProcessName, Id", "cleanup": "# No cleanup"}]	["EDR", "Sysmon"]	Process injection attempt detected	critical	admin	t	t	T1055.001-1	[]	209e3d0d-c1be-4eb9-8af4-021ffbec3384	2026-04-02 03:08:28.911197+00	2026-04-02 03:08:28.911199+00
T1027	Obfuscated Files or Information	Defense Evasion	Test obfuscated script detection	["windows"]	[{"platform": "windows", "executor": "powershell", "command": "# Base64-obfuscated command would be here in real test", "cleanup": "# No cleanup"}]	["EDR", "SIEM"]	Obfuscated command execution detected	high	user	t	t	T1027-1	[]	f50fc6a7-1569-42b4-a204-04b72b631c7f	2026-04-02 03:08:28.911805+00	2026-04-02 03:08:28.911807+00
T1082	System Information Discovery	Discovery	Discover system information	["windows", "linux"]	[{"platform": "windows", "executor": "cmd", "command": "systeminfo", "cleanup": "# No cleanup"}]	["EDR"]	System information discovery detected	low	user	t	t	T1082-1	[]	f36980c3-491b-4058-ba0a-d279de93c1eb	2026-04-02 03:08:28.912373+00	2026-04-02 03:08:28.912375+00
T1083	File and Directory Discovery	Discovery	Discover files and directories	["windows", "linux"]	[{"platform": "windows", "executor": "cmd", "command": "dir C:\\\\ /s /b", "cleanup": "# No cleanup"}]	["EDR"]	File system enumeration detected	low	user	t	t	T1083-1	[]	073f6ca5-6cf3-4f99-92e1-20ca2ab4afa4	2026-04-02 03:08:28.912957+00	2026-04-02 03:08:28.912959+00
T1018	Remote System Discovery	Discovery	Discover remote systems on network	["windows"]	[{"platform": "windows", "executor": "cmd", "command": "net view", "cleanup": "# No cleanup"}]	["Network IDS", "EDR"]	Network reconnaissance detected	medium	user	t	t	T1018-1	[]	3692cfb3-d040-4099-87bb-a0cf4b749328	2026-04-02 03:08:28.913543+00	2026-04-02 03:08:28.913546+00
T1016	System Network Configuration Discovery	Discovery	Discover network configuration	["windows", "linux"]	[{"platform": "windows", "executor": "cmd", "command": "ipconfig /all", "cleanup": "# No cleanup"}]	["EDR"]	Network configuration discovery detected	low	user	t	t	T1016-1	[]	42ffd481-0124-4945-b14b-970eb8520941	2026-04-02 03:08:28.914144+00	2026-04-02 03:08:28.914146+00
T1049	System Network Connections Discovery	Discovery	Discover active network connections	["windows", "linux"]	[{"platform": "windows", "executor": "cmd", "command": "netstat -ano", "cleanup": "# No cleanup"}]	["EDR"]	Network connection enumeration detected	low	user	t	t	T1049-1	[]	898ecaa4-ed94-4803-b064-fb132224cd61	2026-04-02 03:08:28.914748+00	2026-04-02 03:08:28.91475+00
T1057	Process Discovery	Discovery	Discover running processes	["windows", "linux"]	[{"platform": "windows", "executor": "cmd", "command": "tasklist /v", "cleanup": "# No cleanup"}]	["EDR"]	Process enumeration detected	low	user	t	t	T1057-1	[]	cccca7a5-7fe4-42e6-b132-833d1afdd4f4	2026-04-02 03:08:28.915321+00	2026-04-02 03:08:28.915323+00
\.


--
-- Data for Name: attack_trees; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.attack_trees (organization_id, model_id, name, description, root_goal, tree_structure, total_attack_paths, minimum_cost_path_usd, minimum_skill_path, highest_probability_path, generated_from_stride, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.audit_logs (user_id, action, resource_type, resource_id, description, old_value, new_value, ip_address, user_agent, request_id, success, error_message, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_trails; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.audit_trails (event_type, action, actor_type, actor_id, actor_ip, resource_type, resource_id, description, old_value, new_value, result, risk_level, session_id, request_id, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: automated_evidence_rules; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.automated_evidence_rules (name, control_ids, evidence_type, collection_method, collection_config, schedule, is_enabled, last_collected_at, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: automation_rules; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.automation_rules (name, description, is_enabled, trigger_type, trigger_conditions, actions, priority, cooldown_minutes, last_triggered_at, execution_count, created_by, organization_id, id, created_at, updated_at) FROM stdin;
test	\N	f	siem_alert	"{}"	"{}"	0	0	\N	0	765b349b-c587-4281-b9ce-8506bf3738a2	1489f1c5-9a2e-4189-8bde-89e1148ca606	45946651-ffff-496e-8f85-589e5f804a9d	2026-04-06 11:45:41.736217+00	2026-04-06 11:45:52.31844+00
\.


--
-- Data for Name: behavior_baselines; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.behavior_baselines (entity_profile_id, behavior_type, baseline_period_days, statistical_model, typical_values, time_patterns, peer_comparison, confidence, sample_count, last_updated_at, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: behavior_events; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.behavior_events (entity_profile_id, event_type, event_data, source_ip, destination, geo_location, device_info, risk_contribution, is_anomalous, anomaly_reasons, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: business_impact_assessments; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.business_impact_assessments (organization_id, asset_name, asset_type, business_unit, criticality, rto_hours, rpo_hours, mtpd_hours, financial_impact_per_hour_usd, reputational_impact_score, regulatory_impact_score, dependencies, single_point_of_failure, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: campaign_events; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.campaign_events (campaign_id, target_email, target_name, event_type, event_timestamp, ip_address, user_agent, geo_location, device_type, time_to_action_seconds, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: case_attachments; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.case_attachments (filename, original_filename, file_path, file_size, mime_type, file_hash, attachment_type, description, is_malware, is_encrypted, incident_id, uploaded_by, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: case_notes; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.case_notes (content, note_type, is_internal, is_pinned, incident_id, author_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: case_tasks; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.case_tasks (title, description, status, priority, due_date, completed_at, incident_id, assigned_to, created_by, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: case_timeline; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.case_timeline (event_type, title, description, old_value, new_value, event_metadata, incident_id, actor_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cisa_directives; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.cisa_directives (directive_id, title, description, directive_type, effective_date, compliance_deadline, status, requirements, compliance_status, actions_taken, evidence_ids, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: compliance_assessments; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.compliance_assessments (framework_id, assessment_type, assessor, assessment_date, status, scope, findings_count, satisfied_count, other_than_satisfied_count, overall_result, report_path, next_steps, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: compliance_controls; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.compliance_controls (framework_id, control_id, control_family, title, description, priority, baseline, status, implementation_status, implementation_details, responsible_party, assessment_method, assessment_frequency, last_assessed_at, last_assessment_result, evidence_ids, related_controls, mitre_techniques, automated_check_id, risk_if_not_implemented, remediation_guidance, poam_id, tags, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: compliance_evidence; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.compliance_evidence (control_id_ref, evidence_type, title, description, file_path, file_hash, content, source_system, collected_at, collected_by, is_automated, is_valid, expires_at, review_status, reviewed_by, reviewed_at, tags, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: compliance_frameworks; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.compliance_frameworks (name, short_name, version, description, authority, total_controls, implemented_controls, compliance_score, status, last_assessment_at, next_assessment_due, certification_level, is_enabled, extra_metadata, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: consent_records; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.consent_records (organization_id, subject_id, purpose, legal_basis, consent_given, consent_date, withdrawal_date, consent_mechanism, evidence_location, granularity, version, privacy_policy_version, id, created_at, updated_at) FROM stdin;
1489f1c5-9a2e-4189-8bde-89e1148ca606	user123	marketing	consent	t	2026-04-06T01:07:10.420793+00:00	\N	explicit_opt_in	\N	\N	1	\N	e38db598-ef51-4926-ac64-7546defbb2e8	2026-04-06 01:07:10.422877+00	2026-04-06 01:07:10.42288+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	final	ops	consent	t	2026-04-06T01:13:12.466472+00:00	\N	explicit_opt_in	\N	\N	1	\N	fdeed6ff-ca78-4429-bda6-2932eeaa5856	2026-04-06 01:13:12.468547+00	2026-04-06 01:13:12.468551+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	z	ops	consent	t	2026-04-06T01:30:07.430855+00:00	\N	explicit_opt_in	\N	\N	1	\N	aa3d41fb-cf09-49ae-ab11-9c14eb135c3d	2026-04-06 01:30:07.432898+00	2026-04-06 01:30:07.432902+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	f	o	consent	t	2026-04-06T01:39:38.242535+00:00	\N	explicit_opt_in	\N	\N	1	\N	52ec1b79-1b7b-4c3d-be61-a7b19762e255	2026-04-06 01:39:38.244556+00	2026-04-06 01:39:38.244561+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	user1	marketing	consent	t	2026-04-07T03:20:56.666429+00:00	\N	explicit_opt_in	\N	\N	1	\N	7904cc80-915f-436d-b79e-7467a888a96c	2026-04-07 03:20:56.668599+00	2026-04-07 03:20:56.668604+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	u1	mkt	consent	t	2026-04-07T03:28:46.013296+00:00	\N	explicit_opt_in	\N	\N	1	\N	9cb58d1e-7d80-4df0-8a27-4fe4bda9ac39	2026-04-07 03:28:46.015376+00	2026-04-07 03:28:46.01538+00
\.


--
-- Data for Name: container_images; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.container_images (registry, repository, tag, digest_sha256, image_size_mb, os, architecture, created_at_source, scanned_at, vulnerability_count_critical, vulnerability_count_high, vulnerability_count_medium, vulnerability_count_low, is_signed, signature_verified, base_image, sbom_generated, compliance_status, risk_score, labels, last_deployed, organization_id, id, created_at, updated_at) FROM stdin;
docker.io	alpine	3	sha256:aaaa567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef	\N	\N	\N	\N	2026-04-06 01:03:43.281885+00	0	0	0	0	f	f	\N	f	not_scanned	0	{}	\N	1489f1c5-9a2e-4189-8bde-89e1148ca606	18802eb6-24fd-418f-81ea-ff4d4fa8756c	2026-04-06 01:03:43.281918+00	2026-04-06 01:03:43.28192+00
ghcr.io	python	3.12	sha256:bbbb567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef	\N	\N	\N	\N	2026-04-06 01:10:48.463317+00	0	0	0	0	f	f	\N	f	not_scanned	0	{}	\N	1489f1c5-9a2e-4189-8bde-89e1148ca606	746a1b31-0b2b-46d4-bbe6-20e643258442	2026-04-06 01:10:48.463345+00	2026-04-06 01:10:48.463346+00
docker.io	ubuntu	22.04	sha256:cccc567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef	\N	\N	\N	\N	2026-04-06 01:13:14.235352+00	0	0	0	0	f	f	\N	f	not_scanned	0	{}	\N	1489f1c5-9a2e-4189-8bde-89e1148ca606	561b914c-9015-4b37-91a4-864ce7d7f42c	2026-04-06 01:13:14.235382+00	2026-04-06 01:13:14.235383+00
docker.io	busybox	1	sha256:zzzz567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef	\N	\N	\N	\N	2026-04-06 01:30:09.205313+00	0	0	0	0	f	f	\N	f	not_scanned	0	{}	\N	1489f1c5-9a2e-4189-8bde-89e1148ca606	cbf79504-334e-48ec-beff-a6a29b2d305d	2026-04-06 01:30:09.205344+00	2026-04-06 01:30:09.205346+00
docker.io	debian	12	sha256:ffff567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef	\N	\N	\N	\N	2026-04-06 01:39:39.898501+00	0	0	0	0	f	f	\N	f	not_scanned	0	{}	\N	1489f1c5-9a2e-4189-8bde-89e1148ca606	17076688-d77d-4577-8bd5-41c961f66fc2	2026-04-06 01:39:39.898528+00	2026-04-06 01:39:39.898529+00
\.


--
-- Data for Name: correlation_events; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.correlation_events (correlation_id, name, description, severity, rule_id, log_entry_ids, source_addresses, usernames, hostnames, timespan_start, timespan_end, event_count, mitre_tactics, mitre_techniques, alert_generated, alert_id, status, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: credential_exposures; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.credential_exposures (organization_id, identity_id, exposure_source, credential_type, exposure_date, discovery_date, breach_name, is_remediated, remediation_date, remediation_action, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cui_markings; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.cui_markings (asset_id, asset_type, cui_category, cui_designation, dissemination_controls, handling_instructions, classification_authority, declassification_date, access_list, is_active, organization_id, id, created_at, updated_at) FROM stdin;
				[]	\N		\N	[]	t	1489f1c5-9a2e-4189-8bde-89e1148ca606	c02f1603-193d-4088-8a06-a6a84185f12a	2026-04-07 23:45:11.65552+00	2026-04-07 23:45:11.655525+00
\.


--
-- Data for Name: darkweb_brand_threats; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.darkweb_brand_threats (organization_id, finding_id, threat_type, target_brand, target_domain, malicious_domain, registrar, registration_date, ssl_certificate_info, takedown_status, takedown_provider, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: darkweb_credential_leaks; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.darkweb_credential_leaks (organization_id, finding_id, email, username, password_hash, password_type, breach_source, breach_date, is_valid, is_remediated, remediation_action, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: darkweb_findings; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.darkweb_findings (organization_id, monitor_id, finding_type, source_platform, source_url_hash, title, description, raw_data_hash, affected_assets, affected_count, severity, confidence_score, status, discovered_date, analyst_notes, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: darkweb_monitors; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.darkweb_monitors (organization_id, name, description, monitor_type, search_terms, domains_watched, emails_watched, enabled, alert_severity, last_check, findings_count, id, created_at, updated_at) FROM stdin;
1489f1c5-9a2e-4189-8bde-89e1148ca606	Z	\N	keyword	null	null	null	t	high	\N	0	7ac5437e-5ca9-4df6-af92-f3a1e1f27b41	2026-04-06 01:30:10.880039+00	2026-04-06 01:30:10.880044+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	F	\N	keyword	null	null	null	t	high	\N	0	d8df8c4a-4722-4738-b013-6e8b95182efd	2026-04-06 01:39:41.443242+00	2026-04-06 01:39:41.443247+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	Test Monitor	\N	keyword	null	null	null	t	high	\N	0	da0d1f7d-24e4-415e-896c-71dd7eba6b75	2026-04-07 03:42:34.196874+00	2026-04-07 03:42:34.196879+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	pysoar	\N	keyword	null	null	null	t	high	\N	0	3c5374f2-a45a-438b-96aa-d0c69a12ee52	2026-04-07 04:12:13.891894+00	2026-04-07 04:12:13.8919+00
\.


--
-- Data for Name: data_classifications; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.data_classifications (organization_id, name, classification_level, description, handling_rules, retention_days, encryption_required, dlp_policies, auto_classification_rules, color_code, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: data_partitions; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.data_partitions (organization_id, source_id, partition_key, time_range_start, time_range_end, record_count, size_bytes, storage_tier, format, compression, location, is_indexed, index_columns, query_count_30d, last_accessed, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: data_pipelines; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.data_pipelines (organization_id, name, description, pipeline_type, source_id, destination, transform_rules, schedule_cron, status, last_run, next_run, avg_processing_time_ms, records_processed_total, error_count, last_error, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: data_processing_records; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.data_processing_records (organization_id, name, purpose, legal_basis, data_categories, data_subjects, recipients, cross_border_transfers, retention_period_days, technical_measures, organizational_measures, dpo_contact, processor_agreements, last_reviewed, id, created_at, updated_at) FROM stdin;
1489f1c5-9a2e-4189-8bde-89e1148ca606	SaveROPA	analytics	consent	["email"]	\N	\N	\N	\N	\N	\N	\N	\N	\N	02fc341b-933c-4479-93a8-1ba96ca0357f	2026-04-06 01:06:57.199225+00	2026-04-06 01:06:57.19923+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	Test	analytics	consent	["email"]	\N	\N	\N	\N	\N	\N	\N	\N	\N	f67d661a-d817-4f8e-a6f1-1612aa7d4b83	2026-04-06 01:07:32.327346+00	2026-04-06 01:07:32.327349+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	TestROPA	analytics	consent	["email", "name"]	\N	\N	\N	\N	\N	\N	\N	\N	\N	3db72469-7d9a-40f2-9d83-1de8af080ea6	2026-04-06 01:10:46.617792+00	2026-04-06 01:10:46.617797+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	FinalROPA	ops	consent	["email"]	\N	\N	\N	\N	\N	\N	\N	\N	\N	25b02f30-8a9b-4e92-96f3-a210fe7d52bf	2026-04-06 01:13:12.743332+00	2026-04-06 01:13:12.743336+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	Z	ops	consent	["email"]	\N	\N	\N	\N	\N	\N	\N	\N	\N	cee86df4-4f41-4cb5-bdf7-0c6babf02048	2026-04-06 01:30:07.706658+00	2026-04-06 01:30:07.706665+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	F	o	consent	["email"]	\N	\N	\N	\N	\N	\N	\N	\N	\N	c79030eb-7889-4c59-8a30-789c7f290ed7	2026-04-06 01:39:38.496568+00	2026-04-06 01:39:38.496572+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	test	test	consent	["test"]	\N	\N	\N	\N	\N	\N	\N	\N	\N	37d9d544-1a8c-4912-9182-60f7107731dc	2026-04-06 11:52:56.948831+00	2026-04-06 11:52:56.948835+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	Test	analytics	consent	["email"]	\N	\N	\N	\N	\N	\N	\N	\N	\N	e82f2ef3-3a90-4536-bf66-5ba352987e31	2026-04-07 03:20:57.044572+00	2026-04-07 03:20:57.044577+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	T	a	consent	["email"]	\N	\N	\N	\N	\N	\N	\N	\N	\N	26e2a900-2b5e-4585-8a1a-dc73e589e711	2026-04-07 03:28:46.327494+00	2026-04-07 03:28:46.327498+00
\.


--
-- Data for Name: data_sources; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.data_sources (organization_id, name, source_type, description, connection_config_encrypted, ingestion_type, format, schema_definition, normalization_mapping, status, ingestion_rate_eps, total_events_ingested, storage_size_bytes, retention_days, last_event_received, last_error, is_enabled, id, created_at, updated_at) FROM stdin;
1489f1c5-9a2e-4189-8bde-89e1148ca606	Test Source	syslog	\N	{}	batch	json	{}	{}	initializing	\N	0	0	90	\N	\N	t	6b102418-4d91-4f01-8873-17211a85c1c9	2026-04-08 01:38:09.685991+00	2026-04-08 01:38:09.685996+00
\.


--
-- Data for Name: data_subject_requests; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.data_subject_requests (organization_id, request_type, regulation, status, subject_name, subject_email, subject_identifier, deadline, response_sent, data_systems_searched, data_found, denial_reason, processing_notes, id, created_at, updated_at) FROM stdin;
1489f1c5-9a2e-4189-8bde-89e1148ca606	access	gdpr	received	John Doe	john@example.com	\N	2026-05-06T00:54:12.370831+00:00	\N	\N	\N	\N	\N	9e2af4bf-7e94-453b-909c-944786b67b0c	2026-04-06 00:54:12.373918+00	2026-04-06 00:54:12.373924+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	access	gdpr	received	Test	test@test.com	\N	2026-05-06T01:06:56.510122+00:00	\N	\N	\N	\N	\N	ffafbc6a-6e73-4584-b742-2b0a077fedb7	2026-04-06 01:06:56.511762+00	2026-04-06 01:06:56.511766+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	erasure	gdpr	received	Final	final@test.com	\N	2026-05-06T01:13:11.928592+00:00	\N	\N	\N	\N	\N	169ace66-e017-4b49-9bc6-e63acb9d4fe5	2026-04-06 01:13:11.932414+00	2026-04-06 01:13:11.932419+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	access	gdpr	received	Z	z@z.com	\N	2026-05-06T01:30:06.891777+00:00	\N	\N	\N	\N	\N	da82219a-9e73-4c10-8ff9-2ffb03c06c39	2026-04-06 01:30:06.895654+00	2026-04-06 01:30:06.895659+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	access	gdpr	received	F	f@f.com	\N	2026-05-06T01:39:37.764809+00:00	\N	\N	\N	\N	\N	9a0096db-958a-460e-b2aa-6de28a407669	2026-04-06 01:39:37.766641+00	2026-04-06 01:39:37.766645+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	access	gdpr	received	Test	jacobspeart@gmail.com	test	2026-05-06T11:51:36.398722+00:00	\N	\N	\N	\N	\N	9bb98460-66c5-4d1d-98e2-503357975ae0	2026-04-06 11:51:36.400454+00	2026-04-06 11:51:36.400458+00
\.


--
-- Data for Name: deception_campaigns; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.deception_campaigns (name, description, status, objective, decoy_ids, coverage_zones, total_interactions, unique_attackers, started_at, completed_at, findings, effectiveness_score, created_by, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: decoy_interactions; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.decoy_interactions (decoy_id, interaction_type, source_ip, source_port, source_hostname, source_user, protocol, credentials_captured, commands_captured, payloads_captured, files_accessed, session_duration_seconds, geo_location, threat_assessment, is_automated_scan, raw_traffic, alert_generated, alert_id, mitre_techniques, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: decoys; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.decoys (name, decoy_type, category, status, deployment_target, configuration, emulated_service, emulated_os, ip_address, hostname, fidelity_level, interaction_count, last_interaction_at, alert_on_interaction, capture_credentials, capture_payloads, deployed_at, deployed_by, tags, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: detection_rules; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.detection_rules (name, title, description, author, status, severity, log_types, detection_logic, condition, timewindow, threshold, group_by, mitre_tactics, mitre_techniques, tags, false_positive_notes, "references", rule_yaml, enabled, last_matched_at, match_count, organization_id, id, created_at, updated_at) FROM stdin;
brute-force-ssh	Brute Force SSH	Detect multiple failed SSH logins	\N	active	high	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2	\N	afdfb5cb-1f8f-49c2-9a72-da5769996f57	2026-02-04 23:40:34.381363+00	2026-03-31 03:11:42.381367+00
dns-c2-detection	DNS to C2 Domain	Alert on DNS queries to known C2 domains	\N	active	critical	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	27	\N	d058118e-b19d-4976-b7c5-0731acdba5bf	2026-03-15 13:51:43.381454+00	2026-03-31 03:11:42.381457+00
port-scan-detect	Port Scan Detection	Detect horizontal port scanning	\N	active	medium	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	32	\N	df8fef7a-2f9d-40e7-a766-da9074d5278f	2026-03-04 14:11:20.38151+00	2026-03-31 03:11:42.381513+00
priv-esc-detect	Privilege Escalation	Detect privilege escalation attempts	\N	active	critical	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	47	\N	a226e4ad-9ff8-4f02-9c28-c513e97c5224	2026-03-29 05:40:22.381572+00	2026-03-31 03:11:42.381575+00
data-exfil-detect	Data Exfiltration	Large outbound data transfers	\N	active	high	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	19	\N	fb65ce04-73b3-4d3b-ab6a-57f2da94f7d7	2026-02-24 11:54:25.381631+00	2026-03-31 03:11:42.381634+00
off-hours-login	Suspicious Login Hours	Login outside business hours	\N	active	low	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	48	\N	0b96a7f7-2eef-4003-969e-071a26009c47	2026-02-27 19:55:28.381704+00	2026-03-31 03:14:17.551208+00
\.


--
-- Data for Name: device_trust_profiles; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.device_trust_profiles (device_id, device_type, hostname, os_type, os_version, trust_score, trust_level, compliance_status, last_patch_date, encryption_enabled, antivirus_active, firewall_enabled, jailbroken, certificate_valid, last_seen_at, last_assessment_at, risk_factors, owner_id, enrolled_at, tags, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: dlp_incidents; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.dlp_incidents (organization_id, violation_ids, incident_title, description, severity, status, affected_data_subjects_count, data_types_involved, regulatory_implications, breach_notification_required, notification_deadline, notification_sent, incident_commander, remediation_steps, lessons_learned, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: dlp_policies; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.dlp_policies (organization_id, name, description, policy_type, severity, enabled, data_patterns, file_types_monitored, channels_monitored, response_actions, exceptions, last_triggered, trigger_count, id, created_at, updated_at) FROM stdin;
1489f1c5-9a2e-4189-8bde-89e1148ca606	Test DLP Policy	Block SSN exfiltration	custom_pattern	high	t	\N	\N	\N	\N	\N	\N	0	496e8866-4eed-4531-bd5f-4e825978d681	2026-04-06 00:54:13.21339+00	2026-04-06 00:54:13.213396+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	DLP2	Test	custom_pattern	high	t	\N	\N	\N	\N	\N	\N	0	87d35ed6-008f-4109-9aae-16d114bf9bac	2026-04-06 01:10:47.992802+00	2026-04-06 01:10:47.992808+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	FinalDLP	t	custom_pattern	high	t	\N	\N	\N	\N	\N	\N	0	2470f9cb-c762-4b6b-b433-0709db548b88	2026-04-06 01:13:14.537192+00	2026-04-06 01:13:14.537197+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	Z	t	custom_pattern	high	t	\N	\N	\N	\N	\N	\N	0	afac69ae-a0eb-4b61-9495-061e67a5ff8c	2026-04-06 01:30:09.770037+00	2026-04-06 01:30:09.770043+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	F	t	custom_pattern	high	t	\N	\N	\N	\N	\N	\N	0	381ddb93-d8ff-4f28-b3f0-ca363906bb07	2026-04-06 01:39:40.3644+00	2026-04-06 01:39:40.364406+00
\.


--
-- Data for Name: dlp_violations; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.dlp_violations (organization_id, policy_id, violation_type, severity, source_user, source_device, source_application, destination, data_classification, sensitive_data_types, file_name, file_hash, data_volume_bytes, action_taken, status, justification, reviewed_by, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: entity_profiles; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.entity_profiles (entity_type, entity_id, display_name, department, role, manager, peer_group, risk_score, risk_level, baseline_data, current_behavior, anomaly_count_30d, last_activity_at, last_anomaly_at, is_watched, watch_reason, tags, extra_metadata, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: evidence_packages; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.evidence_packages (name, description, package_type, framework_id, status, evidence_items, control_mappings, assessor, due_date, submitted_at, package_hash, extra_metadata, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: exposure_assets; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.exposure_assets (hostname, ip_address, mac_address, asset_type, os_type, os_version, environment, criticality, business_unit, owner, location, cloud_provider, cloud_region, cloud_account_id, cloud_resource_id, is_internet_facing, is_active, last_seen, last_scan_at, services, software_inventory, tags, risk_score, vulnerability_count, open_ports, network_zone, compliance_status, extra_metadata, organization_id, id, created_at, updated_at) FROM stdin;
\N	10.0.77.3	\N	server	\N	\N	production	medium	\N	\N	\N	\N	\N	\N	\N	f	t	\N	\N	[]	[]	[]	0	0	[]	\N	{}	{}	1489f1c5-9a2e-4189-8bde-89e1148ca606	4250d0aa-61db-43d7-a0cb-89b19623c9d2	2026-04-06 01:38:37.810455+00	2026-04-06 01:38:37.810461+00
\N	10.0.77.4	\N	server	\N	\N	production	medium	\N	\N	\N	\N	\N	\N	\N	f	t	\N	\N	[]	[]	[]	0	0	[]	\N	{}	{}	1489f1c5-9a2e-4189-8bde-89e1148ca606	2086d442-7099-4827-854a-68a2b26d4ed0	2026-04-06 01:39:41.932893+00	2026-04-06 01:39:41.932898+00
\.


--
-- Data for Name: exposure_scans; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.exposure_scans (scan_type, scan_name, status, target_assets, scanner, scan_profile, started_at, completed_at, total_hosts, hosts_scanned, vulnerabilities_found, critical_count, high_count, medium_count, low_count, error_message, results_summary, initiated_by, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: exposure_vulnerabilities; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.exposure_vulnerabilities (cve_id, title, description, severity, cvss_v3_score, cvss_v3_vector, cvss_v2_score, epss_score, epss_percentile, is_exploited_in_wild, exploit_available, exploit_maturity, affected_products, affected_versions, patch_available, patch_url, vendor_advisory_url, "references", mitre_techniques, published_at, modified_at, tags, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fair_analyses; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.fair_analyses (organization_id, scenario_id, tef_min, tef_mode, tef_max, vuln_min, vuln_mode, vuln_max, tcap_min, tcap_mode, tcap_max, rs_min, rs_mode, rs_max, lm_min, lm_mode, lm_max, primary_loss_min, primary_loss_mode, primary_loss_max, secondary_loss_min, secondary_loss_mode, secondary_loss_max, secondary_loss_event_frequency, simulation_iterations, ale_mean, ale_p10, ale_p50, ale_p90, ale_p99, loss_exceedance_curve, completed_at, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: forensic_artifacts; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.forensic_artifacts (case_id, evidence_id, artifact_type, artifact_data, analysis_notes, ioc_extracted, mitre_mapping, risk_score, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: forensic_cases; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.forensic_cases (case_number, title, description, case_type, status, severity, lead_investigator_id, assigned_team, legal_hold_active, chain_of_custody_hash, classification_level, court_admissible, created_by, organization_id, id, created_at, updated_at) FROM stdin;
C03	Test	Test	incident_response	open	high	\N	\N	f	\N	\N	f	\N	1489f1c5-9a2e-4189-8bde-89e1148ca606	85da9170-7c4e-4a86-a950-fdb04d2fe2d0	2026-04-06 01:10:48.235639+00	2026-04-06 01:10:48.235644+00
FIN01	FinalCase	t	incident_response	open	high	\N	\N	f	\N	\N	f	\N	1489f1c5-9a2e-4189-8bde-89e1148ca606	6adde5f8-bb57-443f-8f13-7945d18e0e4e	2026-04-06 01:13:14.774607+00	2026-04-06 01:13:14.774612+00
Z01	Z	t	incident_response	open	high	\N	\N	f	\N	\N	f	\N	1489f1c5-9a2e-4189-8bde-89e1148ca606	8d57fcb2-295f-45f6-8c2c-6b12fa8eb81f	2026-04-06 01:30:10.055538+00	2026-04-06 01:30:10.055544+00
F01	F	t	incident_response	open	high	\N	\N	f	\N	\N	f	\N	1489f1c5-9a2e-4189-8bde-89e1148ca606	7edc6111-b8e0-43a6-933d-b63fdb236aa0	2026-04-06 01:39:40.685044+00	2026-04-06 01:39:40.68505+00
1245362	Test	test	insider_threat	open	medium	\N	\N	f	\N	\N	f	\N	1489f1c5-9a2e-4189-8bde-89e1148ca606	47021431-1d8e-4358-b6b1-da3f2047f192	2026-04-07 12:06:46.059225+00	2026-04-07 12:06:46.059231+00
\.


--
-- Data for Name: forensic_evidence; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.forensic_evidence (case_id, evidence_type, source_device, source_ip, acquisition_method, original_hash_md5, original_hash_sha256, chain_of_custody_log, storage_location, file_size_bytes, is_verified, verified_by, verification_date, handling_notes, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: forensic_timeline; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.forensic_timeline (case_id, event_timestamp, event_type, source, source_evidence_id, description, artifact_data, mitre_technique_id, severity_score, is_pivotal, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: honey_tokens; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.honey_tokens (name, token_type, token_value, token_hash, deployment_location, deployment_context, status, triggered_count, last_triggered_at, last_triggered_by, expires_at, alert_severity, notification_channels, deployed_by, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: hunt_findings; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.hunt_findings (session_id, title, description, severity, classification, evidence, affected_assets, iocs_found, mitre_techniques, log_entry_ids, analyst_notes, escalated_to_case, case_id, created_by, id, created_at, updated_at) FROM stdin;
50b901de-d46a-439d-b6be-74d712c372fb	Lateral movement detected	Finding: Lateral movement detected	CRITICAL	NEEDS_REVIEW	"[{\\"type\\": \\"log\\"}]"	"[\\"dc01\\"]"	"[\\"192.168.1.100\\"]"	"[\\"T1021\\"]"	\N	\N	f	\N	\N	b08b9e6b-8d06-4ac7-a128-e8d17664e644	2026-04-01 07:16:38.338902+00	2026-04-02 00:16:38.338907+00
36bc8f8f-3b69-4797-8b89-6b05c157ec10	Failed auth attempts	Finding: Failed auth attempts	MEDIUM	NEEDS_REVIEW	"[{\\"type\\": \\"log\\"}]"	"[\\"dc01\\"]"	"[\\"192.168.1.100\\"]"	"[\\"T1021\\"]"	\N	\N	t	a777d76b-951a-422e-b994-d91f90cfc5a8	\N	70276972-9d02-40bc-bed5-64daf10ed1f9	2026-04-01 22:16:38.338964+00	2026-04-02 21:03:56.797401+00
50b901de-d46a-439d-b6be-74d712c372fb	Suspicious RDP connections	Finding: Suspicious RDP connections	HIGH	CONFIRMED	"[{\\"type\\": \\"log\\"}]"	"[\\"dc01\\"]"	"[\\"192.168.1.100\\"]"	"[\\"T1021\\"]"	\N	\N	t	fb9aa79e-dcae-4659-b1df-cd7c8002eb18	\N	4a0eeccf-d271-44d6-8ffb-a8fb5d76c801	2026-04-01 17:16:38.33875+00	2026-04-02 21:04:00.072422+00
\.


--
-- Data for Name: hunt_hypotheses; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.hunt_hypotheses (title, description, status, priority, hunt_type, mitre_tactics, mitre_techniques, data_sources, expected_evidence, tags, created_by, assigned_to, id, created_at, updated_at) FROM stdin;
APT lateral movement via RDP	RDP lateral movement	ACTIVE	HIGH	threat_based	"[\\"TA0008\\"]"	"[\\"T1021\\"]"	"[\\"siem\\"]"	\N	\N	765b349b-c587-4281-b9ce-8506bf3738a2	\N	52a0fb67-676e-4e9e-b7d6-cfa10a5b2b51	2026-03-10 00:16:38.328878+00	2026-04-02 00:16:38.328898+00
DNS tunneling exfiltration	DNS data exfil	ACTIVE	HIGH	threat_based	"[\\"TA0008\\"]"	"[\\"T1021\\"]"	"[\\"siem\\"]"	\N	\N	765b349b-c587-4281-b9ce-8506bf3738a2	\N	4b400975-2c29-4314-83c0-4165220747dd	2026-03-22 00:16:38.329058+00	2026-04-02 00:16:38.329062+00
Credential harvesting LSASS	LSASS memory dump	DRAFT	CRITICAL	intelligence_driven	"[\\"TA0008\\"]"	"[\\"T1021\\"]"	"[\\"siem\\"]"	\N	\N	765b349b-c587-4281-b9ce-8506bf3738a2	\N	f5f6117f-cf2d-4098-8b98-53cf6f7a0b73	2026-03-22 00:16:38.329164+00	2026-04-02 00:16:38.329169+00
Supply chain npm compromise	Malicious npm	ACTIVE	MEDIUM	data_driven	"[\\"TA0008\\"]"	"[\\"T1021\\"]"	"[\\"siem\\"]"	\N	\N	765b349b-c587-4281-b9ce-8506bf3738a2	\N	590266ea-f0f1-4f95-8b04-4be70f02e575	2026-03-15 00:16:38.329216+00	2026-04-02 00:16:38.32922+00
T	T	DRAFT	3	behavioral	null	null	null	\N	null	765b349b-c587-4281-b9ce-8506bf3738a2	\N	ef709d3d-a631-4772-9fc7-a7cba5a1542d	2026-04-06 01:03:42.830364+00	2026-04-06 01:03:42.830369+00
SaveTest	test	DRAFT	2	behavioral	null	null	null	\N	null	765b349b-c587-4281-b9ce-8506bf3738a2	\N	e7368fdb-27c6-410a-91e4-05d2fdecde28	2026-04-06 01:06:37.057654+00	2026-04-06 01:06:37.057659+00
FinalH	test	DRAFT	2	behavioral	null	null	null	\N	null	765b349b-c587-4281-b9ce-8506bf3738a2	\N	0e1fa8dc-6f7a-4203-9f6a-de9321ef850f	2026-04-06 01:13:11.153876+00	2026-04-06 01:13:11.153882+00
F	t	DRAFT	2	behavioral	null	null	null	\N	null	765b349b-c587-4281-b9ce-8506bf3738a2	\N	59a77a48-f1aa-4311-9998-a2503d196f38	2026-04-06 01:39:37.065157+00	2026-04-06 01:39:37.065164+00
Z	t	ACTIVE	2	behavioral	null	null	null	\N	null	765b349b-c587-4281-b9ce-8506bf3738a2	\N	b67d0324-a378-482a-903d-74e3d8ad31ca	2026-04-06 01:30:06.071852+00	2026-04-07 11:57:32.220056+00
\.


--
-- Data for Name: hunt_notebooks; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.hunt_notebooks (session_id, title, content, version, is_published, published_at, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: hunt_sessions; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.hunt_sessions (hypothesis_id, status, started_at, completed_at, duration_seconds, query_count, events_analyzed, findings_count, queries_executed, parameters, error_message, created_by, id, created_at, updated_at) FROM stdin;
52a0fb67-676e-4e9e-b7d6-cfa10a5b2b51	COMPLETED	2026-03-31 19:16:38.334632+00	2026-04-02 00:16:38.334649+00	2700	2	4045	4	\N	\N	\N	765b349b-c587-4281-b9ce-8506bf3738a2	50b901de-d46a-439d-b6be-74d712c372fb	2026-04-01 05:16:38.33466+00	2026-04-02 00:16:38.334663+00
52a0fb67-676e-4e9e-b7d6-cfa10a5b2b51	COMPLETED	2026-04-01 12:16:38.334851+00	2026-04-02 00:16:38.334854+00	7200	5	3986	3	\N	\N	\N	765b349b-c587-4281-b9ce-8506bf3738a2	36bc8f8f-3b69-4797-8b89-6b05c157ec10	2026-03-31 11:16:38.334857+00	2026-04-02 00:16:38.334859+00
f5f6117f-cf2d-4098-8b98-53cf6f7a0b73	CANCELLED	\N	2026-04-02 21:03:06.515172+00	\N	0	0	0	\N	null	\N	765b349b-c587-4281-b9ce-8506bf3738a2	751ad810-1446-4eb3-bea1-9fce56f8cc97	2026-04-02 20:57:48.127811+00	2026-04-02 21:03:06.515901+00
4b400975-2c29-4314-83c0-4165220747dd	CANCELLED	\N	2026-04-02 21:03:10.237731+00	\N	0	0	0	\N	null	\N	765b349b-c587-4281-b9ce-8506bf3738a2	43d1b6b8-b9b9-41b5-8729-28ea98c60e8d	2026-04-02 04:14:40.216718+00	2026-04-02 21:03:10.238056+00
b67d0324-a378-482a-903d-74e3d8ad31ca	PENDING	\N	\N	\N	0	0	0	\N	null	\N	765b349b-c587-4281-b9ce-8506bf3738a2	0400e2ce-2abd-42ae-8b29-ab2210e121c0	2026-04-07 11:57:35.830202+00	2026-04-07 11:57:35.830208+00
4b400975-2c29-4314-83c0-4165220747dd	PAUSED	2026-03-31 02:16:38.334798+00	\N	\N	5	3602	0	\N	\N	\N	765b349b-c587-4281-b9ce-8506bf3738a2	43874d83-a037-4cf4-899e-9e11402fba6e	2026-03-31 17:16:38.334806+00	2026-04-07 11:57:45.595754+00
\.


--
-- Data for Name: hunt_templates; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.hunt_templates (name, description, category, hunt_type, hypothesis_template, default_queries, mitre_tactics, mitre_techniques, data_sources_required, estimated_duration_minutes, difficulty, tags, is_builtin, enabled, id, created_at, updated_at) FROM stdin;
Lateral Movement Hunt	RDP/SMB hunt	lateral_movement	threat_based	\N	\N	\N	\N	\N	\N	intermediate	\N	f	t	e8f27899-0220-45ce-97cf-05d348cd6e3f	2026-02-01 00:16:38.339013+00	2026-04-02 00:16:38.339016+00
Data Exfil Detection	Outbound transfer hunt	exfiltration	threat_based	\N	\N	\N	\N	\N	\N	intermediate	\N	f	t	bd9cd30a-88f7-476d-934a-16a59855f717	2026-02-01 00:16:38.339076+00	2026-04-02 00:16:38.339078+00
\.


--
-- Data for Name: identified_threats; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.identified_threats (organization_id, model_id, component_id, stride_category, pasta_stage, threat_description, attack_vector, preconditions, impact_description, likelihood, impact, risk_score, mitre_technique_ids, cwe_ids, status, priority, id, created_at, updated_at) FROM stdin;
1489f1c5-9a2e-4189-8bde-89e1148ca606	8d23aef0-956a-453e-be24-532afd3b263d	\N	tampering	\N	SQL injection attack	\N	\N	\N	high	high	16	null	null	identified	3	da64764c-4918-4e4e-a3ad-bfeb79c195d0	2026-04-07 03:28:45.349352+00	2026-04-07 03:28:45.349357+00
\.


--
-- Data for Name: identity_profiles; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.identity_profiles (organization_id, user_id, username, email, display_name, identity_provider, role_assignments, group_memberships, privilege_level, mfa_enabled, mfa_methods, last_authentication, last_password_change, authentication_methods, is_service_account, is_dormant, risk_score, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: identity_threats; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.identity_threats (organization_id, identity_id, threat_type, severity, confidence_score, source_ip, source_location, target_resource, mitre_technique_id, evidence, status, response_actions, id, created_at, updated_at) FROM stdin;
1489f1c5-9a2e-4189-8bde-89e1148ca606	\N	credential_theft	high	85	\N	\N	\N	\N	null	detected	null	432d1d62-5c45-495b-93a3-867fc97ca9b5	2026-04-08 00:16:04.525173+00	2026-04-08 00:16:04.525179+00
\.


--
-- Data for Name: identity_verifications; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.identity_verifications (user_id, verification_type, method, result, risk_score_before, risk_score_after, trigger_reason, device_id, source_ip, geo_location, session_id, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: image_vulnerabilities; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.image_vulnerabilities (image_id, cve_id, package_name, package_version, fixed_version, severity, cvss_score, exploit_available, description, layer_introduced, remediation, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: incident_timeline; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.incident_timeline (organization_id, room_id, event_time, event_type, description, created_by, evidence_ids, is_key_event, mitre_technique, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: incidents; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.incidents (title, description, severity, status, incident_type, priority, impact, affected_systems, affected_users, detected_at, contained_at, resolved_at, assigned_to, root_cause, indicators, evidence, resolution, lessons_learned, recommendations, external_id, ticket_url, tags, mitre_tactics, mitre_techniques, id, created_at, updated_at) FROM stdin;
Ransomware Attack on File Server	Investigation of ransomware attack on file server affecting production environment.	critical	investigating	ransomware	3	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d709da31-6134-4a52-b3eb-d56aa999d960	2026-03-30 17:09:40.354044+00	2026-03-31 03:11:42.354047+00
Executive Email Account Compromise	Investigation of executive email account compromise affecting production environment.	high	containment	phishing	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f548bbcb-9169-407b-ba80-8d4cb04b0b51	2026-03-28 02:56:39.354188+00	2026-03-31 03:11:42.354192+00
Data Breach via SQL Injection	Investigation of data breach via sql injection affecting production environment.	critical	eradication	data_breach	2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	9f4f5e2a-e817-4bb1-b19d-55357ff504a0	2026-03-28 03:30:56.354277+00	2026-03-31 03:11:42.354281+00
Insider Data Theft Investigation	Investigation of insider data theft investigation affecting production environment.	high	investigating	insider_threat	3	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	34c4f329-b1fe-4b66-b742-591189ee9353	2026-03-24 20:41:24.354372+00	2026-03-31 03:11:42.354376+00
Brute Force Attack on VPN Gateway	Investigation of brute force attack on vpn gateway affecting production environment.	medium	open	unauthorized_access	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	28a3a713-0858-4915-b2d6-c41599e9903b	2026-03-20 20:01:56.354443+00	2026-03-31 03:11:42.354445+00
Cloud Infrastructure Misconfiguration	Investigation of cloud infrastructure misconfiguration affecting production environment.	medium	recovery	other	4	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	97e55fea-77a8-4c78-81eb-050c4f8dc0c0	2026-03-19 12:05:35.354494+00	2026-03-31 03:11:42.354495+00
Malware Outbreak on Workstations	Investigation of malware outbreak on workstations affecting production environment.	high	containment	malware	3	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d2b45900-c388-4857-8741-5aa4d4c84a5c	2026-03-12 17:30:46.35454+00	2026-03-31 03:11:42.354542+00
APT Activity Detected in Network	Investigation of apt activity detected in network affecting production environment.	critical	investigating	advanced_persistent_threat	4	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d79de221-aadd-4f03-a7f3-e93435faa0b6	2026-03-06 12:03:58.354587+00	2026-03-31 03:11:42.354588+00
Test Incident	Testing save	critical	open	other	3	\N	\N	\N	2026-04-06T00:47:20.831045+00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	9396ecda-639d-47de-82a7-f15d00f276b4	2026-04-06 00:47:20.832944+00	2026-04-06 00:47:20.832949+00
Save Test Incident	Testing save	critical	open	other	3	\N	\N	\N	2026-04-06T00:52:43.095898+00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0c9d90e0-1650-41cc-937d-d5f38862fb93	2026-04-06 00:52:43.098766+00	2026-04-06 00:52:43.098772+00
SaveTest	\N	critical	open	other	3	\N	\N	\N	2026-04-06T01:06:36.090670+00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ed692803-30f5-4f7e-a608-afb45ce9ef7b	2026-04-06 01:06:36.09288+00	2026-04-06 01:06:36.092885+00
FinalTest	\N	critical	open	other	3	\N	\N	\N	2026-04-06T01:13:10.022961+00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	51d60c46-a6a4-4724-8fad-bab0baa72a43	2026-04-06 01:13:10.025336+00	2026-04-06 01:13:10.025341+00
X	\N	high	open	other	3	\N	\N	\N	2026-04-06T01:30:04.754449+00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	d19f2701-16d3-435d-b156-5af732a36d04	2026-04-06 01:30:04.760588+00	2026-04-06 01:30:04.760594+00
F	\N	high	open	other	3	\N	\N	\N	2026-04-06T01:39:35.851026+00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7f3512a9-e69e-4f08-bd0f-d25708bef3ef	2026-04-06 01:39:35.853624+00	2026-04-06 01:39:35.853641+00
\.


--
-- Data for Name: indicator_sightings; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.indicator_sightings (indicator_id, source, source_ref, sighting_type, context, raw_data, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: installed_integrations; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.installed_integrations (organization_id, connector_id, display_name, config_encrypted, auth_credentials_encrypted, status, health_status, last_health_check, last_successful_action, error_message, rate_limit_remaining, rate_limit_reset, webhook_url, webhook_secret_hash, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: integration_actions; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.integration_actions (connector_id, action_name, display_name, description, action_type, input_schema, output_schema, requires_approval, timeout_seconds, retry_policy, is_idempotent, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: integration_connectors; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.integration_connectors (name, display_name, description, vendor, category, version, icon_url, documentation_url, supported_actions, supported_triggers, auth_type, config_schema, is_builtin, is_community, rating, install_count, last_updated, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: integration_executions; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.integration_executions (organization_id, installed_id, action_id, triggered_by, playbook_run_id, input_data, output_data, status, started_at, completed_at, duration_ms, error_message, retry_count, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: intel_reports; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.intel_reports (title, report_type, tlp, severity, executive_summary, detailed_analysis, recommendations, associated_actors, associated_campaigns, associated_indicators, mitre_techniques, affected_sectors, affected_products, "references", tags, author_id, status, published_at, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: investigations; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.investigations (agent_id, organization_id, trigger_type, trigger_source_id, title, hypothesis, status, priority, confidence_score, reasoning_chain, evidence_collected, actions_taken, findings_summary, recommendations, mitre_techniques, affected_assets, resolution_type, human_feedback, feedback_rating, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: iocs; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.iocs (value, ioc_type, status, threat_level, confidence, description, tags, category, source, source_url, source_reference, malware_family, threat_actor, campaign, mitre_tactics, mitre_techniques, enrichment_data, last_enriched, first_seen, last_seen, expires_at, sighting_count, last_sighting, is_whitelisted, is_internal, id, created_at, updated_at) FROM stdin;
185.220.101.45	ip	active	high	50	Known Cobalt Strike C2 server	\N	\N	threat_feed	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	f	f	f5c7568b-2ed8-4b1a-8dee-a1e6a627660a	2026-02-21 23:00:43.354653+00	2026-03-31 03:11:42.354658+00
evil-update.com	domain	active	critical	50	APT28 domain used in spear-phishing	\N	\N	threat_feed	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	f	f	76ddbc98-f413-424e-943b-d4816be8e6df	2026-03-29 09:05:09.354769+00	2026-03-31 03:11:42.354772+00
http://malware-delivery.net/stage2.exe	url	active	high	50	Malware delivery URL	\N	\N	threat_feed	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	f	f	49cdbade-dd2f-436b-abcc-38029f079a8d	2026-02-19 14:18:59.35483+00	2026-03-31 03:11:42.354833+00
a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2	sha256	active	critical	50	Ransomware payload hash	\N	\N	threat_feed	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	f	f	9e4a2994-897b-4e64-810c-82e72c32a819	2026-03-31 00:14:04.354918+00	2026-03-31 03:11:42.354922+00
d41d8cd98f00b204e9800998ecf8427e	md5	active	medium	50	Suspicious file hash	\N	\N	threat_feed	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	f	f	20623414-ed06-4feb-9776-d9c2ae85e810	2026-03-24 15:21:00.354985+00	2026-03-31 03:11:42.354989+00
192.168.100.50	ip	active	medium	50	Internal host exhibiting C2 beaconing	\N	\N	threat_feed	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	f	f	ff8a9aba-a32d-43dd-b906-2cdece1bc7f3	2026-02-12 04:17:43.355156+00	2026-03-31 03:11:42.355159+00
phishing-portal.xyz	domain	active	high	50	Credential harvesting domain	\N	\N	threat_feed	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	f	f	de006f26-bd9b-4e83-9d1d-6155c07a7513	2026-02-07 15:04:53.355198+00	2026-03-31 03:11:42.3552+00
https://cdn.attack-infra.com/loader.js	url	active	high	50	JavaScript loader for exploit kit	\N	\N	threat_feed	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	f	f	b5cd5740-73d0-4db9-937b-6f8074dda117	2026-02-24 19:24:08.355239+00	2026-03-31 03:11:42.355241+00
5d41402abc4b2a76b9719d911017c592	md5	active	low	50	Adware hash	\N	\N	threat_feed	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	f	f	0ca84ec6-34d2-42e4-9923-f3b8414669cc	2026-02-10 01:26:11.355279+00	2026-03-31 03:11:42.355281+00
103.45.67.89	ip	active	high	50	Scanning IP from threat feed	\N	\N	threat_feed	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	f	f	2fe5023d-9ec4-4a27-8280-78b8d015a3c4	2026-02-26 02:24:35.355313+00	2026-03-31 03:11:42.355315+00
suspicious-vpn.ru	domain	active	medium	50	Russian VPN service linked to APT activity	\N	\N	threat_feed	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	f	f	0452b557-a81b-480d-8d1b-797a20717cb0	2026-03-14 03:24:03.355348+00	2026-03-31 03:11:42.355355+00
44.33.22.11	ip	active	low	50	Tor exit node	\N	\N	threat_feed	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	f	f	255a7120-cfe2-415c-beab-a3d313f4dcce	2026-03-13 14:18:48.355388+00	2026-03-31 03:11:42.35539+00
10.0.0.99	ip	active	high	50	Save test IOC	\N	\N	test	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-04-06T00:52:43.346852+00:00	\N	\N	1	\N	f	f	7119ca8f-2e51-4a67-b504-1989130c8c30	2026-04-06 00:52:43.350757+00	2026-04-06 00:52:43.350764+00
5.6.7.8	ip	active	high	50	\N	\N	\N	test	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-04-06T01:06:36.337531+00:00	\N	\N	1	\N	f	f	f90c695f-2d7b-4ec4-9db3-c8a83284d40f	2026-04-06 01:06:36.339261+00	2026-04-06 01:06:36.339266+00
9.8.7.6	ip	active	high	50	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-04-06T01:13:10.310340+00:00	\N	\N	1	\N	f	f	d73a22ae-37b5-41b8-9ddc-bb72d4b15e24	2026-04-06 01:13:10.312072+00	2026-04-06 01:13:10.312078+00
99.99.99.99	ip	active	high	50	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-04-06T01:30:05.068398+00:00	\N	\N	1	\N	f	f	30c1bb06-876a-41c0-bb60-1dc603f436fe	2026-04-06 01:30:05.074815+00	2026-04-06 01:30:05.074823+00
88.88.88.88	ip	active	high	50	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-04-06T01:39:36.110461+00:00	\N	\N	1	\N	f	f	6e4fbd0d-dacf-41ed-b3ff-18c299f186cc	2026-04-06 01:39:36.112289+00	2026-04-06 01:39:36.112293+00
\.


--
-- Data for Name: k8s_security_findings; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.k8s_security_findings (cluster_id, finding_type, namespace, resource_type, resource_name, severity, description, remediation, cis_benchmark_id, status, detected_at, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: kubernetes_clusters; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.kubernetes_clusters (name, version, provider, endpoint, node_count, namespace_count, pod_count, rbac_enabled, network_policy_enabled, pod_security_standards, audit_logging_enabled, encryption_at_rest, secrets_encrypted, admission_controllers, last_audit, compliance_score, risk_score, organization_id, id, created_at, updated_at) FROM stdin;
z-cluster	1.28	eks	https://z.eks.amazonaws.com	0	0	0	t	f	baseline	f	f	f	{}	\N	0	0	1489f1c5-9a2e-4189-8bde-89e1148ca606	bb99c56f-43d4-4b71-b40a-2b008eda1cd1	2026-04-06 01:30:09.472593+00	2026-04-06 01:30:09.472598+00
f-cluster	1.29	gke	https://f.gke.io	0	0	0	t	f	baseline	f	f	f	{}	\N	0	0	1489f1c5-9a2e-4189-8bde-89e1148ca606	f07f2bc7-a4a6-49e6-a72c-3f0880e1564e	2026-04-06 01:39:40.13116+00	2026-04-06 01:39:40.131166+00
\.


--
-- Data for Name: legal_holds; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.legal_holds (case_id, hold_type, custodians, data_sources, issued_by, issued_date, expiry_date, acknowledgments, status, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: log_entries; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.log_entries ("timestamp", received_at, source_type, source_name, source_ip, log_type, severity, raw_log, parsed_fields, normalized_fields, message, source_address, destination_address, source_port, destination_port, protocol, username, hostname, process_name, action, outcome, rule_matches, tags, organization_id, partition_key, id, created_at, updated_at) FROM stdin;
2026-03-24T05:39:39.374125+00:00	2026-03-31T03:11:42.374144+00:00	syslog	fw-edge-01	10.0.0.1	authentication	high	Failed SSH login from 192.168.1.100	\N	\N	Failed SSH login from 192.168.1.100	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	29e42535-0496-4a3c-aae8-9c90fc4d27d3	2026-03-25 08:38:06.374148+00	2026-03-31 03:11:42.37415+00
2026-03-27T13:16:52.380586+00:00	2026-03-31T03:11:42.380604+00:00	windows_event	dc01.corp.local	10.0.1.10	authentication	informational	Successful RDP session from 10.0.5.20	\N	\N	Successful RDP session from 10.0.5.20	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	cd4934a9-2dc1-493d-922f-f326f6fb9975	2026-03-24 04:08:15.380607+00	2026-03-31 03:11:42.380609+00
2026-03-30T11:16:51.380667+00:00	2026-03-31T03:11:42.380671+00:00	syslog	dns-resolver-01	10.0.0.2	network	critical	DNS query to known C2 domain evil.com	\N	\N	DNS query to known C2 domain evil.com	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	85f64dab-0793-45b5-bcb4-bb2b2aff0621	2026-03-29 03:59:37.380673+00	2026-03-31 03:11:42.380675+00
2026-03-25T04:41:43.380735+00:00	2026-03-31T03:11:42.380739+00:00	cef	fw-edge-01	10.0.0.1	network	medium	Firewall blocked inbound scan on port 445	\N	\N	Firewall blocked inbound scan on port 445	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4fa5b864-6e20-4953-95f2-a889c602a9f0	2026-03-29 23:20:11.380742+00	2026-03-31 03:11:42.380743+00
2026-03-27T22:10:56.380791+00:00	2026-03-31T03:11:42.380795+00:00	windows_event	dc01.corp.local	10.0.1.10	security	high	User account locked after 5 failed attempts	\N	\N	User account locked after 5 failed attempts	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	a4bffb17-5510-432c-9555-cb727debadd9	2026-03-26 13:43:29.380797+00	2026-03-31 03:11:42.380798+00
2026-03-28T21:45:07.380839+00:00	2026-03-31T03:11:42.380843+00:00	cloud_trail	aws-us-east-1	172.16.0.1	cloud	high	AWS CloudTrail: S3 bucket policy changed	\N	\N	AWS CloudTrail: S3 bucket policy changed	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	bd94e2f6-6a59-4830-9c2f-bf7dc98adcda	2026-03-26 12:10:11.380845+00	2026-03-31 03:11:42.380847+00
2026-03-25T12:20:21.380886+00:00	2026-03-31T03:11:42.380889+00:00	json_api	edr-console	10.0.10.5	endpoint	medium	Antivirus quarantined file on WORKSTATION-42	\N	\N	Antivirus quarantined file on WORKSTATION-42	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	30a0580d-93b1-4540-beb7-a2d8ac639083	2026-03-29 14:36:27.380895+00	2026-03-31 03:11:42.380897+00
2026-03-24T12:44:17.380936+00:00	2026-03-31T03:11:42.380940+00:00	syslog	web-prod-01	10.0.2.20	application	critical	Apache access log: SQL injection attempt	\N	\N	Apache access log: SQL injection attempt	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	c4adf271-9e49-4192-adf3-60a185dd024e	2026-03-26 12:01:20.380942+00	2026-03-31 03:11:42.380944+00
2026-03-27T02:53:10.380983+00:00	2026-03-31T03:11:42.380987+00:00	syslog	vpn-gateway	10.0.0.5	network	low	VPN connection established from remote IP	\N	\N	VPN connection established from remote IP	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	50cfee9c-fbff-4670-99f2-95c051608933	2026-03-27 05:05:31.380989+00	2026-03-31 03:11:42.38099+00
2026-03-30T01:03:49.381029+00:00	2026-03-31T03:11:42.381032+00:00	json_api	exchange-01	10.0.1.15	application	high	Exchange: Suspicious mail forwarding rule created	\N	\N	Exchange: Suspicious mail forwarding rule created	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	a490b913-6030-4ac4-881d-0cf9af51be41	2026-03-29 01:50:36.381035+00	2026-03-31 03:11:42.381036+00
2026-03-30T19:22:40.381075+00:00	2026-03-31T03:11:42.381093+00:00	syslog	db-prod-01	10.0.3.30	system	medium	Linux audit: sudo command by non-admin user	\N	\N	Linux audit: sudo command by non-admin user	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	943531af-31e1-4477-8556-281a086547d1	2026-03-24 03:40:09.381095+00	2026-03-31 03:11:42.381096+00
2026-03-31T02:13:09.381142+00:00	2026-03-31T03:11:42.381146+00:00	cef	ids-sensor-01	10.0.0.3	security	high	IDS alert: Port scan detected from external IP	\N	\N	IDS alert: Port scan detected from external IP	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	bbac5a2d-913e-45b9-afd9-0ca03b83b952	2026-03-27 00:14:55.381148+00	2026-03-31 03:11:42.381149+00
2026-03-26T19:19:11.381187+00:00	2026-03-31T03:11:42.381191+00:00	json_api	k8s-node-01	10.0.4.10	endpoint	critical	Container runtime: Privilege escalation attempt	\N	\N	Container runtime: Privilege escalation attempt	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ca49ac34-e19c-44b4-b97c-81ae07718176	2026-03-29 14:01:59.381193+00	2026-03-31 03:11:42.381195+00
2026-03-25T10:13:37.381235+00:00	2026-03-31T03:11:42.381239+00:00	cloud_trail	azure-ad	172.16.0.2	authentication	high	Azure AD: Impossible travel login detected	\N	\N	Azure AD: Impossible travel login detected	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ac8cea23-ac11-446d-964e-40e15f9f1dd4	2026-03-26 11:43:24.381241+00	2026-03-31 03:11:42.381242+00
2026-03-24T14:38:50.381281+00:00	2026-03-31T03:11:42.381284+00:00	syslog	proxy-01	10.0.0.4	network	medium	Proxy: Connection to TOR exit node blocked	\N	\N	Proxy: Connection to TOR exit node blocked	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	23e62f49-b93a-4cf1-b3dd-db9c6ca5d4bd	2026-03-29 23:03:41.381287+00	2026-03-31 03:11:42.381288+00
2026-04-02T12:00:00Z	2026-04-02T17:06:00.531210+00:00	syslog	fw-edge-01	10.0.0.1	authentication	critical	<34>1 2026-04-02T12:00:00Z fw-edge-01 sshd 1234 - Failed password for root from 192.168.1.100 port 22	{"priority": 34, "version": 1, "facility": 4, "severity": 2, "timestamp": "2026-04-02T12:00:00Z", "hostname": "fw-edge-01", "app_name": "sshd", "process_id": "1234", "message_id": "-", "structured_data": null, "message": "Failed password for root from 192.168.1.100 port 22"}	{"timestamp": "2026-04-02T12:00:00", "source_type": "syslog", "log_type": "authentication", "severity": "critical", "source_address": null, "destination_address": null, "source_port": null, "destination_port": null, "protocol": null, "username": null, "hostname": "fw-edge-01", "process_name": "sshd", "action": null, "outcome": null, "message": "Failed password for root from 192.168.1.100 port 22", "raw_fields": {"priority": 34, "version": 1, "facility": 4, "severity": 2, "timestamp": "2026-04-02T12:00:00Z", "hostname": "fw-edge-01", "app_name": "sshd", "process_id": "1234", "message_id": "-", "structured_data": null, "message": "Failed password for root from 192.168.1.100 port 22"}}	Failed password for root from 192.168.1.100 port 22	\N	\N	\N	\N	\N	\N	fw-edge-01	sshd	\N	\N	\N	\N	\N	\N	b83374bc-2b50-4d59-a29b-1e20fab28206	2026-04-02 17:06:00.533931+00	2026-04-02 17:06:00.533936+00
\.


--
-- Data for Name: micro_segments; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.micro_segments (name, segment_type, description, cidr_ranges, allowed_protocols, allowed_ports, allowed_services, ingress_policies, egress_policies, member_assets, trust_level, is_active, traffic_stats, violation_count, last_violation_at, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ml_models; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.ml_models (name, model_type, algorithm, version, status, description, feature_columns, hyperparameters, training_metrics, model_path, training_data_size, last_trained_at, last_prediction_at, prediction_count, drift_score, tags, organization_id, id, created_at, updated_at) FROM stdin;
anomaly_detection_isolation_forest_1.0.0	anomaly_detection	isolation_forest	1.0.0	ready	Auto-trained anomaly detection model	[]	{}	{"accuracy": 0.9, "precision": 0.87, "recall": 0.92, "f1": 0.89}	\N	0	2026-04-06 03:12:20.848857+00	\N	0	0	[]	1489f1c5-9a2e-4189-8bde-89e1148ca606	7cc7cfad-36af-41b5-9a08-714ed8715533	2026-04-06 03:12:20.85474+00	2026-04-06 03:12:20.854746+00
\.


--
-- Data for Name: nl_queries; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.nl_queries (natural_language, interpreted_intent, generated_query, query_parameters, results_summary, result_count, execution_time_ms, user_id, was_helpful, organization_id, id, created_at, updated_at) FROM stdin;
show me critical alerts	general_search	SELECT * FROM alerts WHERE description ILIKE '%show me critical alerts%' ORDER BY created_at DESC	{}	Found 17 results matching your query about 'show me critical alerts'.	17	216	765b349b-c587-4281-b9ce-8506bf3738a2	\N	1489f1c5-9a2e-4189-8bde-89e1148ca606	0e43d88d-0dd8-4b88-93c3-bc540895ffaf	2026-04-02 01:54:18.151391+00	2026-04-02 01:54:18.151398+00
Which assets have critical vulns	general_search	SELECT * FROM alerts WHERE description ILIKE '%which assets have critical vul%' ORDER BY created_at DESC	{}	Found 15 results matching your query about 'Which assets have critical vulns'.	15	164	765b349b-c587-4281-b9ce-8506bf3738a2	\N	1489f1c5-9a2e-4189-8bde-89e1148ca606	48d52f8a-154e-494d-9851-24c7834c3753	2026-04-02 01:55:13.38853+00	2026-04-02 01:55:13.388535+00
Summarize today's alerts	general_search	SELECT * FROM alerts WHERE description ILIKE '%summarize today's alerts%' ORDER BY created_at DESC	{}	Found 38 results matching your query about 'Summarize today's alerts'.	38	87	765b349b-c587-4281-b9ce-8506bf3738a2	\N	1489f1c5-9a2e-4189-8bde-89e1148ca606	243b45c9-24fb-4473-85e6-361eb539a2d7	2026-04-02 01:55:23.15644+00	2026-04-02 01:55:23.156445+00
Unusual network activity detected	general_search	SELECT * FROM alerts WHERE description ILIKE '%unusual network activity detec%' ORDER BY created_at DESC	{}	Found 5 results matching your query about 'Unusual network activity detected'.	5	154	765b349b-c587-4281-b9ce-8506bf3738a2	\N	1489f1c5-9a2e-4189-8bde-89e1148ca606	5b2a40a6-6bc5-45e9-b4f0-4f00a67e7bca	2026-04-02 01:55:28.678247+00	2026-04-02 01:55:28.678251+00
Summarize today's alerts	general_search	SELECT * FROM alerts WHERE description ILIKE '%summarize today's alerts%' ORDER BY created_at DESC	{}	Found 44 results matching your query about 'Summarize today's alerts'.	44	93	765b349b-c587-4281-b9ce-8506bf3738a2	\N	1489f1c5-9a2e-4189-8bde-89e1148ca606	033098b4-2f75-4267-b970-118ad3b645d9	2026-04-06 03:12:37.400782+00	2026-04-06 03:12:37.400786+00
Which assets have critical vulns	general_search	SELECT * FROM alerts WHERE description ILIKE '%which assets have critical vul%' ORDER BY created_at DESC	{}	Found 8 results matching your query about 'Which assets have critical vulns'.	8	107	765b349b-c587-4281-b9ce-8506bf3738a2	\N	1489f1c5-9a2e-4189-8bde-89e1148ca606	1ffa3ffc-4688-4a84-a89a-d8699f819899	2026-04-06 11:29:41.715586+00	2026-04-06 11:29:41.715589+00
\.


--
-- Data for Name: organization_members; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.organization_members (organization_id, user_id, role, is_primary, id, created_at, updated_at) FROM stdin;
1489f1c5-9a2e-4189-8bde-89e1148ca606	765b349b-c587-4281-b9ce-8506bf3738a2	owner	t	78fa30d5-bc0b-46c9-91e5-871ce84fe81a	2026-03-17 15:53:18.009084+00	2026-03-17 15:53:18.009089+00
68954722-881d-4ba9-bd9e-b900b27ad5de	765b349b-c587-4281-b9ce-8506bf3738a2	owner	t	1855676c-e0ab-40e0-ba31-b0c5f6b43027	2026-04-06 11:43:46.337066+00	2026-04-06 11:43:46.33707+00
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.organizations (name, slug, description, email, phone, website, address, city, country, logo_url, primary_color, plan, max_users, max_alerts_per_month, max_storage_gb, settings, is_active, id, created_at, updated_at) FROM stdin;
My Org	my-org	test organization	\N	\N	\N	\N	\N	\N	\N	\N	free	5	1000	5	\N	t	1489f1c5-9a2e-4189-8bde-89e1148ca606	2026-03-17 15:53:18.005818+00	2026-03-17 15:53:18.005826+00
Test	test	Test	\N	\N	\N	\N	\N	\N	\N	\N	free	5	1000	5	\N	t	68954722-881d-4ba9-bd9e-b900b27ad5de	2026-04-06 11:43:46.332884+00	2026-04-06 11:43:46.332889+00
\.


--
-- Data for Name: ot_alerts; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.ot_alerts (organization_id, asset_id, alert_type, severity, source_ip, destination_ip, protocol_used, command_function_code, description, raw_data, mitre_ics_technique, status, response_action, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ot_assets; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.ot_assets (organization_id, name, asset_type, vendor, model, firmware_version, protocol, ip_address, mac_address, serial_number, purdue_level, zone, cell_area, criticality, last_seen, is_online, firmware_current, known_vulnerabilities_count, risk_score, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ot_incidents; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.ot_incidents (organization_id, title, description, affected_assets, affected_zones, incident_type, severity, physical_impact_risk, operational_impact, status, containment_strategy, safe_shutdown_initiated, detected_at, contained_at, resolved_at, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ot_policy_rules; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.ot_policy_rules (organization_id, name, description, rule_type, purdue_levels_applied, conditions, enforcement_action, enabled, violations_count, last_violation, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ot_zones; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.ot_zones (organization_id, name, description, purdue_level, network_cidr, allowed_protocols, allowed_communications, assets_count, compliance_status, last_audit, firewall_rules, segmentation_verified, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: patch_operations; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.patch_operations (vulnerability_instance_id, patch_type, patch_id, patch_name, deployment_status, deployment_date, verification_date, rollback_available, change_ticket_id, approved_by, deployment_notes, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: peer_groups; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.peer_groups (name, description, group_type, member_count, baseline_data, risk_threshold, members, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: phishing_campaigns; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.phishing_campaigns (name, description, campaign_type, status, template_id, target_group_id, send_schedule, start_date, end_date, total_targets, emails_sent, emails_opened, links_clicked, credentials_submitted, attachments_opened, reported_count, difficulty_level, created_by, organization_id, id, created_at, updated_at) FROM stdin;
Z2	t	phishing	draft	\N	\N	{"batch_size": 50, "interval_hours": 1, "send_all_at_once": false}	\N	\N	0	0	0	0	0	0	0	intermediate	765b349b-c587-4281-b9ce-8506bf3738a2	1489f1c5-9a2e-4189-8bde-89e1148ca606	757c5695-d26a-41c7-8b48-d70d89111e3e	2026-04-06 01:35:44.24611+00	2026-04-06 01:35:44.246116+00
F	t	phishing	draft	\N	\N	{"batch_size": 50, "interval_hours": 1, "send_all_at_once": false}	\N	\N	0	0	0	0	0	0	0	intermediate	765b349b-c587-4281-b9ce-8506bf3738a2	1489f1c5-9a2e-4189-8bde-89e1148ca606	175b8449-1ac3-42f1-885b-528260f5c4b3	2026-04-06 01:39:40.887982+00	2026-04-06 01:39:40.887987+00
T	t	phishing	draft	\N	\N	{"batch_size": 50, "interval_hours": 1, "send_all_at_once": false}	\N	\N	0	0	0	0	0	0	0	intermediate	765b349b-c587-4281-b9ce-8506bf3738a2	1489f1c5-9a2e-4189-8bde-89e1148ca606	3fb3ca23-69c7-4db9-97ca-be78995acae5	2026-04-07 03:28:45.013924+00	2026-04-07 03:28:45.01393+00
\.


--
-- Data for Name: phishing_templates; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.phishing_templates (name, description, category, difficulty, subject_line, sender_name, sender_email, html_body, text_body, landing_page_html, has_attachment, attachment_name, indicators_of_phishing, training_content_on_fail, language, is_seasonal, usage_count, average_click_rate, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: playbook_edges; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.playbook_edges (playbook_id, organization_id, source_node_id, target_node_id, edge_type, condition_expression, label, priority, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: playbook_executions; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.playbook_executions (playbook_id, incident_id, status, current_step, total_steps, started_at, completed_at, input_data, output_data, step_results, error_message, error_step, triggered_by, trigger_source, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: playbook_node_executions; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.playbook_node_executions (execution_id, organization_id, node_id, status, started_at, completed_at, duration_ms, input_data, output_data, error_message, retry_attempt, approved_by, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: playbook_nodes; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.playbook_nodes (playbook_id, organization_id, node_id, node_type, display_name, description, position_x, position_y, config, input_schema, output_schema, timeout_seconds, retry_count, on_error, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: playbooks; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.playbooks (name, description, status, trigger_type, trigger_conditions, steps, variables, version, category, tags, is_enabled, timeout_seconds, max_retries, created_by, id, created_at, updated_at) FROM stdin;
Malware Containment	Automated malware containment and isolation procedure	active	manual	\N	[{"name": "Identify affected hosts", "action_type": "query", "description": "Query SIEM for all hosts communicating with the malware C2"}, {"name": "Isolate endpoints", "action_type": "action", "description": "Network isolate affected endpoints via EDR"}, {"name": "Block IOCs", "action_type": "action", "description": "Add malware IOCs to firewall blocklist"}, {"name": "Collect forensic artifacts", "action_type": "query", "description": "Gather memory dumps and disk images"}, {"name": "Notify SOC lead", "action_type": "notification", "description": "Send alert to SOC manager with summary"}]	\N	1	\N	\N	t	3600	3	\N	aa305b22-18e2-44e7-b920-496c3bdfe881	2026-02-12 12:47:43.355499+00	2026-03-31 03:11:42.355503+00
Phishing Response	Automated phishing email investigation and response	active	manual	\N	[{"name": "Extract email indicators", "action_type": "query", "description": "Parse sender, URLs, and attachments from phishing email"}, {"name": "Check URL reputation", "action_type": "enrichment", "description": "Query VirusTotal and URLScan for URL reputation"}, {"name": "Search for similar emails", "action_type": "query", "description": "Search email gateway for related messages"}, {"name": "Quarantine emails", "action_type": "action", "description": "Quarantine all matching emails across organization"}, {"name": "Reset user credentials", "action_type": "action", "description": "Force password reset for affected users"}]	\N	1	\N	\N	t	3600	3	\N	4fd61532-743e-4fc8-a38a-2d7b4252305e	2026-01-30 10:18:13.35566+00	2026-03-31 03:11:42.355665+00
Brute Force Mitigation	Automated response to brute force attacks	active	manual	\N	[{"name": "Identify source IPs", "action_type": "query", "description": "Query authentication logs for failed attempts"}, {"name": "Block source IPs", "action_type": "action", "description": "Add attacker IPs to firewall deny list"}, {"name": "Check compromised accounts", "action_type": "query", "description": "Identify accounts with successful logins after failures"}, {"name": "Lock compromised accounts", "action_type": "action", "description": "Disable any compromised accounts"}]	\N	1	\N	\N	t	3600	3	\N	92bedfbd-9646-4fc3-9d42-767a7804e818	2026-02-24 07:17:29.355775+00	2026-03-31 03:11:42.355778+00
Cloud Security Incident	Automated cloud infrastructure investigation	active	manual	\N	[{"name": "Query CloudTrail events", "action_type": "query", "description": "Pull recent API activity for affected resources"}, {"name": "Revoke exposed credentials", "action_type": "action", "description": "Rotate IAM keys and revoke sessions"}, {"name": "Restore secure configuration", "action_type": "action", "description": "Revert security group and policy changes"}]	\N	1	\N	\N	t	3600	3	\N	313501aa-ccb9-4de6-9d70-af10c8f65252	2026-01-02 09:50:23.35583+00	2026-03-31 03:11:42.355832+00
Ransomware Response	Full ransomware incident response playbook	active	manual	\N	[{"name": "Isolate infected systems", "action_type": "action", "description": "Network-isolate all identified infected hosts"}, {"name": "Identify ransomware variant", "action_type": "query", "description": "Collect samples and identify the ransomware family"}, {"name": "Assess encryption scope", "action_type": "query", "description": "Determine which files and systems are encrypted"}, {"name": "Check backup integrity", "action_type": "query", "description": "Verify backup availability and integrity"}, {"name": "Initiate recovery", "action_type": "action", "description": "Begin system restoration from verified backups"}, {"name": "Executive notification", "action_type": "notification", "description": "Notify CISO and legal team of ransomware incident"}]	\N	1	\N	\N	t	3600	3	\N	52aed387-addf-44a1-931b-1579e0106093	2026-02-20 23:49:47.355887+00	2026-03-31 03:11:42.355889+00
enrivchment	enriches	draft	webhook	\N	[{"id": "step_1", "name": "Step 1", "action": "send_notification", "parameters": {}, "on_success": null, "on_failure": null, "timeout_seconds": 300, "continue_on_error": false}, {"id": "step_2", "name": "Step 2", "action": "create_incident", "parameters": {}, "on_success": null, "on_failure": null, "timeout_seconds": 300, "continue_on_error": false}, {"id": "step_3", "name": "Step 3", "action": "block_ip", "parameters": {}, "on_success": null, "on_failure": null, "timeout_seconds": 300, "continue_on_error": false}, {"id": "step_4", "name": "Step 4", "action": "wait", "parameters": {}, "on_success": null, "on_failure": null, "timeout_seconds": 300, "continue_on_error": false}, {"id": "step_5", "name": "Step 5", "action": "run_script", "parameters": {}, "on_success": null, "on_failure": null, "timeout_seconds": 300, "continue_on_error": false}]	\N	1		\N	t	3600	3	765b349b-c587-4281-b9ce-8506bf3738a2	59726cfd-6aae-43a2-a2ac-29847eea8402	2026-04-06 00:46:18.09526+00	2026-04-06 00:46:18.095266+00
Test Playbook	Testing	draft	manual	\N	[{"id": "step_1", "name": "Step 1", "action": "send_notification", "parameters": {}, "on_success": null, "on_failure": null, "timeout_seconds": 300, "continue_on_error": false}]	\N	1	incident_response	\N	t	3600	3	765b349b-c587-4281-b9ce-8506bf3738a2	e7212970-1f5e-4b3d-8dce-0c794666bf68	2026-04-06 00:49:20.195588+00	2026-04-06 00:49:20.195593+00
Save Test Playbook	test	draft	manual	\N	[{"id": "s1", "name": "Step 1", "action": "send_notification", "parameters": {}, "on_success": null, "on_failure": null, "timeout_seconds": 300, "continue_on_error": false}]	\N	1	\N	\N	t	3600	3	765b349b-c587-4281-b9ce-8506bf3738a2	03e1212e-0102-4468-ba2a-b2407242098f	2026-04-06 00:53:07.868388+00	2026-04-06 00:53:07.868393+00
SaveTest	\N	draft	manual	\N	[{"id": "s1", "name": "S1", "action": "send_notification", "parameters": {}, "on_success": null, "on_failure": null, "timeout_seconds": 300, "continue_on_error": false}]	\N	1	\N	\N	t	3600	3	765b349b-c587-4281-b9ce-8506bf3738a2	1c9a7a75-569c-4e84-ba0c-cd103b6e80e6	2026-04-06 01:06:36.794191+00	2026-04-06 01:06:36.794196+00
FinalPB	\N	draft	manual	\N	[{"id": "s1", "name": "S1", "action": "send_notification", "parameters": {}, "on_success": null, "on_failure": null, "timeout_seconds": 300, "continue_on_error": false}]	\N	1	\N	\N	t	3600	3	765b349b-c587-4281-b9ce-8506bf3738a2	305e496d-ee69-4e37-a6a9-ec054d5215a2	2026-04-06 01:13:10.851556+00	2026-04-06 01:13:10.851562+00
test	test	draft	incident	\N	[{"id": "step_1", "name": "Step 1", "action": "send_notification", "parameters": {}, "on_success": null, "on_failure": null, "timeout_seconds": 300, "continue_on_error": false}, {"id": "step_2", "name": "Step 2", "action": "create_incident", "parameters": {}, "on_success": null, "on_failure": null, "timeout_seconds": 300, "continue_on_error": false}, {"id": "step_3", "name": "Step 3", "action": "block_ip", "parameters": {}, "on_success": null, "on_failure": null, "timeout_seconds": 300, "continue_on_error": false}, {"id": "step_4", "name": "Step 4", "action": "run_script", "parameters": {}, "on_success": null, "on_failure": null, "timeout_seconds": 300, "continue_on_error": false}, {"id": "step_5", "name": "Step 5", "action": "wait", "parameters": {}, "on_success": null, "on_failure": null, "timeout_seconds": 300, "continue_on_error": false}]	\N	1		\N	t	3600	3	765b349b-c587-4281-b9ce-8506bf3738a2	8363cf5c-ad41-4eed-9a7b-b46c94e3776f	2026-04-06 01:18:26.910177+00	2026-04-06 01:18:26.910182+00
ree		draft	manual	\N	[{"id": "step_1", "name": "Step 1", "action": "send_notification", "parameters": {}, "on_success": null, "on_failure": null, "timeout_seconds": 300, "continue_on_error": false}]	\N	1		\N	t	3600	3	765b349b-c587-4281-b9ce-8506bf3738a2	069ffe5d-fa41-4b31-a414-63aaa4c2ce82	2026-04-06 01:18:33.338739+00	2026-04-06 01:18:33.338745+00
My Test Playbook	Testing from frontend	draft	manual	\N	[{"id": "step_1", "name": "Step 1", "action": "send_notification", "parameters": {}, "on_success": null, "on_failure": null, "timeout_seconds": 300, "continue_on_error": false}]	\N	1		\N	t	3600	3	765b349b-c587-4281-b9ce-8506bf3738a2	63d3fefa-cdbb-4113-b6b2-5dfe3ca6d69f	2026-04-06 01:20:25.666989+00	2026-04-06 01:20:25.666994+00
Z	\N	draft	manual	\N	[{"id": "s1", "name": "S1", "action": "send_notification", "parameters": {}, "on_success": null, "on_failure": null, "timeout_seconds": 300, "continue_on_error": false}]	\N	1	\N	\N	t	3600	3	765b349b-c587-4281-b9ce-8506bf3738a2	b1114f62-8acf-4980-bcac-95b8039399e6	2026-04-06 01:30:05.560378+00	2026-04-06 01:30:05.560384+00
F	\N	draft	manual	\N	[{"id": "s1", "name": "S1", "action": "send_notification", "parameters": {}, "on_success": null, "on_failure": null, "timeout_seconds": 300, "continue_on_error": false}]	\N	1	\N	\N	t	3600	3	765b349b-c587-4281-b9ce-8506bf3738a2	10cd5609-c555-444e-ac05-42387e5d4058	2026-04-06 01:39:36.58694+00	2026-04-06 01:39:36.586945+00
\.


--
-- Data for Name: poams; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.poams (control_id_ref, weakness_name, weakness_description, weakness_source, risk_level, original_risk_rating, residual_risk_rating, status, milestone_changes, scheduled_completion_date, actual_completion_date, milestones, resources_required, cost_estimate, compensating_controls, vendor_dependencies, assigned_to, approved_by, comments, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: privacy_impact_assessments; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.privacy_impact_assessments (organization_id, name, project_name, assessment_type, status, data_types_processed, processing_purposes, legal_basis, data_subjects_affected, cross_border_transfers, risk_level, mitigations, dpo_review, dpo_approval_date, supervisory_authority_consulted, id, created_at, updated_at) FROM stdin;
1489f1c5-9a2e-4189-8bde-89e1148ca606	SavePIA	Test	pia	draft	\N	\N	\N	\N	\N	medium	\N	f	\N	f	fc430b40-0396-4656-b979-1799af22a480	2026-04-06 01:07:10.207251+00	2026-04-06 01:07:10.207256+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	FinalPIA	Fin	pia	draft	\N	\N	\N	\N	\N	medium	\N	f	\N	f	293edc08-8558-4fe4-9306-ac710fbdce6b	2026-04-06 01:13:12.192918+00	2026-04-06 01:13:12.192923+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	Z	Z	pia	draft	\N	\N	\N	\N	\N	medium	\N	f	\N	f	725497ec-0c7d-43d5-8062-4048950bb522	2026-04-06 01:30:07.160972+00	2026-04-06 01:30:07.160977+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	F	F	pia	draft	\N	\N	\N	\N	\N	medium	\N	f	\N	f	94023c68-0cf2-4774-9995-1f14c2d3b395	2026-04-06 01:39:37.998729+00	2026-04-06 01:39:37.998733+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	Test PIA	Proj	pia	draft	\N	\N	\N	\N	\N	medium	\N	f	\N	f	a18c6357-e19a-46f1-b71a-d9ebf9674943	2026-04-07 03:20:56.323221+00	2026-04-07 03:20:56.323224+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	T	P	pia	draft	\N	\N	\N	\N	\N	medium	\N	f	\N	f	82ab742b-25ca-44c6-a6d5-737083207190	2026-04-07 03:28:45.694759+00	2026-04-07 03:28:45.694763+00
\.


--
-- Data for Name: privacy_incidents; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.privacy_incidents (organization_id, title, description, incident_type, severity, status, data_types_affected, subjects_affected_count, regulations_implicated, notification_required, notification_deadline, supervisory_authority_notified, subjects_notified, containment_actions, root_cause, remediation_steps, id, created_at, updated_at) FROM stdin;
1489f1c5-9a2e-4189-8bde-89e1148ca606	TestBreach2	Test	data_breach	high	reported	["PII"]	50	\N	t	\N	f	f	\N	\N	\N	ea37b5ee-421c-48fb-a0a0-ee07228fd0c6	2026-04-06 01:10:46.858017+00	2026-04-06 01:10:46.858022+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	Breach3	Test breach	data_breach	high	reported	["PII"]	10	\N	t	\N	f	f	\N	\N	\N	84d2d0d4-5be3-428d-ba63-42ea1fc5c176	2026-04-06 01:11:21.452808+00	2026-04-06 01:11:21.452812+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	Breach4	Test	data_breach	high	reported	["PII", "PHI"]	25	\N	t	\N	f	f	\N	\N	\N	43172886-527c-4d90-bce9-4d13668e4adb	2026-04-06 01:12:39.289433+00	2026-04-06 01:12:39.289438+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	FinalBreach	t	data_breach	high	reported	["PII"]	5	\N	t	\N	f	f	\N	\N	\N	26a2e2f5-cbca-460b-ba6d-41411c8fe32c	2026-04-06 01:13:13.004794+00	2026-04-06 01:13:13.004798+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	Z	t	data_breach	high	reported	["PII"]	1	\N	t	\N	f	f	\N	\N	\N	902d1cb2-e7c6-42fe-b43b-718b65a53e00	2026-04-06 01:30:07.970017+00	2026-04-06 01:30:07.970025+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	F	t	data_breach	high	reported	["PII"]	1	\N	t	\N	f	f	\N	\N	\N	ecc4a43d-ca46-4ae9-87ab-7ec4348a95aa	2026-04-06 01:39:38.72848+00	2026-04-06 01:39:38.728485+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	test	test	data_breach	medium	reported	["tes", "test"]	2	\N	t	\N	f	f	\N	\N	\N	c1c7a5be-b389-456f-b081-af4c9236eaec	2026-04-06 11:53:49.491486+00	2026-04-06 11:53:49.49149+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	Test	t	data_breach	high	reported	["PII"]	1	\N	t	\N	f	f	\N	\N	\N	75d4a925-073a-4c2c-b251-5364ee06484e	2026-04-07 03:20:57.392537+00	2026-04-07 03:20:57.39254+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	T	t	data_breach	high	reported	["PII"]	1	\N	t	\N	f	f	\N	\N	\N	ce14676d-7c97-4f56-b29e-0122b14d1efb	2026-04-07 03:28:46.65377+00	2026-04-07 03:28:46.653774+00
\.


--
-- Data for Name: privileged_access_events; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.privileged_access_events (organization_id, identity_id, event_type, target_resource, justification, approved_by, approval_timestamp, expiry_timestamp, was_revoked, revocation_reason, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: query_jobs; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.query_jobs (organization_id, query_text, query_language, status, data_sources_queried, time_range_start, time_range_end, records_scanned, records_returned, execution_time_ms, result_location, cost_estimate, submitted_by, cached, error_message, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: reasoning_steps; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.reasoning_steps (investigation_id, organization_id, step_number, step_type, thought_process, action_taken, action_tool, action_parameters, observation, confidence_delta, duration_ms, tokens_used, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: remediation_actions; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.remediation_actions (name, description, action_type, target_type, parameters, integration, integration_config, timeout_seconds, retry_count, is_reversible, reverse_action_type, reverse_parameters, risk_level, requires_confirmation, tags, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: remediation_executions; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.remediation_executions (policy_id, trigger_source, trigger_id, trigger_details, status, approval_status, approved_by, approved_at, started_at, completed_at, target_entity, target_type, actions_planned, actions_completed, current_action_index, overall_result, error_message, rollback_status, rolled_back_at, metrics, notes, created_by, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: remediation_integrations; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.remediation_integrations (name, integration_type, vendor, endpoint_url, auth_type, auth_config, capabilities, is_connected, last_health_check, health_status, rate_limit, tags, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: remediation_playbooks; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.remediation_playbooks (name, description, playbook_type, trigger_conditions, steps, decision_points, parallel_actions, estimated_duration_minutes, is_template, is_enabled, success_count, failure_count, avg_execution_minutes, tags, created_by, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: remediation_policies; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.remediation_policies (name, description, policy_type, trigger_type, trigger_conditions, actions, is_enabled, requires_approval, approval_timeout_minutes, auto_approve_after_timeout, cooldown_minutes, max_executions_per_hour, scope, exclusions, priority, risk_level, rollback_enabled, rollback_actions, execution_count, last_executed_at, success_rate, tags, created_by, organization_id, id, created_at, updated_at) FROM stdin;
Auto-Block Critical	Block critical threats	auto_block	alert_severity	{"severity": "critical"}	[]	t	f	30	f	15	10	{}	[]	50	medium	t	[]	0	\N	\N	[]	765b349b-c587-4281-b9ce-8506bf3738a2	1489f1c5-9a2e-4189-8bde-89e1148ca606	7caf32f4-3f3a-47c3-acd2-ee106ddb1d44	2026-04-08 01:58:43.788227+00	2026-04-08 01:58:43.788232+00
\.


--
-- Data for Name: remediation_tickets; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.remediation_tickets (title, description, status, priority, assigned_to, assigned_team, asset_vulnerabilities, affected_assets, remediation_type, remediation_steps, due_date, sla_breach, resolved_at, verification_status, verified_at, verified_by, external_ticket_id, external_ticket_url, tags, organization_id, id, created_at, updated_at) FROM stdin;
Patch critical vulnerability CVE-2024-1234	Apply security patch to production servers	open	high	\N	\N	[]	[]	patch	[]	\N	f	\N	pending	\N	\N	\N	\N	[]	1489f1c5-9a2e-4189-8bde-89e1148ca606	2ab18828-810c-49ca-9b15-ffdac280075e	2026-04-02 01:33:46.368968+00	2026-04-02 01:33:46.368977+00
test	test	open	medium	jacobspeart@gmail.com	\N	[]	[]	patch	[]	2026-04-02 00:00:00+00	f	\N	pending	\N	\N	\N	\N	[]	1489f1c5-9a2e-4189-8bde-89e1148ca606	4db4d40f-7f6b-4a62-abd5-449717ebe5e9	2026-04-02 01:38:34.023637+00	2026-04-02 01:38:34.023642+00
\.


--
-- Data for Name: risk_controls; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.risk_controls (organization_id, risk_register_id, control_name, control_type, implementation_status, effectiveness_score, cost_annual_usd, roi_percentage, frameworks_mapped, last_tested, test_result, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: risk_registers; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.risk_registers (organization_id, name, description, risk_category, inherent_risk_score, residual_risk_score, risk_treatment, treatment_plan, control_effectiveness, owner_id, review_frequency_days, last_review, next_review, ale_annual_usd, risk_appetite_threshold_usd, is_within_appetite, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: risk_scenarios; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.risk_scenarios (organization_id, name, description, asset_id, asset_name, asset_value_usd, threat_actor, threat_type, vulnerability_exploited, loss_type, status, analyst_id, review_date, confidence_level, id, created_at, updated_at) FROM stdin;
1489f1c5-9a2e-4189-8bde-89e1148ca606	Z	t	\N	Server	100000	external_attacker	ransomware	CVE-2024-0001	productivity	draft	765b349b-c587-4281-b9ce-8506bf3738a2	\N	0.5	1caf5a89-a10b-4102-b2b7-b4924af42b4a	2026-04-06 01:30:10.679533+00	2026-04-06 01:30:10.67954+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	F	t	\N	S	50000	external_attacker	ransomware	CVE-2024-001	productivity	draft	765b349b-c587-4281-b9ce-8506bf3738a2	\N	0.5	27196515-9a76-4836-abf1-17b7cb1372b8	2026-04-06 01:39:41.139203+00	2026-04-06 01:39:41.139209+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	T	t	\N	S	50000	external_attacker	ransomware	CVE-2024-1	productivity	draft	765b349b-c587-4281-b9ce-8506bf3738a2	\N	0.5	39a87a77-3b99-4d9d-8b2d-cc87e70b904e	2026-04-07 03:28:47.056881+00	2026-04-07 03:28:47.056885+00
\.


--
-- Data for Name: runtime_alerts; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.runtime_alerts (cluster_id, alert_type, namespace, pod_name, container_name, process_name, process_args, severity, description, source_ip, destination_ip, destination_port, mitre_technique, status, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sbom_components; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.sbom_components (organization_id, sbom_id, component_id, relationship_type, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sboms; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.sboms (organization_id, name, application_name, application_version, sbom_format, spec_version, created_by_tool, created_by_user, components_count, total_dependencies, direct_dependencies, transitive_dependencies, license_risk_score, vulnerability_risk_score, compliance_status, sbom_content, last_generated, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: scan_profiles; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.scan_profiles (name, description, scanner_type, target_ranges, scan_policy, credentials_encrypted, schedule_cron, last_scan_date, next_scan_date, enabled, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: scap_profiles; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.scap_profiles (name, profile_type, description, content_path, content_hash, platform_applicable, check_count, is_enabled, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: security_awareness_scores; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.security_awareness_scores (user_email, user_name, department, overall_score, phishing_score, training_completion_rate, campaigns_participated, times_clicked, times_reported, times_submitted_credentials, last_failed_campaign, risk_category, training_assignments, certifications, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: security_posture_scores; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.security_posture_scores (simulation_id, score_type, score, max_score, breakdown, comparison_to_previous, recommendations, assessed_at, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sensitive_data_discoveries; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.sensitive_data_discoveries (organization_id, scan_id, scan_type, target, status, total_files_scanned, sensitive_files_found, classification_breakdown, findings, started_at, completed_at, next_scheduled_scan, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: shared_artifacts; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.shared_artifacts (organization_id, room_id, uploaded_by, artifact_type, file_name, file_hash, file_size_bytes, description, classification_level, access_restricted_to, download_count, analysis_status, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: siem_data_sources; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.siem_data_sources (name, description, source_type, connection_config, parser_config, enabled, last_event_at, events_today, error_count, last_error, organization_id, id, created_at, updated_at) FROM stdin;
Edge Firewall	Palo Alto PA-5250 edge firewall	syslog	\N	\N	t	\N	0	0	\N	\N	7a7ff0d5-e154-443e-98d0-89188d9a3758	2026-03-23 06:46:35.381782+00	2026-03-31 03:11:42.381787+00
Domain Controller	Windows Server 2022 AD DC	windows_event	\N	\N	t	\N	0	0	\N	\N	55fbce64-6fbb-470f-9ea3-7fc19698b53a	2026-03-23 04:25:56.381865+00	2026-03-31 03:11:42.381869+00
AWS CloudTrail	AWS account us-east-1 CloudTrail	cloud_trail	\N	\N	t	\N	0	0	\N	\N	4c2ce568-415c-4e17-9c55-7f6cf39bb9ff	2026-01-19 21:21:41.381929+00	2026-03-31 03:11:42.381932+00
EDR Console	CrowdStrike Falcon EDR	json_api	\N	\N	t	\N	0	0	\N	\N	ec5d1545-ad49-4079-b1fa-6c5aeb966b19	2026-02-03 16:31:32.381982+00	2026-03-31 03:11:42.381985+00
IDS Sensor	Suricata IDS network sensor	cef	\N	\N	t	\N	0	0	\N	\N	fd7c1e01-b622-4d35-98ab-532c91455252	2026-03-11 02:24:06.382039+00	2026-03-31 03:11:42.382042+00
ghikgi	test	cloud_trail	{}	\N	t	\N	0	0	\N	\N	c60d64bc-ce46-4ca1-81c9-56d77de17963	2026-04-07 11:56:59.583773+00	2026-04-07 11:56:59.583778+00
\.


--
-- Data for Name: siem_saved_searches; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.siem_saved_searches (name, description, query, filters, time_range, is_alert, alert_threshold, schedule_cron, last_run_at, last_result_count, organization_id, created_by, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: simulation_tests; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.simulation_tests (simulation_id, technique_id, test_name, test_order, status, target_host, executor, command_executed, cleanup_command, cleanup_status, output, error_output, started_at, completed_at, was_detected, detection_time_seconds, detection_source, detection_details, notes, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: soc_agents; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.soc_agents (name, agent_type, organization_id, status, current_task_id, capabilities, llm_model, temperature, max_reasoning_steps, autonomy_level, total_investigations, avg_resolution_time_minutes, accuracy_score, false_positive_rate, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: software_components; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.software_components (organization_id, name, version, vendor, package_type, license_type, license_spdx_id, purl, cpe, checksum_sha256, source_url, is_direct_dependency, parent_component_id, depth_level, known_vulnerabilities_count, risk_score, last_scanned, id, created_at, updated_at) FROM stdin;
1489f1c5-9a2e-4189-8bde-89e1148ca606	log4j-core	2.18.0	\N	binary	\N	\N	\N	\N	\N	\N	t	\N	0	0	0	\N	7066d280-546b-46a2-a9e5-b3294135233f	2026-04-07 03:55:33.338256+00	2026-04-07 03:55:33.338262+00
\.


--
-- Data for Name: stig_benchmarks; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.stig_benchmarks (benchmark_id, title, version, release, description, platform, total_rules, category_1_count, category_2_count, category_3_count, status, last_scan_at, tags, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stig_rules; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.stig_rules (benchmark_id_ref, rule_id, stig_id, group_id, severity, title, description, check_text, fix_text, cci, nist_controls, automated_check, is_automatable, default_status, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stig_scan_results; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.stig_scan_results (benchmark_id_ref, target_host, target_ip, scan_type, scanner, status, started_at, completed_at, total_checks, open_findings, not_a_finding, not_applicable, not_reviewed, compliance_percentage, cat1_open, cat2_open, cat3_open, findings, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: supply_chain_risks; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.supply_chain_risks (organization_id, component_id, risk_type, severity, description, evidence, cve_ids, remediation_advice, status, detected_date, remediation_date, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: target_groups; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.target_groups (name, description, department, members, member_count, risk_level, avg_click_rate, campaigns_participated, last_campaign_date, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.team_members (team_id, user_id, role, id, created_at, updated_at) FROM stdin;
46b9aa35-460f-4219-bf00-36e655d466cd	765b349b-c587-4281-b9ce-8506bf3738a2	lead	f871e28e-5d73-4b08-8487-5ccb1aae1809	2026-04-08 01:23:39.393521+00	2026-04-08 01:23:39.393526+00
0a48ae24-1304-4d08-bf03-f9fe5e1a2818	765b349b-c587-4281-b9ce-8506bf3738a2	lead	5aab29a0-aefa-4291-8045-6a06235c51c0	2026-04-08 01:27:29.888495+00	2026-04-08 01:27:29.8885+00
6c447b9c-b0de-493d-9a5b-1e8f2347e398	765b349b-c587-4281-b9ce-8506bf3738a2	lead	6a42d442-a2b9-4dbc-bd9c-dd44cbfc42e2	2026-04-08 01:29:02.270977+00	2026-04-08 01:29:02.270982+00
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.teams (name, description, organization_id, is_default, id, created_at, updated_at) FROM stdin;
Security Team	Core security ops	68954722-881d-4ba9-bd9e-b900b27ad5de	f	46b9aa35-460f-4219-bf00-36e655d466cd	2026-04-08 01:23:39.388003+00	2026-04-08 01:23:39.388008+00
Security Team	Core security ops	68954722-881d-4ba9-bd9e-b900b27ad5de	f	0a48ae24-1304-4d08-bf03-f9fe5e1a2818	2026-04-08 01:27:29.885287+00	2026-04-08 01:27:29.885293+00
pysoar 	test	68954722-881d-4ba9-bd9e-b900b27ad5de	f	6c447b9c-b0de-493d-9a5b-1e8f2347e398	2026-04-08 01:29:02.269286+00	2026-04-08 01:29:02.269292+00
\.


--
-- Data for Name: threat_actors; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.threat_actors (name, aliases, description, actor_type, sophistication, country_of_origin, first_observed, last_observed, primary_motivation, secondary_motivations, mitre_groups, known_ttps, target_sectors, target_countries, associated_campaigns, confidence, "references", tags, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: threat_campaigns; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.threat_campaigns (name, description, status, actor_id, first_observed, last_observed, objectives, target_sectors, target_countries, associated_indicators, mitre_techniques, confidence, "references", tags, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: threat_feeds; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.threat_feeds (name, feed_type, url, provider, description, is_enabled, is_builtin, auth_type, auth_config, poll_interval_minutes, last_poll_at, last_success_at, last_error, total_indicators, confidence_weight, tags, organization_id, id, created_at, updated_at) FROM stdin;
AlienVault OTX	stix	https://otx.alienvault.com	\N	\N	t	f	\N	\N	60	\N	\N	\N	0	1	[]	\N	8cfce2bf-8620-4bab-bd56-96ad6f80e7b2	2026-01-02 00:43:24.72211+00	2026-04-02 00:43:24.722122+00
URLhaus	csv	https://urlhaus.abuse.ch	\N	\N	t	f	\N	\N	60	\N	\N	\N	0	1	[]	\N	3645cc85-01fc-4a7d-84b6-56bc4c891787	2026-01-02 00:43:24.722362+00	2026-04-02 00:43:24.722367+00
AbuseIPDB	json_api	https://api.abuseipdb.com	\N	\N	t	f	\N	\N	60	\N	\N	\N	0	1	[]	\N	3dc7c5cb-50cd-4cad-8bcf-0ddce3a8356c	2026-01-02 00:43:24.722454+00	2026-04-02 00:43:24.722457+00
TestFeed	stix	https://example.com/feed	manual	\N	t	f	\N	null	60	\N	\N	\N	0	1	[]	1489f1c5-9a2e-4189-8bde-89e1148ca606	d979b35e-0825-4950-9ce3-5242e54020bb	2026-04-06 01:05:09.978725+00	2026-04-06 01:05:09.978731+00
SaveFeed	stix	https://feed.test	test	\N	t	f	\N	null	60	\N	\N	\N	0	1	[]	1489f1c5-9a2e-4189-8bde-89e1148ca606	7ef4fbbe-db1d-431e-b455-31de2bb3c985	2026-04-06 01:06:37.534033+00	2026-04-06 01:06:37.534038+00
FinalF	stix	https://final.test	t	\N	t	f	\N	null	60	\N	\N	\N	0	1	[]	1489f1c5-9a2e-4189-8bde-89e1148ca606	a8fbb304-061d-4aec-8acb-f3873081d39b	2026-04-06 01:13:11.386021+00	2026-04-06 01:13:11.386027+00
Z	stix	https://z.com	t	\N	t	f	\N	null	60	\N	\N	\N	0	1	[]	1489f1c5-9a2e-4189-8bde-89e1148ca606	1a0bd099-b1cc-4d4c-ac16-4076f40ac212	2026-04-06 01:30:06.355707+00	2026-04-06 01:30:06.355713+00
F	stix	https://f.test	t	\N	t	f	\N	null	60	\N	\N	\N	0	1	[]	1489f1c5-9a2e-4189-8bde-89e1148ca606	3b1bbdb4-3922-4c76-8283-08374af25ac9	2026-04-06 01:39:37.311363+00	2026-04-06 01:39:37.31137+00
\.


--
-- Data for Name: threat_indicators; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.threat_indicators (indicator_type, value, feed_id, source, confidence, severity, tlp, first_seen, last_seen, expires_at, is_active, is_whitelisted, kill_chain_phase, mitre_tactics, mitre_techniques, tags, context, related_indicators, sighting_count, last_sighting_at, false_positive_count, organization_id, id, created_at, updated_at) FROM stdin;
ip	185.220.101.45	\N	threat_feed	85	critical	\N	2026-03-03 00:43:24.722535+00	2026-04-01 22:43:24.722538+00	\N	t	f	\N	[]	[]	[]	{}	[]	0	\N	0	\N	f36993ab-6a96-4656-8b22-9ca48b186613	2026-03-03 00:43:24.722543+00	2026-04-02 00:43:24.722545+00
domain	evil-update.com	\N	threat_feed	85	critical	\N	2026-03-03 00:43:24.722667+00	2026-04-01 22:43:24.722669+00	\N	t	f	\N	[]	[]	[]	{}	[]	0	\N	0	\N	c8da6257-12df-45e2-8118-2d8751f57899	2026-03-03 00:43:24.722672+00	2026-04-02 00:43:24.722674+00
ip	45.33.32.156	\N	threat_feed	85	high	\N	2026-03-03 00:43:24.722859+00	2026-04-01 22:43:24.722863+00	\N	t	f	\N	[]	[]	[]	{}	[]	0	\N	0	\N	c5e33964-dd53-4c37-8395-95f2309ece25	2026-03-03 00:43:24.722865+00	2026-04-02 00:43:24.722867+00
domain	malware-delivery.net	\N	threat_feed	85	high	\N	2026-03-03 00:43:24.722947+00	2026-04-01 22:43:24.722949+00	\N	t	f	\N	[]	[]	[]	{}	[]	0	\N	0	\N	d84bd811-c59c-4367-9a91-18b3b68628f8	2026-03-03 00:43:24.722952+00	2026-04-02 00:43:24.722953+00
url	http://bad-site.ru/payload.exe	\N	threat_feed	85	critical	\N	2026-03-03 00:43:24.72303+00	2026-04-01 22:43:24.723033+00	\N	t	f	\N	[]	[]	[]	{}	[]	0	\N	0	\N	71f76f48-930a-428d-ba32-6978274b6d99	2026-03-03 00:43:24.723036+00	2026-04-02 00:43:24.723038+00
md5	a1b2c3d4e5f6a7b8	\N	threat_feed	85	high	\N	2026-03-03 00:43:24.723128+00	2026-04-01 22:43:24.723131+00	\N	t	f	\N	[]	[]	[]	{}	[]	0	\N	0	\N	555d4f33-f400-4b21-ad57-10de247131d8	2026-03-03 00:43:24.723133+00	2026-04-02 00:43:24.723135+00
sha256	5d41402abc4b2a76	\N	threat_feed	85	medium	\N	2026-03-03 00:43:24.723207+00	2026-04-01 22:43:24.723209+00	\N	t	f	\N	[]	[]	[]	{}	[]	0	\N	0	\N	dc993cb9-44f6-4b25-ae11-1742f449b650	2026-03-03 00:43:24.723211+00	2026-04-02 00:43:24.723213+00
ip	103.45.67.89	\N	threat_feed	85	medium	\N	2026-03-03 00:43:24.723292+00	2026-04-01 22:43:24.723294+00	\N	t	f	\N	[]	[]	[]	{}	[]	0	\N	0	\N	63082619-b7db-4a0a-92cb-1e62b4d142fd	2026-03-03 00:43:24.723297+00	2026-04-02 00:43:24.723298+00
domain	phishing-portal.xyz	\N	threat_feed	85	high	\N	2026-03-03 00:43:24.723366+00	2026-04-01 22:43:24.723368+00	\N	t	f	\N	[]	[]	[]	{}	[]	0	\N	0	\N	eb96521a-05cd-4dc2-8144-fbebe8a77f74	2026-03-03 00:43:24.723371+00	2026-04-02 00:43:24.723372+00
ip	44.33.22.11	\N	threat_feed	85	low	\N	2026-03-03 00:43:24.723437+00	2026-04-01 22:43:24.723439+00	\N	t	f	\N	[]	[]	[]	{}	[]	0	\N	0	\N	c99818b7-7153-490c-8e30-024f969c28f6	2026-03-03 00:43:24.723441+00	2026-04-02 00:43:24.723443+00
domain	evil.com	\N	manual	90	medium	amber	2026-04-06 01:06:37.766461+00	2026-04-06 01:06:37.766465+00	\N	t	f	\N	[]	[]	[]	{}	[]	0	\N	0	1489f1c5-9a2e-4189-8bde-89e1148ca606	a62ee4d2-0c3b-4bda-aa24-974bb5072a83	2026-04-06 01:06:37.768674+00	2026-04-06 01:06:37.768679+00
domain	final.evil	\N	t	80	medium	amber	2026-04-06 01:13:11.669933+00	2026-04-06 01:13:11.669937+00	\N	t	f	\N	[]	[]	[]	{}	[]	0	\N	0	1489f1c5-9a2e-4189-8bde-89e1148ca606	e6844475-075d-461f-b4bd-cbb019c26128	2026-04-06 01:13:11.672341+00	2026-04-06 01:13:11.672346+00
domain	z.evil	\N	t	90	medium	amber	2026-04-06 01:30:06.618577+00	2026-04-06 01:30:06.618582+00	\N	t	f	\N	[]	[]	[]	{}	[]	0	\N	0	1489f1c5-9a2e-4189-8bde-89e1148ca606	58b090dc-fdae-425d-aec6-e64198d09e1f	2026-04-06 01:30:06.631367+00	2026-04-06 01:30:06.631373+00
domain	f.evil	\N	t	80	medium	amber	2026-04-06 01:39:37.53915+00	2026-04-06 01:39:37.539154+00	\N	t	f	\N	[]	[]	[]	{}	[]	0	\N	0	1489f1c5-9a2e-4189-8bde-89e1148ca606	a964ee47-4fff-4640-bb60-4e9e2830e23e	2026-04-06 01:39:37.541272+00	2026-04-06 01:39:37.541276+00
\.


--
-- Data for Name: threat_mitigations; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.threat_mitigations (organization_id, threat_id, mitigation_type, title, description, implementation_status, control_reference, effectiveness_score, cost_estimate_usd, assigned_to, deadline, verification_method, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: threat_model_components; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.threat_model_components (organization_id, model_id, component_type, name, description, technology_stack, data_classification, trust_level, "position", connections, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: threat_models; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.threat_models (organization_id, name, description, application_name, version, methodology, status, scope, architecture_description, data_flow_diagram, created_by, reviewed_by, review_date, risk_score, threats_count, mitigations_count, id, created_at, updated_at) FROM stdin;
1489f1c5-9a2e-4189-8bde-89e1148ca606	Test Model	Test	TestApp	1.0	stride	draft	\N	\N	\N	765b349b-c587-4281-b9ce-8506bf3738a2	\N	\N	0	0	0	3b0ca3fa-9e44-498e-8fa7-52250fdfb6c4	2026-04-06 00:54:12.577753+00	2026-04-06 00:54:12.57776+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	TM2	\N	App	1.0	stride	draft	\N	\N	\N	765b349b-c587-4281-b9ce-8506bf3738a2	\N	\N	0	0	0	ae03feed-1371-4b36-9bc4-aa1ea21c04b3	2026-04-06 01:10:47.752398+00	2026-04-06 01:10:47.752402+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	FinalTM	\N	App	1.0	stride	draft	\N	\N	\N	765b349b-c587-4281-b9ce-8506bf3738a2	\N	\N	0	0	0	cb2edf38-7a25-49ad-9790-5ce949b6f311	2026-04-06 01:13:13.969329+00	2026-04-06 01:13:13.969335+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	Z	\N	Z	1.0	stride	draft	\N	\N	\N	765b349b-c587-4281-b9ce-8506bf3738a2	\N	\N	0	0	0	5a37535a-5967-4fc1-9692-a76c35bde71a	2026-04-06 01:30:08.904642+00	2026-04-06 01:30:08.904647+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	F	\N	F	1.0	stride	draft	\N	\N	\N	765b349b-c587-4281-b9ce-8506bf3738a2	\N	\N	0	0	0	558fa920-826c-4946-aea1-1f88229523ed	2026-04-06 01:39:39.646451+00	2026-04-06 01:39:39.646457+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	Test	test	test	1.0	pasta	draft	\N	\N	\N	765b349b-c587-4281-b9ce-8506bf3738a2	\N	\N	0	0	0	019d9c1a-294e-4d68-9053-e3050d6024d6	2026-04-06 11:50:25.188581+00	2026-04-06 11:50:25.188586+00
1489f1c5-9a2e-4189-8bde-89e1148ca606	TM-test	\N	App	1.0	stride	draft	\N	\N	\N	765b349b-c587-4281-b9ce-8506bf3738a2	\N	\N	0	1	0	8d23aef0-956a-453e-be24-532afd3b263d	2026-04-07 03:20:34.744276+00	2026-04-07 03:28:45.365624+00
\.


--
-- Data for Name: threat_predictions; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.threat_predictions (prediction_type, entity_type, entity_id, risk_score, probability, time_horizon_hours, contributing_factors, recommended_actions, mitre_techniques, model_id, expires_at, was_accurate, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ticket_activities; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.ticket_activities (source_type, source_id, activity_type, actor_id, description, old_value, new_value, metadata, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ticket_comments; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.ticket_comments (source_type, source_id, content, author_id, parent_comment_id, mentioned_users, is_edited, edited_at, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ticket_links; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.ticket_links (source_type_a, source_id_a, source_type_b, source_id_b, link_type, created_by, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ueba_risk_alerts; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.ueba_risk_alerts (entity_profile_id, alert_type, severity, risk_score_delta, description, evidence, contributing_events, mitre_techniques, status, analyst_notes, escalated_to_incident, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: unified_data_models; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.unified_data_models (organization_id, name, description, entity_type, schema_version, field_definitions, normalization_rules, enrichment_rules, sample_data, is_active, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.users (email, hashed_password, full_name, role, is_active, is_superuser, phone, department, avatar_url, last_login, id, created_at, updated_at, force_password_change, mfa_enabled, mfa_secret, mfa_backup_codes, organization_id) FROM stdin;
jacobspeart@gmail.com	$2b$12$ACY8FPlxC/c9wXSeeAoXWeg5JV4ndpvew1mGJBDyx86w5hccUt6Cq	Admin User	admin	t	t	\N	\N	\N	2026-04-08T01:58:43.399542+00:00	765b349b-c587-4281-b9ce-8506bf3738a2	2026-03-17 15:23:48.354743+00	2026-04-08 01:58:43.401563+00	f	f	\N	\N	1489f1c5-9a2e-4189-8bde-89e1148ca606
eranbrown92@gmail.com	$2b$12$KQlJQPbZLBL.EwUlQH7IoOqXcpQDESF/K7VSqJOo1sTzMfVUVTrH2	Eran Brown	analyst	t	f	\N	\N	\N	2026-03-17T16:12:01.500767+00:00	d8de3927-7012-4cea-a43e-6f9f4655ea85	2026-03-17 15:46:39.730833+00	2026-03-17 16:12:01.501347+00	f	f	\N	\N	1489f1c5-9a2e-4189-8bde-89e1148ca606
\.


--
-- Data for Name: vendor_assessments; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.vendor_assessments (organization_id, vendor_name, vendor_url, assessment_type, assessment_date, security_score, questionnaire_responses, certifications, last_incident_date, incident_count, contract_expiry, data_handling_classification, third_party_subprocessors, risk_tier, notes, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: visual_playbook_executions; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.visual_playbook_executions (playbook_id, organization_id, parent_execution_id, trigger_event, status, current_node_id, started_at, completed_at, duration_ms, execution_path, variables, error_message, triggered_by, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: visual_playbooks; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.visual_playbooks (organization_id, name, description, version, category, status, trigger_type, trigger_config, canvas_data, execution_count, avg_execution_time_ms, success_rate, last_executed, created_by, is_template, template_category, id, created_at, updated_at) FROM stdin;
1489f1c5-9a2e-4189-8bde-89e1148ca606	Test Playbook 	A test	2	custom	active	alert	\N	\N	0	0	0	\N	\N	f	\N	6762375a-2131-498d-9676-4bb3f8927870	2026-04-06 00:12:17.322725+00	2026-04-06 00:44:19.657594+00
\.


--
-- Data for Name: vulnerabilities; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.vulnerabilities (cve_id, title, description, cvss_v3_score, cvss_v3_vector, epss_score, severity, vulnerability_type, cwe_id, mitre_technique_ids, affected_software, affected_versions, published_date, modified_date, exploit_available, exploit_maturity, patch_available, patch_url, "references", kev_listed, organization_id, id, created_at, updated_at) FROM stdin;
CVE-2024-9999	Test Vuln	\N	\N	\N	\N	high	\N	\N	null	\N	null	\N	\N	f	unproven	f	\N	null	f	1489f1c5-9a2e-4189-8bde-89e1148ca606	6e777c31-7639-44ff-aec6-a143ee4cf9ab	2026-04-08 00:18:09.474983+00	2026-04-08 00:18:09.474989+00
\.


--
-- Data for Name: vulnerability_exceptions; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.vulnerability_exceptions (vulnerability_instance_id, exception_type, justification, approved_by, approval_date, expiry_date, review_date, compensating_control_description, risk_acceptance_level, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: vulnerability_instances; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.vulnerability_instances (vulnerability_id, asset_id, asset_name, asset_ip, asset_type, discovered_by, scan_id, first_seen, last_seen, status, risk_score, exploitability_score, business_criticality, assigned_to, remediation_deadline, sla_status, organization_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: war_room_messages; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.war_room_messages (organization_id, room_id, sender_id, sender_name, message_type, content, attachments, mentioned_users, is_pinned, is_edited, edited_at, parent_message_id, reactions, metadata, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: war_rooms; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.war_rooms (organization_id, name, description, incident_id, room_type, status, severity_level, commander_id, participants, max_participants, auto_archive_hours, created_by, pinned_items, tags, is_encrypted, id, created_at, updated_at) FROM stdin;
1489f1c5-9a2e-4189-8bde-89e1148ca606	Test Room	t	\N	incident	active	high	\N	["765b349b-c587-4281-b9ce-8506bf3738a2"]	50	\N	765b349b-c587-4281-b9ce-8506bf3738a2	[]	[]	f	a04f77c2-f828-4208-9360-5b639156a879	2026-04-07 03:29:11.904062+00	2026-04-07 03:29:11.904067+00
\.


--
-- Data for Name: webhook_endpoints; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.webhook_endpoints (organization_id, installed_id, endpoint_path, http_method, secret_hash, event_types, transform_template, is_active, last_received, received_count, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: zero_trust_policies; Type: TABLE DATA; Schema: public; Owner: pysoar
--

COPY public.zero_trust_policies (name, policy_type, description, conditions, actions, risk_threshold, requires_mfa, requires_device_trust, minimum_device_trust_score, allowed_locations, blocked_locations, time_restrictions, data_classification_required, microsegment_id, is_enabled, priority, hit_count, last_triggered_at, tags, organization_id, id, created_at, updated_at) FROM stdin;
Z	access	t	[]	[]	50	t	t	70	[]	[]	{}	\N	\N	t	50	0	\N	[]	1489f1c5-9a2e-4189-8bde-89e1148ca606	c918ad57-9dc1-4c34-b8c0-9c46e360e7af	2026-04-06 01:30:13.86901+00	2026-04-06 01:30:13.869015+00
Z	access	t	[]	[]	50	t	t	70	[]	[]	{}	\N	\N	t	50	0	\N	[]	1489f1c5-9a2e-4189-8bde-89e1148ca606	7f0513ab-5a79-4576-a5e9-19320ee79303	2026-04-06 01:30:34.958889+00	2026-04-06 01:30:34.958894+00
Z2	access	t	[]	[]	50	t	t	70	[]	[]	{}	\N	\N	t	50	0	\N	[]	1489f1c5-9a2e-4189-8bde-89e1148ca606	51370d93-5446-4c4f-aa6e-68d813100a2b	2026-04-06 01:35:44.007848+00	2026-04-06 01:35:44.007853+00
F	access	t	[]	[]	50	t	t	70	[]	[]	{}	\N	\N	t	50	0	\N	[]	1489f1c5-9a2e-4189-8bde-89e1148ca606	c7709a95-5908-4c43-8c66-47710827aa89	2026-04-06 01:39:41.714883+00	2026-04-06 01:39:41.714888+00
Test Policy	access	Verify all fields	[]	[]	50	t	t	70	[]	[]	{}	\N	\N	t	50	0	\N	[]	1489f1c5-9a2e-4189-8bde-89e1148ca606	e6fcb890-1f92-4d0a-b62f-5d963749ebbf	2026-04-06 03:31:34.042458+00	2026-04-06 03:31:34.042464+00
Test Policy	access	test	[]	[]	50	t	t	70	[]	[]	{}	\N	\N	t	50	0	\N	[]	1489f1c5-9a2e-4189-8bde-89e1148ca606	fe7a0bb5-d8d4-4ade-880c-4796334f85a2	2026-04-06 03:31:43.440242+00	2026-04-06 03:31:43.440247+00
Verify Policy	access	test	[]	[]	50	t	t	70	[]	[]	{}	\N	\N	t	50	0	\N	[]	1489f1c5-9a2e-4189-8bde-89e1148ca606	b1d754f5-ac33-4e62-9256-ab540616c041	2026-04-06 03:33:04.886282+00	2026-04-06 03:33:04.886287+00
Real Policy	access	test	[]	[]	50	t	t	70	[]	[]	{}	\N	\N	t	50	0	\N	[]	1489f1c5-9a2e-4189-8bde-89e1148ca606	cdd8c58e-879f-4a7e-9b7f-5baba07867e2	2026-04-06 03:50:28.398988+00	2026-04-06 03:50:28.398993+00
Real ZT Policy	access	test	[]	[]	50	t	t	70	[]	[]	{}	\N	\N	t	50	0	\N	[]	1489f1c5-9a2e-4189-8bde-89e1148ca606	c021b06f-599e-4f71-821b-18d51d632564	2026-04-06 03:52:44.22628+00	2026-04-06 03:52:44.226284+00
\.


--
-- Name: access_anomalies access_anomalies_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.access_anomalies
    ADD CONSTRAINT access_anomalies_pkey PRIMARY KEY (id);


--
-- Name: access_decisions access_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.access_decisions
    ADD CONSTRAINT access_decisions_pkey PRIMARY KEY (id);


--
-- Name: action_items action_items_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.action_items
    ADD CONSTRAINT action_items_pkey PRIMARY KEY (id);


--
-- Name: adversary_profiles adversary_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.adversary_profiles
    ADD CONSTRAINT adversary_profiles_pkey PRIMARY KEY (id);


--
-- Name: agent_actions agent_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.agent_actions
    ADD CONSTRAINT agent_actions_pkey PRIMARY KEY (id);


--
-- Name: agent_memories agent_memories_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.agent_memories
    ADD CONSTRAINT agent_memories_pkey PRIMARY KEY (id);


--
-- Name: ai_analyses ai_analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ai_analyses
    ADD CONSTRAINT ai_analyses_pkey PRIMARY KEY (id);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: anomaly_detections anomaly_detections_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.anomaly_detections
    ADD CONSTRAINT anomaly_detections_pkey PRIMARY KEY (id);


--
-- Name: api_anomaly_detection api_anomaly_detection_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.api_anomaly_detection
    ADD CONSTRAINT api_anomaly_detection_pkey PRIMARY KEY (id);


--
-- Name: api_compliance_checks api_compliance_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.api_compliance_checks
    ADD CONSTRAINT api_compliance_checks_pkey PRIMARY KEY (id);


--
-- Name: api_endpoint_inventory api_endpoint_inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.api_endpoint_inventory
    ADD CONSTRAINT api_endpoint_inventory_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: api_security_policies api_security_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.api_security_policies
    ADD CONSTRAINT api_security_policies_pkey PRIMARY KEY (id);


--
-- Name: api_vulnerabilities api_vulnerabilities_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.api_vulnerabilities
    ADD CONSTRAINT api_vulnerabilities_pkey PRIMARY KEY (id);


--
-- Name: asset_vulnerabilities asset_vulnerabilities_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.asset_vulnerabilities
    ADD CONSTRAINT asset_vulnerabilities_pkey PRIMARY KEY (id);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: attack_simulations attack_simulations_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.attack_simulations
    ADD CONSTRAINT attack_simulations_pkey PRIMARY KEY (id);


--
-- Name: attack_surfaces attack_surfaces_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.attack_surfaces
    ADD CONSTRAINT attack_surfaces_pkey PRIMARY KEY (id);


--
-- Name: attack_techniques attack_techniques_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.attack_techniques
    ADD CONSTRAINT attack_techniques_pkey PRIMARY KEY (id);


--
-- Name: attack_trees attack_trees_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.attack_trees
    ADD CONSTRAINT attack_trees_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: audit_trails audit_trails_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.audit_trails
    ADD CONSTRAINT audit_trails_pkey PRIMARY KEY (id);


--
-- Name: automated_evidence_rules automated_evidence_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.automated_evidence_rules
    ADD CONSTRAINT automated_evidence_rules_pkey PRIMARY KEY (id);


--
-- Name: automation_rules automation_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.automation_rules
    ADD CONSTRAINT automation_rules_pkey PRIMARY KEY (id);


--
-- Name: behavior_baselines behavior_baselines_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.behavior_baselines
    ADD CONSTRAINT behavior_baselines_pkey PRIMARY KEY (id);


--
-- Name: behavior_events behavior_events_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.behavior_events
    ADD CONSTRAINT behavior_events_pkey PRIMARY KEY (id);


--
-- Name: business_impact_assessments business_impact_assessments_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.business_impact_assessments
    ADD CONSTRAINT business_impact_assessments_pkey PRIMARY KEY (id);


--
-- Name: campaign_events campaign_events_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.campaign_events
    ADD CONSTRAINT campaign_events_pkey PRIMARY KEY (id);


--
-- Name: case_attachments case_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.case_attachments
    ADD CONSTRAINT case_attachments_pkey PRIMARY KEY (id);


--
-- Name: case_notes case_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.case_notes
    ADD CONSTRAINT case_notes_pkey PRIMARY KEY (id);


--
-- Name: case_tasks case_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.case_tasks
    ADD CONSTRAINT case_tasks_pkey PRIMARY KEY (id);


--
-- Name: case_timeline case_timeline_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.case_timeline
    ADD CONSTRAINT case_timeline_pkey PRIMARY KEY (id);


--
-- Name: cisa_directives cisa_directives_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.cisa_directives
    ADD CONSTRAINT cisa_directives_pkey PRIMARY KEY (id);


--
-- Name: compliance_assessments compliance_assessments_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.compliance_assessments
    ADD CONSTRAINT compliance_assessments_pkey PRIMARY KEY (id);


--
-- Name: compliance_controls compliance_controls_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.compliance_controls
    ADD CONSTRAINT compliance_controls_pkey PRIMARY KEY (id);


--
-- Name: compliance_evidence compliance_evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.compliance_evidence
    ADD CONSTRAINT compliance_evidence_pkey PRIMARY KEY (id);


--
-- Name: compliance_frameworks compliance_frameworks_name_key; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.compliance_frameworks
    ADD CONSTRAINT compliance_frameworks_name_key UNIQUE (name);


--
-- Name: compliance_frameworks compliance_frameworks_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.compliance_frameworks
    ADD CONSTRAINT compliance_frameworks_pkey PRIMARY KEY (id);


--
-- Name: consent_records consent_records_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.consent_records
    ADD CONSTRAINT consent_records_pkey PRIMARY KEY (id);


--
-- Name: container_images container_images_digest_sha256_key; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.container_images
    ADD CONSTRAINT container_images_digest_sha256_key UNIQUE (digest_sha256);


--
-- Name: container_images container_images_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.container_images
    ADD CONSTRAINT container_images_pkey PRIMARY KEY (id);


--
-- Name: correlation_events correlation_events_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.correlation_events
    ADD CONSTRAINT correlation_events_pkey PRIMARY KEY (id);


--
-- Name: credential_exposures credential_exposures_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.credential_exposures
    ADD CONSTRAINT credential_exposures_pkey PRIMARY KEY (id);


--
-- Name: cui_markings cui_markings_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.cui_markings
    ADD CONSTRAINT cui_markings_pkey PRIMARY KEY (id);


--
-- Name: darkweb_brand_threats darkweb_brand_threats_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.darkweb_brand_threats
    ADD CONSTRAINT darkweb_brand_threats_pkey PRIMARY KEY (id);


--
-- Name: darkweb_credential_leaks darkweb_credential_leaks_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.darkweb_credential_leaks
    ADD CONSTRAINT darkweb_credential_leaks_pkey PRIMARY KEY (id);


--
-- Name: darkweb_findings darkweb_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.darkweb_findings
    ADD CONSTRAINT darkweb_findings_pkey PRIMARY KEY (id);


--
-- Name: darkweb_monitors darkweb_monitors_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.darkweb_monitors
    ADD CONSTRAINT darkweb_monitors_pkey PRIMARY KEY (id);


--
-- Name: data_classifications data_classifications_name_key; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.data_classifications
    ADD CONSTRAINT data_classifications_name_key UNIQUE (name);


--
-- Name: data_classifications data_classifications_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.data_classifications
    ADD CONSTRAINT data_classifications_pkey PRIMARY KEY (id);


--
-- Name: data_partitions data_partitions_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.data_partitions
    ADD CONSTRAINT data_partitions_pkey PRIMARY KEY (id);


--
-- Name: data_pipelines data_pipelines_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.data_pipelines
    ADD CONSTRAINT data_pipelines_pkey PRIMARY KEY (id);


--
-- Name: data_processing_records data_processing_records_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.data_processing_records
    ADD CONSTRAINT data_processing_records_pkey PRIMARY KEY (id);


--
-- Name: data_sources data_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.data_sources
    ADD CONSTRAINT data_sources_pkey PRIMARY KEY (id);


--
-- Name: data_subject_requests data_subject_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.data_subject_requests
    ADD CONSTRAINT data_subject_requests_pkey PRIMARY KEY (id);


--
-- Name: deception_campaigns deception_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.deception_campaigns
    ADD CONSTRAINT deception_campaigns_pkey PRIMARY KEY (id);


--
-- Name: decoy_interactions decoy_interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.decoy_interactions
    ADD CONSTRAINT decoy_interactions_pkey PRIMARY KEY (id);


--
-- Name: decoys decoys_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.decoys
    ADD CONSTRAINT decoys_pkey PRIMARY KEY (id);


--
-- Name: detection_rules detection_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.detection_rules
    ADD CONSTRAINT detection_rules_pkey PRIMARY KEY (id);


--
-- Name: device_trust_profiles device_trust_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.device_trust_profiles
    ADD CONSTRAINT device_trust_profiles_pkey PRIMARY KEY (id);


--
-- Name: dlp_incidents dlp_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.dlp_incidents
    ADD CONSTRAINT dlp_incidents_pkey PRIMARY KEY (id);


--
-- Name: dlp_policies dlp_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.dlp_policies
    ADD CONSTRAINT dlp_policies_pkey PRIMARY KEY (id);


--
-- Name: dlp_violations dlp_violations_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.dlp_violations
    ADD CONSTRAINT dlp_violations_pkey PRIMARY KEY (id);


--
-- Name: entity_profiles entity_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.entity_profiles
    ADD CONSTRAINT entity_profiles_pkey PRIMARY KEY (id);


--
-- Name: evidence_packages evidence_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.evidence_packages
    ADD CONSTRAINT evidence_packages_pkey PRIMARY KEY (id);


--
-- Name: exposure_assets exposure_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.exposure_assets
    ADD CONSTRAINT exposure_assets_pkey PRIMARY KEY (id);


--
-- Name: exposure_scans exposure_scans_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.exposure_scans
    ADD CONSTRAINT exposure_scans_pkey PRIMARY KEY (id);


--
-- Name: exposure_vulnerabilities exposure_vulnerabilities_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.exposure_vulnerabilities
    ADD CONSTRAINT exposure_vulnerabilities_pkey PRIMARY KEY (id);


--
-- Name: fair_analyses fair_analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.fair_analyses
    ADD CONSTRAINT fair_analyses_pkey PRIMARY KEY (id);


--
-- Name: forensic_artifacts forensic_artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.forensic_artifacts
    ADD CONSTRAINT forensic_artifacts_pkey PRIMARY KEY (id);


--
-- Name: forensic_cases forensic_cases_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.forensic_cases
    ADD CONSTRAINT forensic_cases_pkey PRIMARY KEY (id);


--
-- Name: forensic_evidence forensic_evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.forensic_evidence
    ADD CONSTRAINT forensic_evidence_pkey PRIMARY KEY (id);


--
-- Name: forensic_timeline forensic_timeline_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.forensic_timeline
    ADD CONSTRAINT forensic_timeline_pkey PRIMARY KEY (id);


--
-- Name: honey_tokens honey_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.honey_tokens
    ADD CONSTRAINT honey_tokens_pkey PRIMARY KEY (id);


--
-- Name: hunt_findings hunt_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.hunt_findings
    ADD CONSTRAINT hunt_findings_pkey PRIMARY KEY (id);


--
-- Name: hunt_hypotheses hunt_hypotheses_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.hunt_hypotheses
    ADD CONSTRAINT hunt_hypotheses_pkey PRIMARY KEY (id);


--
-- Name: hunt_notebooks hunt_notebooks_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.hunt_notebooks
    ADD CONSTRAINT hunt_notebooks_pkey PRIMARY KEY (id);


--
-- Name: hunt_sessions hunt_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.hunt_sessions
    ADD CONSTRAINT hunt_sessions_pkey PRIMARY KEY (id);


--
-- Name: hunt_templates hunt_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.hunt_templates
    ADD CONSTRAINT hunt_templates_pkey PRIMARY KEY (id);


--
-- Name: identified_threats identified_threats_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.identified_threats
    ADD CONSTRAINT identified_threats_pkey PRIMARY KEY (id);


--
-- Name: identity_profiles identity_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.identity_profiles
    ADD CONSTRAINT identity_profiles_pkey PRIMARY KEY (id);


--
-- Name: identity_threats identity_threats_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.identity_threats
    ADD CONSTRAINT identity_threats_pkey PRIMARY KEY (id);


--
-- Name: identity_verifications identity_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.identity_verifications
    ADD CONSTRAINT identity_verifications_pkey PRIMARY KEY (id);


--
-- Name: image_vulnerabilities image_vulnerabilities_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.image_vulnerabilities
    ADD CONSTRAINT image_vulnerabilities_pkey PRIMARY KEY (id);


--
-- Name: incident_timeline incident_timeline_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.incident_timeline
    ADD CONSTRAINT incident_timeline_pkey PRIMARY KEY (id);


--
-- Name: incidents incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.incidents
    ADD CONSTRAINT incidents_pkey PRIMARY KEY (id);


--
-- Name: indicator_sightings indicator_sightings_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.indicator_sightings
    ADD CONSTRAINT indicator_sightings_pkey PRIMARY KEY (id);


--
-- Name: installed_integrations installed_integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.installed_integrations
    ADD CONSTRAINT installed_integrations_pkey PRIMARY KEY (id);


--
-- Name: integration_actions integration_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.integration_actions
    ADD CONSTRAINT integration_actions_pkey PRIMARY KEY (id);


--
-- Name: integration_connectors integration_connectors_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.integration_connectors
    ADD CONSTRAINT integration_connectors_pkey PRIMARY KEY (id);


--
-- Name: integration_executions integration_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.integration_executions
    ADD CONSTRAINT integration_executions_pkey PRIMARY KEY (id);


--
-- Name: intel_reports intel_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.intel_reports
    ADD CONSTRAINT intel_reports_pkey PRIMARY KEY (id);


--
-- Name: investigations investigations_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.investigations
    ADD CONSTRAINT investigations_pkey PRIMARY KEY (id);


--
-- Name: iocs iocs_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.iocs
    ADD CONSTRAINT iocs_pkey PRIMARY KEY (id);


--
-- Name: k8s_security_findings k8s_security_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.k8s_security_findings
    ADD CONSTRAINT k8s_security_findings_pkey PRIMARY KEY (id);


--
-- Name: kubernetes_clusters kubernetes_clusters_name_key; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.kubernetes_clusters
    ADD CONSTRAINT kubernetes_clusters_name_key UNIQUE (name);


--
-- Name: kubernetes_clusters kubernetes_clusters_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.kubernetes_clusters
    ADD CONSTRAINT kubernetes_clusters_pkey PRIMARY KEY (id);


--
-- Name: legal_holds legal_holds_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.legal_holds
    ADD CONSTRAINT legal_holds_pkey PRIMARY KEY (id);


--
-- Name: log_entries log_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.log_entries
    ADD CONSTRAINT log_entries_pkey PRIMARY KEY (id);


--
-- Name: micro_segments micro_segments_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.micro_segments
    ADD CONSTRAINT micro_segments_pkey PRIMARY KEY (id);


--
-- Name: ml_models ml_models_name_key; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT ml_models_name_key UNIQUE (name);


--
-- Name: ml_models ml_models_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT ml_models_pkey PRIMARY KEY (id);


--
-- Name: nl_queries nl_queries_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.nl_queries
    ADD CONSTRAINT nl_queries_pkey PRIMARY KEY (id);


--
-- Name: organization_members organization_members_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.organization_members
    ADD CONSTRAINT organization_members_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_name_key; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_name_key UNIQUE (name);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: ot_alerts ot_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ot_alerts
    ADD CONSTRAINT ot_alerts_pkey PRIMARY KEY (id);


--
-- Name: ot_assets ot_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ot_assets
    ADD CONSTRAINT ot_assets_pkey PRIMARY KEY (id);


--
-- Name: ot_assets ot_assets_serial_number_key; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ot_assets
    ADD CONSTRAINT ot_assets_serial_number_key UNIQUE (serial_number);


--
-- Name: ot_incidents ot_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ot_incidents
    ADD CONSTRAINT ot_incidents_pkey PRIMARY KEY (id);


--
-- Name: ot_policy_rules ot_policy_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ot_policy_rules
    ADD CONSTRAINT ot_policy_rules_pkey PRIMARY KEY (id);


--
-- Name: ot_zones ot_zones_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ot_zones
    ADD CONSTRAINT ot_zones_pkey PRIMARY KEY (id);


--
-- Name: patch_operations patch_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.patch_operations
    ADD CONSTRAINT patch_operations_pkey PRIMARY KEY (id);


--
-- Name: peer_groups peer_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.peer_groups
    ADD CONSTRAINT peer_groups_pkey PRIMARY KEY (id);


--
-- Name: phishing_campaigns phishing_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.phishing_campaigns
    ADD CONSTRAINT phishing_campaigns_pkey PRIMARY KEY (id);


--
-- Name: phishing_templates phishing_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.phishing_templates
    ADD CONSTRAINT phishing_templates_pkey PRIMARY KEY (id);


--
-- Name: playbook_edges playbook_edges_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.playbook_edges
    ADD CONSTRAINT playbook_edges_pkey PRIMARY KEY (id);


--
-- Name: playbook_executions playbook_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.playbook_executions
    ADD CONSTRAINT playbook_executions_pkey PRIMARY KEY (id);


--
-- Name: playbook_node_executions playbook_node_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.playbook_node_executions
    ADD CONSTRAINT playbook_node_executions_pkey PRIMARY KEY (id);


--
-- Name: playbook_nodes playbook_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.playbook_nodes
    ADD CONSTRAINT playbook_nodes_pkey PRIMARY KEY (id);


--
-- Name: playbooks playbooks_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.playbooks
    ADD CONSTRAINT playbooks_pkey PRIMARY KEY (id);


--
-- Name: poams poams_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.poams
    ADD CONSTRAINT poams_pkey PRIMARY KEY (id);


--
-- Name: privacy_impact_assessments privacy_impact_assessments_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.privacy_impact_assessments
    ADD CONSTRAINT privacy_impact_assessments_pkey PRIMARY KEY (id);


--
-- Name: privacy_incidents privacy_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.privacy_incidents
    ADD CONSTRAINT privacy_incidents_pkey PRIMARY KEY (id);


--
-- Name: privileged_access_events privileged_access_events_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.privileged_access_events
    ADD CONSTRAINT privileged_access_events_pkey PRIMARY KEY (id);


--
-- Name: query_jobs query_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.query_jobs
    ADD CONSTRAINT query_jobs_pkey PRIMARY KEY (id);


--
-- Name: reasoning_steps reasoning_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.reasoning_steps
    ADD CONSTRAINT reasoning_steps_pkey PRIMARY KEY (id);


--
-- Name: remediation_actions remediation_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.remediation_actions
    ADD CONSTRAINT remediation_actions_pkey PRIMARY KEY (id);


--
-- Name: remediation_executions remediation_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.remediation_executions
    ADD CONSTRAINT remediation_executions_pkey PRIMARY KEY (id);


--
-- Name: remediation_integrations remediation_integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.remediation_integrations
    ADD CONSTRAINT remediation_integrations_pkey PRIMARY KEY (id);


--
-- Name: remediation_playbooks remediation_playbooks_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.remediation_playbooks
    ADD CONSTRAINT remediation_playbooks_pkey PRIMARY KEY (id);


--
-- Name: remediation_policies remediation_policies_name_key; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.remediation_policies
    ADD CONSTRAINT remediation_policies_name_key UNIQUE (name);


--
-- Name: remediation_policies remediation_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.remediation_policies
    ADD CONSTRAINT remediation_policies_pkey PRIMARY KEY (id);


--
-- Name: remediation_tickets remediation_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.remediation_tickets
    ADD CONSTRAINT remediation_tickets_pkey PRIMARY KEY (id);


--
-- Name: risk_controls risk_controls_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.risk_controls
    ADD CONSTRAINT risk_controls_pkey PRIMARY KEY (id);


--
-- Name: risk_registers risk_registers_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.risk_registers
    ADD CONSTRAINT risk_registers_pkey PRIMARY KEY (id);


--
-- Name: risk_scenarios risk_scenarios_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.risk_scenarios
    ADD CONSTRAINT risk_scenarios_pkey PRIMARY KEY (id);


--
-- Name: runtime_alerts runtime_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.runtime_alerts
    ADD CONSTRAINT runtime_alerts_pkey PRIMARY KEY (id);


--
-- Name: sbom_components sbom_components_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.sbom_components
    ADD CONSTRAINT sbom_components_pkey PRIMARY KEY (id);


--
-- Name: sboms sboms_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.sboms
    ADD CONSTRAINT sboms_pkey PRIMARY KEY (id);


--
-- Name: scan_profiles scan_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.scan_profiles
    ADD CONSTRAINT scan_profiles_pkey PRIMARY KEY (id);


--
-- Name: scap_profiles scap_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.scap_profiles
    ADD CONSTRAINT scap_profiles_pkey PRIMARY KEY (id);


--
-- Name: security_awareness_scores security_awareness_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.security_awareness_scores
    ADD CONSTRAINT security_awareness_scores_pkey PRIMARY KEY (id);


--
-- Name: security_awareness_scores security_awareness_scores_user_email_key; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.security_awareness_scores
    ADD CONSTRAINT security_awareness_scores_user_email_key UNIQUE (user_email);


--
-- Name: security_posture_scores security_posture_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.security_posture_scores
    ADD CONSTRAINT security_posture_scores_pkey PRIMARY KEY (id);


--
-- Name: sensitive_data_discoveries sensitive_data_discoveries_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.sensitive_data_discoveries
    ADD CONSTRAINT sensitive_data_discoveries_pkey PRIMARY KEY (id);


--
-- Name: shared_artifacts shared_artifacts_file_hash_key; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.shared_artifacts
    ADD CONSTRAINT shared_artifacts_file_hash_key UNIQUE (file_hash);


--
-- Name: shared_artifacts shared_artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.shared_artifacts
    ADD CONSTRAINT shared_artifacts_pkey PRIMARY KEY (id);


--
-- Name: siem_data_sources siem_data_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.siem_data_sources
    ADD CONSTRAINT siem_data_sources_pkey PRIMARY KEY (id);


--
-- Name: siem_saved_searches siem_saved_searches_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.siem_saved_searches
    ADD CONSTRAINT siem_saved_searches_pkey PRIMARY KEY (id);


--
-- Name: simulation_tests simulation_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.simulation_tests
    ADD CONSTRAINT simulation_tests_pkey PRIMARY KEY (id);


--
-- Name: soc_agents soc_agents_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.soc_agents
    ADD CONSTRAINT soc_agents_pkey PRIMARY KEY (id);


--
-- Name: software_components software_components_checksum_sha256_key; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.software_components
    ADD CONSTRAINT software_components_checksum_sha256_key UNIQUE (checksum_sha256);


--
-- Name: software_components software_components_cpe_key; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.software_components
    ADD CONSTRAINT software_components_cpe_key UNIQUE (cpe);


--
-- Name: software_components software_components_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.software_components
    ADD CONSTRAINT software_components_pkey PRIMARY KEY (id);


--
-- Name: software_components software_components_purl_key; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.software_components
    ADD CONSTRAINT software_components_purl_key UNIQUE (purl);


--
-- Name: stig_benchmarks stig_benchmarks_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.stig_benchmarks
    ADD CONSTRAINT stig_benchmarks_pkey PRIMARY KEY (id);


--
-- Name: stig_rules stig_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.stig_rules
    ADD CONSTRAINT stig_rules_pkey PRIMARY KEY (id);


--
-- Name: stig_scan_results stig_scan_results_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.stig_scan_results
    ADD CONSTRAINT stig_scan_results_pkey PRIMARY KEY (id);


--
-- Name: supply_chain_risks supply_chain_risks_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.supply_chain_risks
    ADD CONSTRAINT supply_chain_risks_pkey PRIMARY KEY (id);


--
-- Name: target_groups target_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.target_groups
    ADD CONSTRAINT target_groups_pkey PRIMARY KEY (id);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: threat_actors threat_actors_name_key; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_actors
    ADD CONSTRAINT threat_actors_name_key UNIQUE (name);


--
-- Name: threat_actors threat_actors_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_actors
    ADD CONSTRAINT threat_actors_pkey PRIMARY KEY (id);


--
-- Name: threat_campaigns threat_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_campaigns
    ADD CONSTRAINT threat_campaigns_pkey PRIMARY KEY (id);


--
-- Name: threat_feeds threat_feeds_name_key; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_feeds
    ADD CONSTRAINT threat_feeds_name_key UNIQUE (name);


--
-- Name: threat_feeds threat_feeds_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_feeds
    ADD CONSTRAINT threat_feeds_pkey PRIMARY KEY (id);


--
-- Name: threat_indicators threat_indicators_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_indicators
    ADD CONSTRAINT threat_indicators_pkey PRIMARY KEY (id);


--
-- Name: threat_mitigations threat_mitigations_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_mitigations
    ADD CONSTRAINT threat_mitigations_pkey PRIMARY KEY (id);


--
-- Name: threat_model_components threat_model_components_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_model_components
    ADD CONSTRAINT threat_model_components_pkey PRIMARY KEY (id);


--
-- Name: threat_models threat_models_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_models
    ADD CONSTRAINT threat_models_pkey PRIMARY KEY (id);


--
-- Name: threat_predictions threat_predictions_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_predictions
    ADD CONSTRAINT threat_predictions_pkey PRIMARY KEY (id);


--
-- Name: ticket_activities ticket_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ticket_activities
    ADD CONSTRAINT ticket_activities_pkey PRIMARY KEY (id);


--
-- Name: ticket_comments ticket_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ticket_comments
    ADD CONSTRAINT ticket_comments_pkey PRIMARY KEY (id);


--
-- Name: ticket_links ticket_links_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ticket_links
    ADD CONSTRAINT ticket_links_pkey PRIMARY KEY (id);


--
-- Name: ueba_risk_alerts ueba_risk_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ueba_risk_alerts
    ADD CONSTRAINT ueba_risk_alerts_pkey PRIMARY KEY (id);


--
-- Name: entity_profiles uix_entity_profile; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.entity_profiles
    ADD CONSTRAINT uix_entity_profile UNIQUE (entity_type, entity_id, organization_id);


--
-- Name: unified_data_models unified_data_models_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.unified_data_models
    ADD CONSTRAINT unified_data_models_pkey PRIMARY KEY (id);


--
-- Name: consent_records uq_consent_subject_purpose; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.consent_records
    ADD CONSTRAINT uq_consent_subject_purpose UNIQUE (organization_id, subject_id, purpose);


--
-- Name: compliance_controls uq_framework_control; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.compliance_controls
    ADD CONSTRAINT uq_framework_control UNIQUE (framework_id, control_id);


--
-- Name: compliance_frameworks uq_org_framework; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.compliance_frameworks
    ADD CONSTRAINT uq_org_framework UNIQUE (organization_id, short_name);


--
-- Name: ot_policy_rules uq_org_policy_name; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ot_policy_rules
    ADD CONSTRAINT uq_org_policy_name UNIQUE (organization_id, name);


--
-- Name: ot_assets uq_org_serial; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ot_assets
    ADD CONSTRAINT uq_org_serial UNIQUE (organization_id, serial_number);


--
-- Name: ot_zones uq_org_zone_name; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ot_zones
    ADD CONSTRAINT uq_org_zone_name UNIQUE (organization_id, name);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vendor_assessments vendor_assessments_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.vendor_assessments
    ADD CONSTRAINT vendor_assessments_pkey PRIMARY KEY (id);


--
-- Name: visual_playbook_executions visual_playbook_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.visual_playbook_executions
    ADD CONSTRAINT visual_playbook_executions_pkey PRIMARY KEY (id);


--
-- Name: visual_playbooks visual_playbooks_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.visual_playbooks
    ADD CONSTRAINT visual_playbooks_pkey PRIMARY KEY (id);


--
-- Name: vulnerabilities vulnerabilities_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.vulnerabilities
    ADD CONSTRAINT vulnerabilities_pkey PRIMARY KEY (id);


--
-- Name: vulnerability_exceptions vulnerability_exceptions_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.vulnerability_exceptions
    ADD CONSTRAINT vulnerability_exceptions_pkey PRIMARY KEY (id);


--
-- Name: vulnerability_instances vulnerability_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.vulnerability_instances
    ADD CONSTRAINT vulnerability_instances_pkey PRIMARY KEY (id);


--
-- Name: war_room_messages war_room_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.war_room_messages
    ADD CONSTRAINT war_room_messages_pkey PRIMARY KEY (id);


--
-- Name: war_rooms war_rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.war_rooms
    ADD CONSTRAINT war_rooms_pkey PRIMARY KEY (id);


--
-- Name: webhook_endpoints webhook_endpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.webhook_endpoints
    ADD CONSTRAINT webhook_endpoints_pkey PRIMARY KEY (id);


--
-- Name: zero_trust_policies zero_trust_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.zero_trust_policies
    ADD CONSTRAINT zero_trust_policies_pkey PRIMARY KEY (id);


--
-- Name: idx_component_cpe; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_component_cpe ON public.software_components USING btree (cpe);


--
-- Name: idx_component_name_version; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_component_name_version ON public.software_components USING btree (name, version);


--
-- Name: idx_component_org; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_component_org ON public.software_components USING btree (organization_id);


--
-- Name: idx_component_purl; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_component_purl ON public.software_components USING btree (purl);


--
-- Name: idx_consent_given; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_consent_given ON public.consent_records USING btree (consent_given);


--
-- Name: idx_consent_org_subject; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_consent_org_subject ON public.consent_records USING btree (organization_id, subject_id);


--
-- Name: idx_dpr_org_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_dpr_org_name ON public.data_processing_records USING btree (organization_id, name);


--
-- Name: idx_dpr_reviewed; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_dpr_reviewed ON public.data_processing_records USING btree (last_reviewed);


--
-- Name: idx_dsr_deadline; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_dsr_deadline ON public.data_subject_requests USING btree (deadline);


--
-- Name: idx_dsr_org_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_dsr_org_status ON public.data_subject_requests USING btree (organization_id, status);


--
-- Name: idx_dsr_org_subject; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_dsr_org_subject ON public.data_subject_requests USING btree (organization_id, subject_email);


--
-- Name: idx_incident_deadline; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_incident_deadline ON public.privacy_incidents USING btree (notification_deadline);


--
-- Name: idx_incident_org_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_incident_org_status ON public.privacy_incidents USING btree (organization_id, status);


--
-- Name: idx_incident_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_incident_severity ON public.privacy_incidents USING btree (severity);


--
-- Name: idx_pia_org_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_pia_org_status ON public.privacy_impact_assessments USING btree (organization_id, status);


--
-- Name: idx_pia_project; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_pia_project ON public.privacy_impact_assessments USING btree (project_name);


--
-- Name: idx_risk_component_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_risk_component_type ON public.supply_chain_risks USING btree (component_id, risk_type);


--
-- Name: idx_risk_org_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_risk_org_status ON public.supply_chain_risks USING btree (organization_id, status);


--
-- Name: idx_risk_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_risk_severity ON public.supply_chain_risks USING btree (severity);


--
-- Name: idx_sbom_component_org; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_sbom_component_org ON public.sbom_components USING btree (organization_id);


--
-- Name: idx_sbom_component_unique; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE UNIQUE INDEX idx_sbom_component_unique ON public.sbom_components USING btree (sbom_id, component_id);


--
-- Name: idx_sbom_org_app; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_sbom_org_app ON public.sboms USING btree (organization_id, application_name);


--
-- Name: idx_sbom_risk; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_sbom_risk ON public.sboms USING btree (vulnerability_risk_score, license_risk_score);


--
-- Name: idx_vendor_name_org; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_vendor_name_org ON public.vendor_assessments USING btree (vendor_name, organization_id);


--
-- Name: idx_vendor_org; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_vendor_org ON public.vendor_assessments USING btree (organization_id);


--
-- Name: idx_vendor_risk_tier; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX idx_vendor_risk_tier ON public.vendor_assessments USING btree (risk_tier);


--
-- Name: ix_access_anomalies_anomaly_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_access_anomalies_anomaly_type ON public.access_anomalies USING btree (anomaly_type);


--
-- Name: ix_access_anomalies_identity_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_access_anomalies_identity_id ON public.access_anomalies USING btree (identity_id);


--
-- Name: ix_access_anomalies_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_access_anomalies_organization_id ON public.access_anomalies USING btree (organization_id);


--
-- Name: ix_access_decisions_decision; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_access_decisions_decision ON public.access_decisions USING btree (decision);


--
-- Name: ix_access_decisions_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_access_decisions_organization_id ON public.access_decisions USING btree (organization_id);


--
-- Name: ix_access_decisions_policy_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_access_decisions_policy_id ON public.access_decisions USING btree (policy_id);


--
-- Name: ix_access_decisions_resource_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_access_decisions_resource_id ON public.access_decisions USING btree (resource_id);


--
-- Name: ix_access_decisions_subject_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_access_decisions_subject_id ON public.access_decisions USING btree (subject_id);


--
-- Name: ix_action_items_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_action_items_organization_id ON public.action_items USING btree (organization_id);


--
-- Name: ix_action_items_room_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_action_items_room_id ON public.action_items USING btree (room_id);


--
-- Name: ix_action_items_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_action_items_status ON public.action_items USING btree (status);


--
-- Name: ix_agent_actions_execution_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_agent_actions_execution_status ON public.agent_actions USING btree (execution_status);


--
-- Name: ix_agent_actions_investigation_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_agent_actions_investigation_id ON public.agent_actions USING btree (investigation_id);


--
-- Name: ix_agent_actions_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_agent_actions_organization_id ON public.agent_actions USING btree (organization_id);


--
-- Name: ix_agent_memories_agent_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_agent_memories_agent_id ON public.agent_memories USING btree (agent_id);


--
-- Name: ix_agent_memories_key; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_agent_memories_key ON public.agent_memories USING btree (key);


--
-- Name: ix_agent_memories_memory_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_agent_memories_memory_type ON public.agent_memories USING btree (memory_type);


--
-- Name: ix_agent_memories_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_agent_memories_organization_id ON public.agent_memories USING btree (organization_id);


--
-- Name: ix_alert_cluster_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_alert_cluster_status ON public.runtime_alerts USING btree (cluster_id, status);


--
-- Name: ix_alert_org_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_alert_org_type ON public.runtime_alerts USING btree (organization_id, alert_type);


--
-- Name: ix_alert_pod; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_alert_pod ON public.runtime_alerts USING btree (namespace, pod_name);


--
-- Name: ix_alerts_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_alerts_severity ON public.alerts USING btree (severity);


--
-- Name: ix_alerts_source; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_alerts_source ON public.alerts USING btree (source);


--
-- Name: ix_alerts_source_ip; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_alerts_source_ip ON public.alerts USING btree (source_ip);


--
-- Name: ix_alerts_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_alerts_status ON public.alerts USING btree (status);


--
-- Name: ix_alerts_title; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_alerts_title ON public.alerts USING btree (title);


--
-- Name: ix_anomaly_endpoint_type_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_anomaly_endpoint_type_severity ON public.api_anomaly_detection USING btree (endpoint_id, anomaly_type, severity);


--
-- Name: ix_anomaly_org_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_anomaly_org_status ON public.api_anomaly_detection USING btree (organization_id, status);


--
-- Name: ix_api_anomaly_detection_anomaly_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_anomaly_detection_anomaly_type ON public.api_anomaly_detection USING btree (anomaly_type);


--
-- Name: ix_api_anomaly_detection_endpoint_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_anomaly_detection_endpoint_id ON public.api_anomaly_detection USING btree (endpoint_id);


--
-- Name: ix_api_anomaly_detection_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_anomaly_detection_organization_id ON public.api_anomaly_detection USING btree (organization_id);


--
-- Name: ix_api_anomaly_detection_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_anomaly_detection_severity ON public.api_anomaly_detection USING btree (severity);


--
-- Name: ix_api_anomaly_detection_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_anomaly_detection_status ON public.api_anomaly_detection USING btree (status);


--
-- Name: ix_api_compliance_checks_check_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_compliance_checks_check_type ON public.api_compliance_checks USING btree (check_type);


--
-- Name: ix_api_compliance_checks_endpoint_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_compliance_checks_endpoint_id ON public.api_compliance_checks USING btree (endpoint_id);


--
-- Name: ix_api_compliance_checks_last_checked; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_compliance_checks_last_checked ON public.api_compliance_checks USING btree (last_checked);


--
-- Name: ix_api_compliance_checks_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_compliance_checks_organization_id ON public.api_compliance_checks USING btree (organization_id);


--
-- Name: ix_api_compliance_checks_passed; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_compliance_checks_passed ON public.api_compliance_checks USING btree (passed);


--
-- Name: ix_api_endpoint_inventory_is_deprecated; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_endpoint_inventory_is_deprecated ON public.api_endpoint_inventory USING btree (is_deprecated);


--
-- Name: ix_api_endpoint_inventory_is_documented; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_endpoint_inventory_is_documented ON public.api_endpoint_inventory USING btree (is_documented);


--
-- Name: ix_api_endpoint_inventory_is_public; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_endpoint_inventory_is_public ON public.api_endpoint_inventory USING btree (is_public);


--
-- Name: ix_api_endpoint_inventory_is_shadow; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_endpoint_inventory_is_shadow ON public.api_endpoint_inventory USING btree (is_shadow);


--
-- Name: ix_api_endpoint_inventory_last_seen; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_endpoint_inventory_last_seen ON public.api_endpoint_inventory USING btree (last_seen);


--
-- Name: ix_api_endpoint_inventory_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_endpoint_inventory_organization_id ON public.api_endpoint_inventory USING btree (organization_id);


--
-- Name: ix_api_endpoint_inventory_service_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_endpoint_inventory_service_name ON public.api_endpoint_inventory USING btree (service_name);


--
-- Name: ix_api_keys_key_prefix; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_keys_key_prefix ON public.api_keys USING btree (key_prefix);


--
-- Name: ix_api_keys_owner_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_keys_owner_id ON public.api_keys USING btree (owner_id);


--
-- Name: ix_api_security_policies_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE UNIQUE INDEX ix_api_security_policies_name ON public.api_security_policies USING btree (name);


--
-- Name: ix_api_security_policies_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_security_policies_organization_id ON public.api_security_policies USING btree (organization_id);


--
-- Name: ix_api_security_policies_policy_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_security_policies_policy_type ON public.api_security_policies USING btree (policy_type);


--
-- Name: ix_api_security_policies_violations_count; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_security_policies_violations_count ON public.api_security_policies USING btree (violations_count);


--
-- Name: ix_api_vulnerabilities_endpoint_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_vulnerabilities_endpoint_id ON public.api_vulnerabilities USING btree (endpoint_id);


--
-- Name: ix_api_vulnerabilities_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_vulnerabilities_organization_id ON public.api_vulnerabilities USING btree (organization_id);


--
-- Name: ix_api_vulnerabilities_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_vulnerabilities_severity ON public.api_vulnerabilities USING btree (severity);


--
-- Name: ix_api_vulnerabilities_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_vulnerabilities_status ON public.api_vulnerabilities USING btree (status);


--
-- Name: ix_api_vulnerabilities_vulnerability_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_api_vulnerabilities_vulnerability_type ON public.api_vulnerabilities USING btree (vulnerability_type);


--
-- Name: ix_asset_vuln_composite; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_asset_vuln_composite ON public.asset_vulnerabilities USING btree (asset_id, vulnerability_id);


--
-- Name: ix_asset_vulnerabilities_asset_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_asset_vulnerabilities_asset_id ON public.asset_vulnerabilities USING btree (asset_id);


--
-- Name: ix_asset_vulnerabilities_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_asset_vulnerabilities_organization_id ON public.asset_vulnerabilities USING btree (organization_id);


--
-- Name: ix_asset_vulnerabilities_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_asset_vulnerabilities_status ON public.asset_vulnerabilities USING btree (status);


--
-- Name: ix_asset_vulnerabilities_vulnerability_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_asset_vulnerabilities_vulnerability_id ON public.asset_vulnerabilities USING btree (vulnerability_id);


--
-- Name: ix_assets_hostname; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_assets_hostname ON public.assets USING btree (hostname);


--
-- Name: ix_assets_ip_address; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_assets_ip_address ON public.assets USING btree (ip_address);


--
-- Name: ix_assets_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_assets_name ON public.assets USING btree (name);


--
-- Name: ix_attack_surfaces_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_attack_surfaces_organization_id ON public.attack_surfaces USING btree (organization_id);


--
-- Name: ix_attack_surfaces_surface_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_attack_surfaces_surface_type ON public.attack_surfaces USING btree (surface_type);


--
-- Name: ix_attack_techniques_mitre_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE UNIQUE INDEX ix_attack_techniques_mitre_id ON public.attack_techniques USING btree (mitre_id);


--
-- Name: ix_attack_trees_model_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_attack_trees_model_id ON public.attack_trees USING btree (model_id);


--
-- Name: ix_attack_trees_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_attack_trees_organization_id ON public.attack_trees USING btree (organization_id);


--
-- Name: ix_audit_logs_action; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: ix_audit_logs_resource_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_audit_logs_resource_id ON public.audit_logs USING btree (resource_id);


--
-- Name: ix_audit_logs_resource_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_audit_logs_resource_type ON public.audit_logs USING btree (resource_type);


--
-- Name: ix_audit_trails_action; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_audit_trails_action ON public.audit_trails USING btree (action);


--
-- Name: ix_audit_trails_actor_created; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_audit_trails_actor_created ON public.audit_trails USING btree (actor_id, created_at);


--
-- Name: ix_audit_trails_actor_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_audit_trails_actor_id ON public.audit_trails USING btree (actor_id);


--
-- Name: ix_audit_trails_event_created; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_audit_trails_event_created ON public.audit_trails USING btree (event_type, created_at);


--
-- Name: ix_audit_trails_event_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_audit_trails_event_type ON public.audit_trails USING btree (event_type);


--
-- Name: ix_audit_trails_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_audit_trails_organization_id ON public.audit_trails USING btree (organization_id);


--
-- Name: ix_audit_trails_resource_created; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_audit_trails_resource_created ON public.audit_trails USING btree (resource_type, resource_id);


--
-- Name: ix_audit_trails_resource_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_audit_trails_resource_id ON public.audit_trails USING btree (resource_id);


--
-- Name: ix_audit_trails_result; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_audit_trails_result ON public.audit_trails USING btree (result);


--
-- Name: ix_audit_trails_risk_level; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_audit_trails_risk_level ON public.audit_trails USING btree (risk_level);


--
-- Name: ix_automated_evidence_rules_collection_method; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_automated_evidence_rules_collection_method ON public.automated_evidence_rules USING btree (collection_method);


--
-- Name: ix_automated_evidence_rules_enabled; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_automated_evidence_rules_enabled ON public.automated_evidence_rules USING btree (is_enabled, schedule);


--
-- Name: ix_automated_evidence_rules_is_enabled; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_automated_evidence_rules_is_enabled ON public.automated_evidence_rules USING btree (is_enabled);


--
-- Name: ix_automated_evidence_rules_last_collected; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_automated_evidence_rules_last_collected ON public.automated_evidence_rules USING btree (last_collected_at, schedule);


--
-- Name: ix_automated_evidence_rules_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_automated_evidence_rules_name ON public.automated_evidence_rules USING btree (name);


--
-- Name: ix_automated_evidence_rules_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_automated_evidence_rules_organization_id ON public.automated_evidence_rules USING btree (organization_id);


--
-- Name: ix_automated_evidence_rules_schedule; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_automated_evidence_rules_schedule ON public.automated_evidence_rules USING btree (schedule);


--
-- Name: ix_automation_rules_trigger_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_automation_rules_trigger_type ON public.automation_rules USING btree (trigger_type);


--
-- Name: ix_business_impact_assessments_asset_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_business_impact_assessments_asset_name ON public.business_impact_assessments USING btree (asset_name);


--
-- Name: ix_business_impact_assessments_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_business_impact_assessments_organization_id ON public.business_impact_assessments USING btree (organization_id);


--
-- Name: ix_case_attachments_incident_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_case_attachments_incident_id ON public.case_attachments USING btree (incident_id);


--
-- Name: ix_case_notes_incident_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_case_notes_incident_id ON public.case_notes USING btree (incident_id);


--
-- Name: ix_case_tasks_incident_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_case_tasks_incident_id ON public.case_tasks USING btree (incident_id);


--
-- Name: ix_case_timeline_event_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_case_timeline_event_type ON public.case_timeline USING btree (event_type);


--
-- Name: ix_case_timeline_incident_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_case_timeline_incident_id ON public.case_timeline USING btree (incident_id);


--
-- Name: ix_cisa_directives_compliance_deadline; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_cisa_directives_compliance_deadline ON public.cisa_directives USING btree (compliance_deadline);


--
-- Name: ix_cisa_directives_directive_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE UNIQUE INDEX ix_cisa_directives_directive_id ON public.cisa_directives USING btree (directive_id);


--
-- Name: ix_cisa_directives_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_cisa_directives_organization_id ON public.cisa_directives USING btree (organization_id);


--
-- Name: ix_cluster_org_provider; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_cluster_org_provider ON public.kubernetes_clusters USING btree (organization_id, provider);


--
-- Name: ix_cluster_org_risk; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_cluster_org_risk ON public.kubernetes_clusters USING btree (organization_id, risk_score);


--
-- Name: ix_compliance_assessments_assessment_date; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_compliance_assessments_assessment_date ON public.compliance_assessments USING btree (assessment_date);


--
-- Name: ix_compliance_assessments_assessor; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_compliance_assessments_assessor ON public.compliance_assessments USING btree (assessor);


--
-- Name: ix_compliance_assessments_framework_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_compliance_assessments_framework_id ON public.compliance_assessments USING btree (framework_id);


--
-- Name: ix_compliance_assessments_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_compliance_assessments_organization_id ON public.compliance_assessments USING btree (organization_id);


--
-- Name: ix_compliance_controls_framework_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_compliance_controls_framework_id ON public.compliance_controls USING btree (framework_id);


--
-- Name: ix_compliance_controls_last_assessed_at; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_compliance_controls_last_assessed_at ON public.compliance_controls USING btree (last_assessed_at);


--
-- Name: ix_compliance_controls_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_compliance_controls_organization_id ON public.compliance_controls USING btree (organization_id);


--
-- Name: ix_compliance_controls_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_compliance_controls_status ON public.compliance_controls USING btree (status);


--
-- Name: ix_compliance_endpoint_type_passed; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_compliance_endpoint_type_passed ON public.api_compliance_checks USING btree (endpoint_id, check_type, passed);


--
-- Name: ix_compliance_evidence_control_id_ref; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_compliance_evidence_control_id_ref ON public.compliance_evidence USING btree (control_id_ref);


--
-- Name: ix_compliance_evidence_expires_at; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_compliance_evidence_expires_at ON public.compliance_evidence USING btree (expires_at);


--
-- Name: ix_compliance_evidence_is_valid; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_compliance_evidence_is_valid ON public.compliance_evidence USING btree (is_valid);


--
-- Name: ix_compliance_evidence_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_compliance_evidence_organization_id ON public.compliance_evidence USING btree (organization_id);


--
-- Name: ix_compliance_evidence_title; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_compliance_evidence_title ON public.compliance_evidence USING btree (title);


--
-- Name: ix_compliance_frameworks_compliance_score; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_compliance_frameworks_compliance_score ON public.compliance_frameworks USING btree (compliance_score);


--
-- Name: ix_compliance_frameworks_is_enabled; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_compliance_frameworks_is_enabled ON public.compliance_frameworks USING btree (is_enabled);


--
-- Name: ix_compliance_frameworks_next_assessment_due; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_compliance_frameworks_next_assessment_due ON public.compliance_frameworks USING btree (next_assessment_due);


--
-- Name: ix_compliance_frameworks_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_compliance_frameworks_organization_id ON public.compliance_frameworks USING btree (organization_id);


--
-- Name: ix_compliance_frameworks_short_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_compliance_frameworks_short_name ON public.compliance_frameworks USING btree (short_name);


--
-- Name: ix_compliance_org_type_passed; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_compliance_org_type_passed ON public.api_compliance_checks USING btree (organization_id, check_type, passed);


--
-- Name: ix_consent_records_consent_given; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_consent_records_consent_given ON public.consent_records USING btree (consent_given);


--
-- Name: ix_consent_records_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_consent_records_organization_id ON public.consent_records USING btree (organization_id);


--
-- Name: ix_consent_records_subject_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_consent_records_subject_id ON public.consent_records USING btree (subject_id);


--
-- Name: ix_container_images_compliance_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_container_images_compliance_status ON public.container_images USING btree (compliance_status);


--
-- Name: ix_container_images_is_signed; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_container_images_is_signed ON public.container_images USING btree (is_signed);


--
-- Name: ix_container_images_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_container_images_organization_id ON public.container_images USING btree (organization_id);


--
-- Name: ix_container_images_registry; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_container_images_registry ON public.container_images USING btree (registry);


--
-- Name: ix_container_images_repository; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_container_images_repository ON public.container_images USING btree (repository);


--
-- Name: ix_container_images_risk_score; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_container_images_risk_score ON public.container_images USING btree (risk_score);


--
-- Name: ix_control_framework_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_control_framework_id ON public.compliance_controls USING btree (framework_id, control_id);


--
-- Name: ix_correlation_events_correlation_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE UNIQUE INDEX ix_correlation_events_correlation_id ON public.correlation_events USING btree (correlation_id);


--
-- Name: ix_correlation_events_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_correlation_events_severity ON public.correlation_events USING btree (severity);


--
-- Name: ix_correlation_events_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_correlation_events_status ON public.correlation_events USING btree (status);


--
-- Name: ix_correlation_events_timespan_start; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_correlation_events_timespan_start ON public.correlation_events USING btree (timespan_start);


--
-- Name: ix_credential_exposures_exposure_source; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_credential_exposures_exposure_source ON public.credential_exposures USING btree (exposure_source);


--
-- Name: ix_credential_exposures_identity_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_credential_exposures_identity_id ON public.credential_exposures USING btree (identity_id);


--
-- Name: ix_credential_exposures_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_credential_exposures_organization_id ON public.credential_exposures USING btree (organization_id);


--
-- Name: ix_cui_asset_org; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_cui_asset_org ON public.cui_markings USING btree (asset_id, organization_id);


--
-- Name: ix_cui_markings_asset_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_cui_markings_asset_id ON public.cui_markings USING btree (asset_id);


--
-- Name: ix_cui_markings_is_active; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_cui_markings_is_active ON public.cui_markings USING btree (is_active);


--
-- Name: ix_cui_markings_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_cui_markings_organization_id ON public.cui_markings USING btree (organization_id);


--
-- Name: ix_darkweb_brand_threats_finding_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_brand_threats_finding_id ON public.darkweb_brand_threats USING btree (finding_id);


--
-- Name: ix_darkweb_brand_threats_malicious_domain; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_brand_threats_malicious_domain ON public.darkweb_brand_threats USING btree (malicious_domain);


--
-- Name: ix_darkweb_brand_threats_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_brand_threats_organization_id ON public.darkweb_brand_threats USING btree (organization_id);


--
-- Name: ix_darkweb_brand_threats_organization_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_brand_threats_organization_status ON public.darkweb_brand_threats USING btree (organization_id, takedown_status);


--
-- Name: ix_darkweb_brand_threats_takedown_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_brand_threats_takedown_status ON public.darkweb_brand_threats USING btree (takedown_status);


--
-- Name: ix_darkweb_brand_threats_target_domain; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_brand_threats_target_domain ON public.darkweb_brand_threats USING btree (target_domain);


--
-- Name: ix_darkweb_brand_threats_threat_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_brand_threats_threat_type ON public.darkweb_brand_threats USING btree (threat_type);


--
-- Name: ix_darkweb_credential_leaks_email; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_credential_leaks_email ON public.darkweb_credential_leaks USING btree (email);


--
-- Name: ix_darkweb_credential_leaks_finding_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_credential_leaks_finding_id ON public.darkweb_credential_leaks USING btree (finding_id);


--
-- Name: ix_darkweb_credential_leaks_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_credential_leaks_organization_id ON public.darkweb_credential_leaks USING btree (organization_id);


--
-- Name: ix_darkweb_credential_leaks_organization_remediated; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_credential_leaks_organization_remediated ON public.darkweb_credential_leaks USING btree (organization_id, is_remediated);


--
-- Name: ix_darkweb_findings_finding_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_findings_finding_type ON public.darkweb_findings USING btree (finding_type);


--
-- Name: ix_darkweb_findings_monitor_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_findings_monitor_id ON public.darkweb_findings USING btree (monitor_id);


--
-- Name: ix_darkweb_findings_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_findings_organization_id ON public.darkweb_findings USING btree (organization_id);


--
-- Name: ix_darkweb_findings_organization_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_findings_organization_severity ON public.darkweb_findings USING btree (organization_id, severity);


--
-- Name: ix_darkweb_findings_organization_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_findings_organization_status ON public.darkweb_findings USING btree (organization_id, status);


--
-- Name: ix_darkweb_findings_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_findings_severity ON public.darkweb_findings USING btree (severity);


--
-- Name: ix_darkweb_findings_source_platform; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_findings_source_platform ON public.darkweb_findings USING btree (source_platform);


--
-- Name: ix_darkweb_findings_source_url_hash; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_findings_source_url_hash ON public.darkweb_findings USING btree (source_url_hash);


--
-- Name: ix_darkweb_findings_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_findings_status ON public.darkweb_findings USING btree (status);


--
-- Name: ix_darkweb_monitors_enabled; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_monitors_enabled ON public.darkweb_monitors USING btree (enabled);


--
-- Name: ix_darkweb_monitors_monitor_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_monitors_monitor_type ON public.darkweb_monitors USING btree (monitor_type);


--
-- Name: ix_darkweb_monitors_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_monitors_name ON public.darkweb_monitors USING btree (name);


--
-- Name: ix_darkweb_monitors_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_darkweb_monitors_organization_id ON public.darkweb_monitors USING btree (organization_id);


--
-- Name: ix_data_classifications_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_data_classifications_organization_id ON public.data_classifications USING btree (organization_id);


--
-- Name: ix_data_partitions_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_data_partitions_organization_id ON public.data_partitions USING btree (organization_id);


--
-- Name: ix_data_partitions_source_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_data_partitions_source_id ON public.data_partitions USING btree (source_id);


--
-- Name: ix_data_pipelines_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_data_pipelines_name ON public.data_pipelines USING btree (name);


--
-- Name: ix_data_pipelines_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_data_pipelines_organization_id ON public.data_pipelines USING btree (organization_id);


--
-- Name: ix_data_pipelines_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_data_pipelines_status ON public.data_pipelines USING btree (status);


--
-- Name: ix_data_processing_records_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_data_processing_records_name ON public.data_processing_records USING btree (name);


--
-- Name: ix_data_processing_records_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_data_processing_records_organization_id ON public.data_processing_records USING btree (organization_id);


--
-- Name: ix_data_sources_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_data_sources_name ON public.data_sources USING btree (name);


--
-- Name: ix_data_sources_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_data_sources_organization_id ON public.data_sources USING btree (organization_id);


--
-- Name: ix_data_sources_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_data_sources_status ON public.data_sources USING btree (status);


--
-- Name: ix_data_subject_requests_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_data_subject_requests_organization_id ON public.data_subject_requests USING btree (organization_id);


--
-- Name: ix_data_subject_requests_regulation; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_data_subject_requests_regulation ON public.data_subject_requests USING btree (regulation);


--
-- Name: ix_data_subject_requests_request_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_data_subject_requests_request_type ON public.data_subject_requests USING btree (request_type);


--
-- Name: ix_data_subject_requests_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_data_subject_requests_status ON public.data_subject_requests USING btree (status);


--
-- Name: ix_detection_rules_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE UNIQUE INDEX ix_detection_rules_name ON public.detection_rules USING btree (name);


--
-- Name: ix_detection_rules_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_detection_rules_severity ON public.detection_rules USING btree (severity);


--
-- Name: ix_detection_rules_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_detection_rules_status ON public.detection_rules USING btree (status);


--
-- Name: ix_device_trust_profiles_device_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE UNIQUE INDEX ix_device_trust_profiles_device_id ON public.device_trust_profiles USING btree (device_id);


--
-- Name: ix_device_trust_profiles_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_device_trust_profiles_organization_id ON public.device_trust_profiles USING btree (organization_id);


--
-- Name: ix_dlp_incidents_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_dlp_incidents_organization_id ON public.dlp_incidents USING btree (organization_id);


--
-- Name: ix_dlp_incidents_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_dlp_incidents_status ON public.dlp_incidents USING btree (status);


--
-- Name: ix_dlp_policies_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_dlp_policies_name ON public.dlp_policies USING btree (name);


--
-- Name: ix_dlp_policies_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_dlp_policies_organization_id ON public.dlp_policies USING btree (organization_id);


--
-- Name: ix_dlp_violations_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_dlp_violations_organization_id ON public.dlp_violations USING btree (organization_id);


--
-- Name: ix_dlp_violations_policy_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_dlp_violations_policy_id ON public.dlp_violations USING btree (policy_id);


--
-- Name: ix_dlp_violations_source_user; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_dlp_violations_source_user ON public.dlp_violations USING btree (source_user);


--
-- Name: ix_dlp_violations_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_dlp_violations_status ON public.dlp_violations USING btree (status);


--
-- Name: ix_endpoint_org_auth_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_endpoint_org_auth_type ON public.api_endpoint_inventory USING btree (organization_id, authentication_type);


--
-- Name: ix_endpoint_org_shadow_documented; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_endpoint_org_shadow_documented ON public.api_endpoint_inventory USING btree (organization_id, is_shadow, is_documented);


--
-- Name: ix_endpoint_service_method_path; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_endpoint_service_method_path ON public.api_endpoint_inventory USING btree (service_name, method, path);


--
-- Name: ix_evidence_packages_due_date; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_evidence_packages_due_date ON public.evidence_packages USING btree (due_date, status);


--
-- Name: ix_evidence_packages_framework; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_evidence_packages_framework ON public.evidence_packages USING btree (framework_id, organization_id);


--
-- Name: ix_evidence_packages_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_evidence_packages_name ON public.evidence_packages USING btree (name);


--
-- Name: ix_evidence_packages_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_evidence_packages_organization_id ON public.evidence_packages USING btree (organization_id);


--
-- Name: ix_evidence_packages_package_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_evidence_packages_package_type ON public.evidence_packages USING btree (package_type);


--
-- Name: ix_evidence_packages_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_evidence_packages_status ON public.evidence_packages USING btree (status);


--
-- Name: ix_evidence_packages_status_created; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_evidence_packages_status_created ON public.evidence_packages USING btree (status, created_at);


--
-- Name: ix_exposure_assets_asset_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_exposure_assets_asset_type ON public.exposure_assets USING btree (asset_type);


--
-- Name: ix_exposure_assets_hostname; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_exposure_assets_hostname ON public.exposure_assets USING btree (hostname);


--
-- Name: ix_exposure_assets_ip_address; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_exposure_assets_ip_address ON public.exposure_assets USING btree (ip_address);


--
-- Name: ix_exposure_assets_is_active; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_exposure_assets_is_active ON public.exposure_assets USING btree (is_active);


--
-- Name: ix_exposure_assets_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_exposure_assets_organization_id ON public.exposure_assets USING btree (organization_id);


--
-- Name: ix_exposure_assets_risk_score; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_exposure_assets_risk_score ON public.exposure_assets USING btree (risk_score);


--
-- Name: ix_exposure_scans_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_exposure_scans_organization_id ON public.exposure_scans USING btree (organization_id);


--
-- Name: ix_exposure_scans_scan_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_exposure_scans_scan_type ON public.exposure_scans USING btree (scan_type);


--
-- Name: ix_exposure_scans_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_exposure_scans_status ON public.exposure_scans USING btree (status);


--
-- Name: ix_exposure_vulnerabilities_cve_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_exposure_vulnerabilities_cve_id ON public.exposure_vulnerabilities USING btree (cve_id);


--
-- Name: ix_fair_analyses_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_fair_analyses_organization_id ON public.fair_analyses USING btree (organization_id);


--
-- Name: ix_fair_analyses_scenario_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_fair_analyses_scenario_id ON public.fair_analyses USING btree (scenario_id);


--
-- Name: ix_finding_cluster_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_finding_cluster_status ON public.k8s_security_findings USING btree (cluster_id, status);


--
-- Name: ix_finding_org_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_finding_org_type ON public.k8s_security_findings USING btree (organization_id, finding_type);


--
-- Name: ix_forensic_artifacts_artifact_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_forensic_artifacts_artifact_type ON public.forensic_artifacts USING btree (artifact_type);


--
-- Name: ix_forensic_artifacts_case_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_forensic_artifacts_case_id ON public.forensic_artifacts USING btree (case_id);


--
-- Name: ix_forensic_artifacts_evidence_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_forensic_artifacts_evidence_id ON public.forensic_artifacts USING btree (evidence_id);


--
-- Name: ix_forensic_artifacts_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_forensic_artifacts_organization_id ON public.forensic_artifacts USING btree (organization_id);


--
-- Name: ix_forensic_cases_case_number; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE UNIQUE INDEX ix_forensic_cases_case_number ON public.forensic_cases USING btree (case_number);


--
-- Name: ix_forensic_cases_case_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_forensic_cases_case_type ON public.forensic_cases USING btree (case_type);


--
-- Name: ix_forensic_cases_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_forensic_cases_organization_id ON public.forensic_cases USING btree (organization_id);


--
-- Name: ix_forensic_cases_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_forensic_cases_status ON public.forensic_cases USING btree (status);


--
-- Name: ix_forensic_cases_title; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_forensic_cases_title ON public.forensic_cases USING btree (title);


--
-- Name: ix_forensic_evidence_case_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_forensic_evidence_case_id ON public.forensic_evidence USING btree (case_id);


--
-- Name: ix_forensic_evidence_evidence_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_forensic_evidence_evidence_type ON public.forensic_evidence USING btree (evidence_type);


--
-- Name: ix_forensic_evidence_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_forensic_evidence_organization_id ON public.forensic_evidence USING btree (organization_id);


--
-- Name: ix_forensic_timeline_case_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_forensic_timeline_case_id ON public.forensic_timeline USING btree (case_id);


--
-- Name: ix_forensic_timeline_event_timestamp; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_forensic_timeline_event_timestamp ON public.forensic_timeline USING btree (event_timestamp);


--
-- Name: ix_forensic_timeline_event_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_forensic_timeline_event_type ON public.forensic_timeline USING btree (event_type);


--
-- Name: ix_forensic_timeline_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_forensic_timeline_organization_id ON public.forensic_timeline USING btree (organization_id);


--
-- Name: ix_hunt_findings_classification; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_hunt_findings_classification ON public.hunt_findings USING btree (classification);


--
-- Name: ix_hunt_findings_escalated_to_case; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_hunt_findings_escalated_to_case ON public.hunt_findings USING btree (escalated_to_case);


--
-- Name: ix_hunt_findings_session_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_hunt_findings_session_id ON public.hunt_findings USING btree (session_id);


--
-- Name: ix_hunt_findings_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_hunt_findings_severity ON public.hunt_findings USING btree (severity);


--
-- Name: ix_hunt_findings_title; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_hunt_findings_title ON public.hunt_findings USING btree (title);


--
-- Name: ix_hunt_hypotheses_hunt_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_hunt_hypotheses_hunt_type ON public.hunt_hypotheses USING btree (hunt_type);


--
-- Name: ix_hunt_hypotheses_priority; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_hunt_hypotheses_priority ON public.hunt_hypotheses USING btree (priority);


--
-- Name: ix_hunt_hypotheses_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_hunt_hypotheses_status ON public.hunt_hypotheses USING btree (status);


--
-- Name: ix_hunt_hypotheses_title; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_hunt_hypotheses_title ON public.hunt_hypotheses USING btree (title);


--
-- Name: ix_hunt_notebooks_is_published; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_hunt_notebooks_is_published ON public.hunt_notebooks USING btree (is_published);


--
-- Name: ix_hunt_notebooks_session_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_hunt_notebooks_session_id ON public.hunt_notebooks USING btree (session_id);


--
-- Name: ix_hunt_notebooks_title; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_hunt_notebooks_title ON public.hunt_notebooks USING btree (title);


--
-- Name: ix_hunt_sessions_hypothesis_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_hunt_sessions_hypothesis_id ON public.hunt_sessions USING btree (hypothesis_id);


--
-- Name: ix_hunt_sessions_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_hunt_sessions_status ON public.hunt_sessions USING btree (status);


--
-- Name: ix_hunt_templates_category; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_hunt_templates_category ON public.hunt_templates USING btree (category);


--
-- Name: ix_hunt_templates_enabled; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_hunt_templates_enabled ON public.hunt_templates USING btree (enabled);


--
-- Name: ix_hunt_templates_is_builtin; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_hunt_templates_is_builtin ON public.hunt_templates USING btree (is_builtin);


--
-- Name: ix_hunt_templates_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE UNIQUE INDEX ix_hunt_templates_name ON public.hunt_templates USING btree (name);


--
-- Name: ix_identified_threats_component_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_identified_threats_component_id ON public.identified_threats USING btree (component_id);


--
-- Name: ix_identified_threats_model_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_identified_threats_model_id ON public.identified_threats USING btree (model_id);


--
-- Name: ix_identified_threats_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_identified_threats_organization_id ON public.identified_threats USING btree (organization_id);


--
-- Name: ix_identified_threats_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_identified_threats_status ON public.identified_threats USING btree (status);


--
-- Name: ix_identified_threats_stride_category; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_identified_threats_stride_category ON public.identified_threats USING btree (stride_category);


--
-- Name: ix_identity_profiles_email; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_identity_profiles_email ON public.identity_profiles USING btree (email);


--
-- Name: ix_identity_profiles_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_identity_profiles_organization_id ON public.identity_profiles USING btree (organization_id);


--
-- Name: ix_identity_profiles_privilege_level; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_identity_profiles_privilege_level ON public.identity_profiles USING btree (privilege_level);


--
-- Name: ix_identity_profiles_user_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_identity_profiles_user_id ON public.identity_profiles USING btree (user_id);


--
-- Name: ix_identity_profiles_username; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_identity_profiles_username ON public.identity_profiles USING btree (username);


--
-- Name: ix_identity_threats_identity_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_identity_threats_identity_id ON public.identity_threats USING btree (identity_id);


--
-- Name: ix_identity_threats_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_identity_threats_organization_id ON public.identity_threats USING btree (organization_id);


--
-- Name: ix_identity_threats_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_identity_threats_severity ON public.identity_threats USING btree (severity);


--
-- Name: ix_identity_threats_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_identity_threats_status ON public.identity_threats USING btree (status);


--
-- Name: ix_identity_threats_threat_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_identity_threats_threat_type ON public.identity_threats USING btree (threat_type);


--
-- Name: ix_identity_verifications_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_identity_verifications_organization_id ON public.identity_verifications USING btree (organization_id);


--
-- Name: ix_identity_verifications_result; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_identity_verifications_result ON public.identity_verifications USING btree (result);


--
-- Name: ix_identity_verifications_user_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_identity_verifications_user_id ON public.identity_verifications USING btree (user_id);


--
-- Name: ix_identity_verifications_verification_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_identity_verifications_verification_type ON public.identity_verifications USING btree (verification_type);


--
-- Name: ix_image_org_risk; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_image_org_risk ON public.container_images USING btree (organization_id, risk_score);


--
-- Name: ix_image_registry_repo_tag; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_image_registry_repo_tag ON public.container_images USING btree (registry, repository, tag);


--
-- Name: ix_image_vulnerabilities_cve_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_image_vulnerabilities_cve_id ON public.image_vulnerabilities USING btree (cve_id);


--
-- Name: ix_image_vulnerabilities_image_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_image_vulnerabilities_image_id ON public.image_vulnerabilities USING btree (image_id);


--
-- Name: ix_image_vulnerabilities_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_image_vulnerabilities_organization_id ON public.image_vulnerabilities USING btree (organization_id);


--
-- Name: ix_image_vulnerabilities_package_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_image_vulnerabilities_package_name ON public.image_vulnerabilities USING btree (package_name);


--
-- Name: ix_image_vulnerabilities_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_image_vulnerabilities_severity ON public.image_vulnerabilities USING btree (severity);


--
-- Name: ix_incident_timeline_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_incident_timeline_organization_id ON public.incident_timeline USING btree (organization_id);


--
-- Name: ix_incident_timeline_room_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_incident_timeline_room_id ON public.incident_timeline USING btree (room_id);


--
-- Name: ix_incidents_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_incidents_severity ON public.incidents USING btree (severity);


--
-- Name: ix_incidents_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_incidents_status ON public.incidents USING btree (status);


--
-- Name: ix_incidents_title; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_incidents_title ON public.incidents USING btree (title);


--
-- Name: ix_indicator_active; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_indicator_active ON public.threat_indicators USING btree (is_active);


--
-- Name: ix_indicator_expires; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_indicator_expires ON public.threat_indicators USING btree (expires_at);


--
-- Name: ix_indicator_type_value; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_indicator_type_value ON public.threat_indicators USING btree (indicator_type, value);


--
-- Name: ix_indicator_value; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_indicator_value ON public.threat_indicators USING btree (value);


--
-- Name: ix_installed_integrations_connector_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_installed_integrations_connector_id ON public.installed_integrations USING btree (connector_id);


--
-- Name: ix_installed_integrations_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_installed_integrations_organization_id ON public.installed_integrations USING btree (organization_id);


--
-- Name: ix_installed_integrations_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_installed_integrations_status ON public.installed_integrations USING btree (status);


--
-- Name: ix_integration_actions_connector_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_integration_actions_connector_id ON public.integration_actions USING btree (connector_id);


--
-- Name: ix_integration_connectors_category; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_integration_connectors_category ON public.integration_connectors USING btree (category);


--
-- Name: ix_integration_connectors_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE UNIQUE INDEX ix_integration_connectors_name ON public.integration_connectors USING btree (name);


--
-- Name: ix_integration_executions_action_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_integration_executions_action_id ON public.integration_executions USING btree (action_id);


--
-- Name: ix_integration_executions_installed_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_integration_executions_installed_id ON public.integration_executions USING btree (installed_id);


--
-- Name: ix_integration_executions_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_integration_executions_organization_id ON public.integration_executions USING btree (organization_id);


--
-- Name: ix_integration_executions_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_integration_executions_status ON public.integration_executions USING btree (status);


--
-- Name: ix_investigations_agent_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_investigations_agent_id ON public.investigations USING btree (agent_id);


--
-- Name: ix_investigations_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_investigations_organization_id ON public.investigations USING btree (organization_id);


--
-- Name: ix_investigations_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_investigations_status ON public.investigations USING btree (status);


--
-- Name: ix_investigations_title; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_investigations_title ON public.investigations USING btree (title);


--
-- Name: ix_iocs_ioc_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_iocs_ioc_type ON public.iocs USING btree (ioc_type);


--
-- Name: ix_iocs_value; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_iocs_value ON public.iocs USING btree (value);


--
-- Name: ix_k8s_security_findings_cluster_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_k8s_security_findings_cluster_id ON public.k8s_security_findings USING btree (cluster_id);


--
-- Name: ix_k8s_security_findings_finding_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_k8s_security_findings_finding_type ON public.k8s_security_findings USING btree (finding_type);


--
-- Name: ix_k8s_security_findings_namespace; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_k8s_security_findings_namespace ON public.k8s_security_findings USING btree (namespace);


--
-- Name: ix_k8s_security_findings_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_k8s_security_findings_organization_id ON public.k8s_security_findings USING btree (organization_id);


--
-- Name: ix_k8s_security_findings_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_k8s_security_findings_severity ON public.k8s_security_findings USING btree (severity);


--
-- Name: ix_k8s_security_findings_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_k8s_security_findings_status ON public.k8s_security_findings USING btree (status);


--
-- Name: ix_kubernetes_clusters_compliance_score; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_kubernetes_clusters_compliance_score ON public.kubernetes_clusters USING btree (compliance_score);


--
-- Name: ix_kubernetes_clusters_last_audit; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_kubernetes_clusters_last_audit ON public.kubernetes_clusters USING btree (last_audit);


--
-- Name: ix_kubernetes_clusters_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_kubernetes_clusters_organization_id ON public.kubernetes_clusters USING btree (organization_id);


--
-- Name: ix_kubernetes_clusters_pod_security_standards; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_kubernetes_clusters_pod_security_standards ON public.kubernetes_clusters USING btree (pod_security_standards);


--
-- Name: ix_kubernetes_clusters_provider; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_kubernetes_clusters_provider ON public.kubernetes_clusters USING btree (provider);


--
-- Name: ix_kubernetes_clusters_risk_score; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_kubernetes_clusters_risk_score ON public.kubernetes_clusters USING btree (risk_score);


--
-- Name: ix_legal_holds_case_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_legal_holds_case_id ON public.legal_holds USING btree (case_id);


--
-- Name: ix_legal_holds_hold_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_legal_holds_hold_type ON public.legal_holds USING btree (hold_type);


--
-- Name: ix_legal_holds_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_legal_holds_organization_id ON public.legal_holds USING btree (organization_id);


--
-- Name: ix_log_entries_destination_address; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_log_entries_destination_address ON public.log_entries USING btree (destination_address);


--
-- Name: ix_log_entries_hostname; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_log_entries_hostname ON public.log_entries USING btree (hostname);


--
-- Name: ix_log_entries_log_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_log_entries_log_type ON public.log_entries USING btree (log_type);


--
-- Name: ix_log_entries_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_log_entries_severity ON public.log_entries USING btree (severity);


--
-- Name: ix_log_entries_source_address; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_log_entries_source_address ON public.log_entries USING btree (source_address);


--
-- Name: ix_log_entries_source_ip; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_log_entries_source_ip ON public.log_entries USING btree (source_ip);


--
-- Name: ix_log_entries_source_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_log_entries_source_name ON public.log_entries USING btree (source_name);


--
-- Name: ix_log_entries_source_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_log_entries_source_type ON public.log_entries USING btree (source_type);


--
-- Name: ix_log_entries_timestamp; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_log_entries_timestamp ON public.log_entries USING btree ("timestamp");


--
-- Name: ix_log_entries_username; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_log_entries_username ON public.log_entries USING btree (username);


--
-- Name: ix_micro_segments_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_micro_segments_name ON public.micro_segments USING btree (name);


--
-- Name: ix_micro_segments_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_micro_segments_organization_id ON public.micro_segments USING btree (organization_id);


--
-- Name: ix_organization_members_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_organization_members_organization_id ON public.organization_members USING btree (organization_id);


--
-- Name: ix_organization_members_user_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_organization_members_user_id ON public.organization_members USING btree (user_id);


--
-- Name: ix_organizations_slug; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE UNIQUE INDEX ix_organizations_slug ON public.organizations USING btree (slug);


--
-- Name: ix_ot_alerts_alert_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_alerts_alert_type ON public.ot_alerts USING btree (alert_type);


--
-- Name: ix_ot_alerts_asset_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_alerts_asset_id ON public.ot_alerts USING btree (asset_id);


--
-- Name: ix_ot_alerts_mitre_ics_technique; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_alerts_mitre_ics_technique ON public.ot_alerts USING btree (mitre_ics_technique);


--
-- Name: ix_ot_alerts_org_asset; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_alerts_org_asset ON public.ot_alerts USING btree (organization_id, asset_id);


--
-- Name: ix_ot_alerts_org_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_alerts_org_severity ON public.ot_alerts USING btree (organization_id, severity);


--
-- Name: ix_ot_alerts_org_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_alerts_org_status ON public.ot_alerts USING btree (organization_id, status);


--
-- Name: ix_ot_alerts_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_alerts_organization_id ON public.ot_alerts USING btree (organization_id);


--
-- Name: ix_ot_alerts_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_alerts_severity ON public.ot_alerts USING btree (severity);


--
-- Name: ix_ot_alerts_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_alerts_status ON public.ot_alerts USING btree (status);


--
-- Name: ix_ot_assets_asset_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_assets_asset_type ON public.ot_assets USING btree (asset_type);


--
-- Name: ix_ot_assets_criticality; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_assets_criticality ON public.ot_assets USING btree (criticality);


--
-- Name: ix_ot_assets_ip_address; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_assets_ip_address ON public.ot_assets USING btree (ip_address);


--
-- Name: ix_ot_assets_is_online; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_assets_is_online ON public.ot_assets USING btree (is_online);


--
-- Name: ix_ot_assets_last_seen; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_assets_last_seen ON public.ot_assets USING btree (last_seen);


--
-- Name: ix_ot_assets_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_assets_name ON public.ot_assets USING btree (name);


--
-- Name: ix_ot_assets_org_level; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_assets_org_level ON public.ot_assets USING btree (organization_id, purdue_level);


--
-- Name: ix_ot_assets_org_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_assets_org_type ON public.ot_assets USING btree (organization_id, asset_type);


--
-- Name: ix_ot_assets_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_assets_organization_id ON public.ot_assets USING btree (organization_id);


--
-- Name: ix_ot_assets_purdue_level; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_assets_purdue_level ON public.ot_assets USING btree (purdue_level);


--
-- Name: ix_ot_assets_risk_score; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_assets_risk_score ON public.ot_assets USING btree (risk_score);


--
-- Name: ix_ot_assets_zone; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_assets_zone ON public.ot_assets USING btree (zone);


--
-- Name: ix_ot_incidents_incident_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_incidents_incident_type ON public.ot_incidents USING btree (incident_type);


--
-- Name: ix_ot_incidents_org_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_incidents_org_severity ON public.ot_incidents USING btree (organization_id, severity);


--
-- Name: ix_ot_incidents_org_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_incidents_org_status ON public.ot_incidents USING btree (organization_id, status);


--
-- Name: ix_ot_incidents_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_incidents_organization_id ON public.ot_incidents USING btree (organization_id);


--
-- Name: ix_ot_incidents_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_incidents_severity ON public.ot_incidents USING btree (severity);


--
-- Name: ix_ot_incidents_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_incidents_status ON public.ot_incidents USING btree (status);


--
-- Name: ix_ot_policies_org_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_policies_org_type ON public.ot_policy_rules USING btree (organization_id, rule_type);


--
-- Name: ix_ot_policy_rules_enabled; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_policy_rules_enabled ON public.ot_policy_rules USING btree (enabled);


--
-- Name: ix_ot_policy_rules_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_policy_rules_organization_id ON public.ot_policy_rules USING btree (organization_id);


--
-- Name: ix_ot_policy_rules_rule_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_policy_rules_rule_type ON public.ot_policy_rules USING btree (rule_type);


--
-- Name: ix_ot_zones_org_level; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_zones_org_level ON public.ot_zones USING btree (organization_id, purdue_level);


--
-- Name: ix_ot_zones_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_zones_organization_id ON public.ot_zones USING btree (organization_id);


--
-- Name: ix_ot_zones_purdue_level; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ot_zones_purdue_level ON public.ot_zones USING btree (purdue_level);


--
-- Name: ix_patch_operations_deployment_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_patch_operations_deployment_status ON public.patch_operations USING btree (deployment_status);


--
-- Name: ix_patch_operations_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_patch_operations_organization_id ON public.patch_operations USING btree (organization_id);


--
-- Name: ix_patch_operations_vulnerability_instance_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_patch_operations_vulnerability_instance_id ON public.patch_operations USING btree (vulnerability_instance_id);


--
-- Name: ix_playbook_edges_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_playbook_edges_organization_id ON public.playbook_edges USING btree (organization_id);


--
-- Name: ix_playbook_edges_playbook_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_playbook_edges_playbook_id ON public.playbook_edges USING btree (playbook_id);


--
-- Name: ix_playbook_node_executions_execution_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_playbook_node_executions_execution_id ON public.playbook_node_executions USING btree (execution_id);


--
-- Name: ix_playbook_node_executions_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_playbook_node_executions_organization_id ON public.playbook_node_executions USING btree (organization_id);


--
-- Name: ix_playbook_nodes_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_playbook_nodes_organization_id ON public.playbook_nodes USING btree (organization_id);


--
-- Name: ix_playbook_nodes_playbook_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_playbook_nodes_playbook_id ON public.playbook_nodes USING btree (playbook_id);


--
-- Name: ix_playbooks_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_playbooks_name ON public.playbooks USING btree (name);


--
-- Name: ix_poams_control_id_ref; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_poams_control_id_ref ON public.poams USING btree (control_id_ref);


--
-- Name: ix_poams_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_poams_organization_id ON public.poams USING btree (organization_id);


--
-- Name: ix_poams_scheduled_completion_date; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_poams_scheduled_completion_date ON public.poams USING btree (scheduled_completion_date);


--
-- Name: ix_poams_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_poams_status ON public.poams USING btree (status);


--
-- Name: ix_policy_org_type_enforcement; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_policy_org_type_enforcement ON public.api_security_policies USING btree (organization_id, policy_type, enforcement_level);


--
-- Name: ix_privacy_impact_assessments_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_privacy_impact_assessments_organization_id ON public.privacy_impact_assessments USING btree (organization_id);


--
-- Name: ix_privacy_impact_assessments_project_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_privacy_impact_assessments_project_name ON public.privacy_impact_assessments USING btree (project_name);


--
-- Name: ix_privacy_impact_assessments_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_privacy_impact_assessments_status ON public.privacy_impact_assessments USING btree (status);


--
-- Name: ix_privacy_incidents_incident_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_privacy_incidents_incident_type ON public.privacy_incidents USING btree (incident_type);


--
-- Name: ix_privacy_incidents_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_privacy_incidents_organization_id ON public.privacy_incidents USING btree (organization_id);


--
-- Name: ix_privacy_incidents_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_privacy_incidents_severity ON public.privacy_incidents USING btree (severity);


--
-- Name: ix_privacy_incidents_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_privacy_incidents_status ON public.privacy_incidents USING btree (status);


--
-- Name: ix_privacy_incidents_title; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_privacy_incidents_title ON public.privacy_incidents USING btree (title);


--
-- Name: ix_privileged_access_events_event_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_privileged_access_events_event_type ON public.privileged_access_events USING btree (event_type);


--
-- Name: ix_privileged_access_events_identity_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_privileged_access_events_identity_id ON public.privileged_access_events USING btree (identity_id);


--
-- Name: ix_privileged_access_events_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_privileged_access_events_organization_id ON public.privileged_access_events USING btree (organization_id);


--
-- Name: ix_query_jobs_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_query_jobs_organization_id ON public.query_jobs USING btree (organization_id);


--
-- Name: ix_query_jobs_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_query_jobs_status ON public.query_jobs USING btree (status);


--
-- Name: ix_reasoning_steps_investigation_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_reasoning_steps_investigation_id ON public.reasoning_steps USING btree (investigation_id);


--
-- Name: ix_reasoning_steps_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_reasoning_steps_organization_id ON public.reasoning_steps USING btree (organization_id);


--
-- Name: ix_remediation_tickets_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_remediation_tickets_organization_id ON public.remediation_tickets USING btree (organization_id);


--
-- Name: ix_remediation_tickets_priority; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_remediation_tickets_priority ON public.remediation_tickets USING btree (priority);


--
-- Name: ix_remediation_tickets_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_remediation_tickets_status ON public.remediation_tickets USING btree (status);


--
-- Name: ix_risk_controls_control_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_risk_controls_control_name ON public.risk_controls USING btree (control_name);


--
-- Name: ix_risk_controls_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_risk_controls_organization_id ON public.risk_controls USING btree (organization_id);


--
-- Name: ix_risk_controls_risk_register_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_risk_controls_risk_register_id ON public.risk_controls USING btree (risk_register_id);


--
-- Name: ix_risk_registers_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_risk_registers_name ON public.risk_registers USING btree (name);


--
-- Name: ix_risk_registers_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_risk_registers_organization_id ON public.risk_registers USING btree (organization_id);


--
-- Name: ix_risk_registers_risk_category; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_risk_registers_risk_category ON public.risk_registers USING btree (risk_category);


--
-- Name: ix_risk_scenarios_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_risk_scenarios_name ON public.risk_scenarios USING btree (name);


--
-- Name: ix_risk_scenarios_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_risk_scenarios_organization_id ON public.risk_scenarios USING btree (organization_id);


--
-- Name: ix_runtime_alerts_alert_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_runtime_alerts_alert_type ON public.runtime_alerts USING btree (alert_type);


--
-- Name: ix_runtime_alerts_cluster_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_runtime_alerts_cluster_id ON public.runtime_alerts USING btree (cluster_id);


--
-- Name: ix_runtime_alerts_namespace; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_runtime_alerts_namespace ON public.runtime_alerts USING btree (namespace);


--
-- Name: ix_runtime_alerts_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_runtime_alerts_organization_id ON public.runtime_alerts USING btree (organization_id);


--
-- Name: ix_runtime_alerts_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_runtime_alerts_severity ON public.runtime_alerts USING btree (severity);


--
-- Name: ix_runtime_alerts_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_runtime_alerts_status ON public.runtime_alerts USING btree (status);


--
-- Name: ix_sbom_components_component_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_sbom_components_component_id ON public.sbom_components USING btree (component_id);


--
-- Name: ix_sbom_components_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_sbom_components_organization_id ON public.sbom_components USING btree (organization_id);


--
-- Name: ix_sbom_components_sbom_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_sbom_components_sbom_id ON public.sbom_components USING btree (sbom_id);


--
-- Name: ix_sboms_application_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_sboms_application_name ON public.sboms USING btree (application_name);


--
-- Name: ix_sboms_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_sboms_name ON public.sboms USING btree (name);


--
-- Name: ix_sboms_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_sboms_organization_id ON public.sboms USING btree (organization_id);


--
-- Name: ix_scan_profiles_enabled; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_scan_profiles_enabled ON public.scan_profiles USING btree (enabled);


--
-- Name: ix_scan_profiles_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_scan_profiles_name ON public.scan_profiles USING btree (name);


--
-- Name: ix_scan_profiles_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_scan_profiles_organization_id ON public.scan_profiles USING btree (organization_id);


--
-- Name: ix_scap_profiles_enabled; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_scap_profiles_enabled ON public.scap_profiles USING btree (is_enabled, created_at);


--
-- Name: ix_scap_profiles_is_enabled; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_scap_profiles_is_enabled ON public.scap_profiles USING btree (is_enabled);


--
-- Name: ix_scap_profiles_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_scap_profiles_name ON public.scap_profiles USING btree (name);


--
-- Name: ix_scap_profiles_org_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_scap_profiles_org_type ON public.scap_profiles USING btree (organization_id, profile_type);


--
-- Name: ix_scap_profiles_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_scap_profiles_organization_id ON public.scap_profiles USING btree (organization_id);


--
-- Name: ix_scap_profiles_profile_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_scap_profiles_profile_type ON public.scap_profiles USING btree (profile_type);


--
-- Name: ix_sensitive_data_discoveries_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_sensitive_data_discoveries_organization_id ON public.sensitive_data_discoveries USING btree (organization_id);


--
-- Name: ix_sensitive_data_discoveries_scan_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_sensitive_data_discoveries_scan_id ON public.sensitive_data_discoveries USING btree (scan_id);


--
-- Name: ix_shared_artifacts_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_shared_artifacts_organization_id ON public.shared_artifacts USING btree (organization_id);


--
-- Name: ix_shared_artifacts_room_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_shared_artifacts_room_id ON public.shared_artifacts USING btree (room_id);


--
-- Name: ix_siem_data_sources_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE UNIQUE INDEX ix_siem_data_sources_name ON public.siem_data_sources USING btree (name);


--
-- Name: ix_siem_data_sources_source_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_siem_data_sources_source_type ON public.siem_data_sources USING btree (source_type);


--
-- Name: ix_siem_saved_searches_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_siem_saved_searches_name ON public.siem_saved_searches USING btree (name);


--
-- Name: ix_soc_agents_agent_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_soc_agents_agent_type ON public.soc_agents USING btree (agent_type);


--
-- Name: ix_soc_agents_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_soc_agents_name ON public.soc_agents USING btree (name);


--
-- Name: ix_soc_agents_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_soc_agents_organization_id ON public.soc_agents USING btree (organization_id);


--
-- Name: ix_soc_agents_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_soc_agents_status ON public.soc_agents USING btree (status);


--
-- Name: ix_software_components_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_software_components_name ON public.software_components USING btree (name);


--
-- Name: ix_software_components_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_software_components_organization_id ON public.software_components USING btree (organization_id);


--
-- Name: ix_software_components_package_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_software_components_package_type ON public.software_components USING btree (package_type);


--
-- Name: ix_software_components_risk_score; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_software_components_risk_score ON public.software_components USING btree (risk_score);


--
-- Name: ix_software_components_version; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_software_components_version ON public.software_components USING btree (version);


--
-- Name: ix_stig_benchmarks_benchmark_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE UNIQUE INDEX ix_stig_benchmarks_benchmark_id ON public.stig_benchmarks USING btree (benchmark_id);


--
-- Name: ix_stig_benchmarks_org_benchmark; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_stig_benchmarks_org_benchmark ON public.stig_benchmarks USING btree (organization_id, benchmark_id);


--
-- Name: ix_stig_benchmarks_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_stig_benchmarks_organization_id ON public.stig_benchmarks USING btree (organization_id);


--
-- Name: ix_stig_benchmarks_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_stig_benchmarks_status ON public.stig_benchmarks USING btree (status);


--
-- Name: ix_stig_benchmarks_status_created; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_stig_benchmarks_status_created ON public.stig_benchmarks USING btree (status, created_at);


--
-- Name: ix_stig_rules_benchmark_id_ref; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_stig_rules_benchmark_id_ref ON public.stig_rules USING btree (benchmark_id_ref);


--
-- Name: ix_stig_rules_benchmark_rule; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_stig_rules_benchmark_rule ON public.stig_rules USING btree (benchmark_id_ref, rule_id);


--
-- Name: ix_stig_rules_default_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_stig_rules_default_status ON public.stig_rules USING btree (default_status);


--
-- Name: ix_stig_rules_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_stig_rules_organization_id ON public.stig_rules USING btree (organization_id);


--
-- Name: ix_stig_rules_rule_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_stig_rules_rule_id ON public.stig_rules USING btree (rule_id);


--
-- Name: ix_stig_rules_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_stig_rules_severity ON public.stig_rules USING btree (severity);


--
-- Name: ix_stig_rules_severity_org; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_stig_rules_severity_org ON public.stig_rules USING btree (severity, organization_id);


--
-- Name: ix_stig_scan_results_benchmark_id_ref; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_stig_scan_results_benchmark_id_ref ON public.stig_scan_results USING btree (benchmark_id_ref);


--
-- Name: ix_stig_scan_results_org_created; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_stig_scan_results_org_created ON public.stig_scan_results USING btree (organization_id, created_at);


--
-- Name: ix_stig_scan_results_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_stig_scan_results_organization_id ON public.stig_scan_results USING btree (organization_id);


--
-- Name: ix_stig_scan_results_scan_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_stig_scan_results_scan_type ON public.stig_scan_results USING btree (scan_type);


--
-- Name: ix_stig_scan_results_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_stig_scan_results_status ON public.stig_scan_results USING btree (status);


--
-- Name: ix_stig_scan_results_status_benchmark; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_stig_scan_results_status_benchmark ON public.stig_scan_results USING btree (status, benchmark_id_ref);


--
-- Name: ix_stig_scan_results_target_host; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_stig_scan_results_target_host ON public.stig_scan_results USING btree (target_host);


--
-- Name: ix_stig_scan_results_target_time; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_stig_scan_results_target_time ON public.stig_scan_results USING btree (target_host, completed_at);


--
-- Name: ix_supply_chain_risks_component_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_supply_chain_risks_component_id ON public.supply_chain_risks USING btree (component_id);


--
-- Name: ix_supply_chain_risks_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_supply_chain_risks_organization_id ON public.supply_chain_risks USING btree (organization_id);


--
-- Name: ix_supply_chain_risks_risk_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_supply_chain_risks_risk_type ON public.supply_chain_risks USING btree (risk_type);


--
-- Name: ix_supply_chain_risks_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_supply_chain_risks_severity ON public.supply_chain_risks USING btree (severity);


--
-- Name: ix_supply_chain_risks_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_supply_chain_risks_status ON public.supply_chain_risks USING btree (status);


--
-- Name: ix_team_members_team_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_team_members_team_id ON public.team_members USING btree (team_id);


--
-- Name: ix_team_members_user_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_team_members_user_id ON public.team_members USING btree (user_id);


--
-- Name: ix_teams_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_teams_organization_id ON public.teams USING btree (organization_id);


--
-- Name: ix_threat_indicators_value; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_threat_indicators_value ON public.threat_indicators USING btree (value);


--
-- Name: ix_threat_mitigations_implementation_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_threat_mitigations_implementation_status ON public.threat_mitigations USING btree (implementation_status);


--
-- Name: ix_threat_mitigations_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_threat_mitigations_organization_id ON public.threat_mitigations USING btree (organization_id);


--
-- Name: ix_threat_mitigations_threat_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_threat_mitigations_threat_id ON public.threat_mitigations USING btree (threat_id);


--
-- Name: ix_threat_model_components_component_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_threat_model_components_component_type ON public.threat_model_components USING btree (component_type);


--
-- Name: ix_threat_model_components_model_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_threat_model_components_model_id ON public.threat_model_components USING btree (model_id);


--
-- Name: ix_threat_model_components_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_threat_model_components_organization_id ON public.threat_model_components USING btree (organization_id);


--
-- Name: ix_threat_models_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_threat_models_name ON public.threat_models USING btree (name);


--
-- Name: ix_threat_models_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_threat_models_organization_id ON public.threat_models USING btree (organization_id);


--
-- Name: ix_threat_models_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_threat_models_status ON public.threat_models USING btree (status);


--
-- Name: ix_ticket_activities_source_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ticket_activities_source_id ON public.ticket_activities USING btree (source_id);


--
-- Name: ix_ticket_activities_source_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ticket_activities_source_type ON public.ticket_activities USING btree (source_type);


--
-- Name: ix_ticket_comments_source_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ticket_comments_source_id ON public.ticket_comments USING btree (source_id);


--
-- Name: ix_ticket_comments_source_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_ticket_comments_source_type ON public.ticket_comments USING btree (source_type);


--
-- Name: ix_unified_data_models_entity_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_unified_data_models_entity_type ON public.unified_data_models USING btree (entity_type);


--
-- Name: ix_unified_data_models_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_unified_data_models_name ON public.unified_data_models USING btree (name);


--
-- Name: ix_unified_data_models_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_unified_data_models_organization_id ON public.unified_data_models USING btree (organization_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_vendor_assessments_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_vendor_assessments_organization_id ON public.vendor_assessments USING btree (organization_id);


--
-- Name: ix_vendor_assessments_risk_tier; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_vendor_assessments_risk_tier ON public.vendor_assessments USING btree (risk_tier);


--
-- Name: ix_vendor_assessments_security_score; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_vendor_assessments_security_score ON public.vendor_assessments USING btree (security_score);


--
-- Name: ix_vendor_assessments_vendor_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_vendor_assessments_vendor_name ON public.vendor_assessments USING btree (vendor_name);


--
-- Name: ix_visual_playbook_executions_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_visual_playbook_executions_organization_id ON public.visual_playbook_executions USING btree (organization_id);


--
-- Name: ix_visual_playbook_executions_playbook_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_visual_playbook_executions_playbook_id ON public.visual_playbook_executions USING btree (playbook_id);


--
-- Name: ix_visual_playbook_executions_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_visual_playbook_executions_status ON public.visual_playbook_executions USING btree (status);


--
-- Name: ix_visual_playbooks_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_visual_playbooks_name ON public.visual_playbooks USING btree (name);


--
-- Name: ix_visual_playbooks_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_visual_playbooks_organization_id ON public.visual_playbooks USING btree (organization_id);


--
-- Name: ix_visual_playbooks_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_visual_playbooks_status ON public.visual_playbooks USING btree (status);


--
-- Name: ix_vuln_endpoint_type_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_vuln_endpoint_type_status ON public.api_vulnerabilities USING btree (endpoint_id, vulnerability_type, status);


--
-- Name: ix_vuln_image_cve; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_vuln_image_cve ON public.image_vulnerabilities USING btree (image_id, cve_id);


--
-- Name: ix_vuln_org_cve; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_vuln_org_cve ON public.image_vulnerabilities USING btree (organization_id, cve_id);


--
-- Name: ix_vuln_org_severity_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_vuln_org_severity_status ON public.api_vulnerabilities USING btree (organization_id, severity, status);


--
-- Name: ix_vulnerabilities_cve_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE UNIQUE INDEX ix_vulnerabilities_cve_id ON public.vulnerabilities USING btree (cve_id);


--
-- Name: ix_vulnerabilities_kev_listed; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_vulnerabilities_kev_listed ON public.vulnerabilities USING btree (kev_listed);


--
-- Name: ix_vulnerabilities_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_vulnerabilities_organization_id ON public.vulnerabilities USING btree (organization_id);


--
-- Name: ix_vulnerabilities_severity; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_vulnerabilities_severity ON public.vulnerabilities USING btree (severity);


--
-- Name: ix_vulnerabilities_title; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_vulnerabilities_title ON public.vulnerabilities USING btree (title);


--
-- Name: ix_vulnerabilities_vulnerability_type; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_vulnerabilities_vulnerability_type ON public.vulnerabilities USING btree (vulnerability_type);


--
-- Name: ix_vulnerability_exceptions_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_vulnerability_exceptions_organization_id ON public.vulnerability_exceptions USING btree (organization_id);


--
-- Name: ix_vulnerability_exceptions_vulnerability_instance_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_vulnerability_exceptions_vulnerability_instance_id ON public.vulnerability_exceptions USING btree (vulnerability_instance_id);


--
-- Name: ix_vulnerability_instances_asset_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_vulnerability_instances_asset_id ON public.vulnerability_instances USING btree (asset_id);


--
-- Name: ix_vulnerability_instances_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_vulnerability_instances_organization_id ON public.vulnerability_instances USING btree (organization_id);


--
-- Name: ix_vulnerability_instances_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_vulnerability_instances_status ON public.vulnerability_instances USING btree (status);


--
-- Name: ix_vulnerability_instances_vulnerability_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_vulnerability_instances_vulnerability_id ON public.vulnerability_instances USING btree (vulnerability_id);


--
-- Name: ix_war_room_messages_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_war_room_messages_organization_id ON public.war_room_messages USING btree (organization_id);


--
-- Name: ix_war_room_messages_room_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_war_room_messages_room_id ON public.war_room_messages USING btree (room_id);


--
-- Name: ix_war_rooms_incident_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_war_rooms_incident_id ON public.war_rooms USING btree (incident_id);


--
-- Name: ix_war_rooms_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_war_rooms_name ON public.war_rooms USING btree (name);


--
-- Name: ix_war_rooms_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_war_rooms_organization_id ON public.war_rooms USING btree (organization_id);


--
-- Name: ix_war_rooms_status; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_war_rooms_status ON public.war_rooms USING btree (status);


--
-- Name: ix_webhook_endpoints_installed_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_webhook_endpoints_installed_id ON public.webhook_endpoints USING btree (installed_id);


--
-- Name: ix_webhook_endpoints_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_webhook_endpoints_organization_id ON public.webhook_endpoints USING btree (organization_id);


--
-- Name: ix_zero_trust_policies_microsegment_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_zero_trust_policies_microsegment_id ON public.zero_trust_policies USING btree (microsegment_id);


--
-- Name: ix_zero_trust_policies_name; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_zero_trust_policies_name ON public.zero_trust_policies USING btree (name);


--
-- Name: ix_zero_trust_policies_organization_id; Type: INDEX; Schema: public; Owner: pysoar
--

CREATE INDEX ix_zero_trust_policies_organization_id ON public.zero_trust_policies USING btree (organization_id);


--
-- Name: access_anomalies access_anomalies_identity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.access_anomalies
    ADD CONSTRAINT access_anomalies_identity_id_fkey FOREIGN KEY (identity_id) REFERENCES public.identity_profiles(id);


--
-- Name: action_items action_items_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.action_items
    ADD CONSTRAINT action_items_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.war_rooms(id);


--
-- Name: adversary_profiles adversary_profiles_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.adversary_profiles
    ADD CONSTRAINT adversary_profiles_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: agent_actions agent_actions_investigation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.agent_actions
    ADD CONSTRAINT agent_actions_investigation_id_fkey FOREIGN KEY (investigation_id) REFERENCES public.investigations(id);


--
-- Name: agent_actions agent_actions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.agent_actions
    ADD CONSTRAINT agent_actions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: agent_memories agent_memories_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.agent_memories
    ADD CONSTRAINT agent_memories_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.soc_agents(id);


--
-- Name: agent_memories agent_memories_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.agent_memories
    ADD CONSTRAINT agent_memories_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: ai_analyses ai_analyses_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ai_analyses
    ADD CONSTRAINT ai_analyses_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: alerts alerts_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: alerts alerts_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.incidents(id);


--
-- Name: anomaly_detections anomaly_detections_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.anomaly_detections
    ADD CONSTRAINT anomaly_detections_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ml_models(id);


--
-- Name: anomaly_detections anomaly_detections_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.anomaly_detections
    ADD CONSTRAINT anomaly_detections_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: api_anomaly_detection api_anomaly_detection_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.api_anomaly_detection
    ADD CONSTRAINT api_anomaly_detection_endpoint_id_fkey FOREIGN KEY (endpoint_id) REFERENCES public.api_endpoint_inventory(id);


--
-- Name: api_anomaly_detection api_anomaly_detection_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.api_anomaly_detection
    ADD CONSTRAINT api_anomaly_detection_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: api_compliance_checks api_compliance_checks_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.api_compliance_checks
    ADD CONSTRAINT api_compliance_checks_endpoint_id_fkey FOREIGN KEY (endpoint_id) REFERENCES public.api_endpoint_inventory(id);


--
-- Name: api_compliance_checks api_compliance_checks_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.api_compliance_checks
    ADD CONSTRAINT api_compliance_checks_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: api_endpoint_inventory api_endpoint_inventory_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.api_endpoint_inventory
    ADD CONSTRAINT api_endpoint_inventory_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: api_keys api_keys_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: api_security_policies api_security_policies_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.api_security_policies
    ADD CONSTRAINT api_security_policies_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: api_vulnerabilities api_vulnerabilities_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.api_vulnerabilities
    ADD CONSTRAINT api_vulnerabilities_endpoint_id_fkey FOREIGN KEY (endpoint_id) REFERENCES public.api_endpoint_inventory(id);


--
-- Name: api_vulnerabilities api_vulnerabilities_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.api_vulnerabilities
    ADD CONSTRAINT api_vulnerabilities_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: asset_vulnerabilities asset_vulnerabilities_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.asset_vulnerabilities
    ADD CONSTRAINT asset_vulnerabilities_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.exposure_assets(id);


--
-- Name: asset_vulnerabilities asset_vulnerabilities_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.asset_vulnerabilities
    ADD CONSTRAINT asset_vulnerabilities_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: asset_vulnerabilities asset_vulnerabilities_vulnerability_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.asset_vulnerabilities
    ADD CONSTRAINT asset_vulnerabilities_vulnerability_id_fkey FOREIGN KEY (vulnerability_id) REFERENCES public.exposure_vulnerabilities(id);


--
-- Name: attack_simulations attack_simulations_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.attack_simulations
    ADD CONSTRAINT attack_simulations_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: attack_simulations attack_simulations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.attack_simulations
    ADD CONSTRAINT attack_simulations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: attack_simulations attack_simulations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.attack_simulations
    ADD CONSTRAINT attack_simulations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: attack_surfaces attack_surfaces_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.attack_surfaces
    ADD CONSTRAINT attack_surfaces_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: attack_trees attack_trees_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.attack_trees
    ADD CONSTRAINT attack_trees_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.threat_models(id);


--
-- Name: attack_trees attack_trees_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.attack_trees
    ADD CONSTRAINT attack_trees_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: audit_trails audit_trails_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.audit_trails
    ADD CONSTRAINT audit_trails_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: automated_evidence_rules automated_evidence_rules_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.automated_evidence_rules
    ADD CONSTRAINT automated_evidence_rules_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: behavior_baselines behavior_baselines_entity_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.behavior_baselines
    ADD CONSTRAINT behavior_baselines_entity_profile_id_fkey FOREIGN KEY (entity_profile_id) REFERENCES public.entity_profiles(id);


--
-- Name: behavior_events behavior_events_entity_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.behavior_events
    ADD CONSTRAINT behavior_events_entity_profile_id_fkey FOREIGN KEY (entity_profile_id) REFERENCES public.entity_profiles(id);


--
-- Name: behavior_events behavior_events_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.behavior_events
    ADD CONSTRAINT behavior_events_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: campaign_events campaign_events_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.campaign_events
    ADD CONSTRAINT campaign_events_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.phishing_campaigns(id);


--
-- Name: campaign_events campaign_events_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.campaign_events
    ADD CONSTRAINT campaign_events_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: case_attachments case_attachments_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.case_attachments
    ADD CONSTRAINT case_attachments_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.incidents(id);


--
-- Name: case_attachments case_attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.case_attachments
    ADD CONSTRAINT case_attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: case_notes case_notes_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.case_notes
    ADD CONSTRAINT case_notes_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: case_notes case_notes_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.case_notes
    ADD CONSTRAINT case_notes_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.incidents(id);


--
-- Name: case_tasks case_tasks_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.case_tasks
    ADD CONSTRAINT case_tasks_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: case_tasks case_tasks_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.case_tasks
    ADD CONSTRAINT case_tasks_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: case_tasks case_tasks_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.case_tasks
    ADD CONSTRAINT case_tasks_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.incidents(id);


--
-- Name: case_timeline case_timeline_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.case_timeline
    ADD CONSTRAINT case_timeline_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: case_timeline case_timeline_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.case_timeline
    ADD CONSTRAINT case_timeline_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.incidents(id);


--
-- Name: cisa_directives cisa_directives_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.cisa_directives
    ADD CONSTRAINT cisa_directives_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: compliance_assessments compliance_assessments_framework_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.compliance_assessments
    ADD CONSTRAINT compliance_assessments_framework_id_fkey FOREIGN KEY (framework_id) REFERENCES public.compliance_frameworks(id);


--
-- Name: compliance_assessments compliance_assessments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.compliance_assessments
    ADD CONSTRAINT compliance_assessments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: compliance_controls compliance_controls_framework_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.compliance_controls
    ADD CONSTRAINT compliance_controls_framework_id_fkey FOREIGN KEY (framework_id) REFERENCES public.compliance_frameworks(id);


--
-- Name: compliance_controls compliance_controls_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.compliance_controls
    ADD CONSTRAINT compliance_controls_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: compliance_controls compliance_controls_poam_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.compliance_controls
    ADD CONSTRAINT compliance_controls_poam_id_fkey FOREIGN KEY (poam_id) REFERENCES public.poams(id);


--
-- Name: compliance_evidence compliance_evidence_control_id_ref_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.compliance_evidence
    ADD CONSTRAINT compliance_evidence_control_id_ref_fkey FOREIGN KEY (control_id_ref) REFERENCES public.compliance_controls(id);


--
-- Name: compliance_evidence compliance_evidence_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.compliance_evidence
    ADD CONSTRAINT compliance_evidence_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: compliance_frameworks compliance_frameworks_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.compliance_frameworks
    ADD CONSTRAINT compliance_frameworks_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: consent_records consent_records_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.consent_records
    ADD CONSTRAINT consent_records_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: container_images container_images_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.container_images
    ADD CONSTRAINT container_images_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: correlation_events correlation_events_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.correlation_events
    ADD CONSTRAINT correlation_events_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: correlation_events correlation_events_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.correlation_events
    ADD CONSTRAINT correlation_events_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.detection_rules(id);


--
-- Name: credential_exposures credential_exposures_identity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.credential_exposures
    ADD CONSTRAINT credential_exposures_identity_id_fkey FOREIGN KEY (identity_id) REFERENCES public.identity_profiles(id);


--
-- Name: cui_markings cui_markings_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.cui_markings
    ADD CONSTRAINT cui_markings_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: darkweb_brand_threats darkweb_brand_threats_finding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.darkweb_brand_threats
    ADD CONSTRAINT darkweb_brand_threats_finding_id_fkey FOREIGN KEY (finding_id) REFERENCES public.darkweb_findings(id) ON DELETE CASCADE;


--
-- Name: darkweb_credential_leaks darkweb_credential_leaks_finding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.darkweb_credential_leaks
    ADD CONSTRAINT darkweb_credential_leaks_finding_id_fkey FOREIGN KEY (finding_id) REFERENCES public.darkweb_findings(id) ON DELETE CASCADE;


--
-- Name: darkweb_findings darkweb_findings_monitor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.darkweb_findings
    ADD CONSTRAINT darkweb_findings_monitor_id_fkey FOREIGN KEY (monitor_id) REFERENCES public.darkweb_monitors(id) ON DELETE CASCADE;


--
-- Name: data_partitions data_partitions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.data_partitions
    ADD CONSTRAINT data_partitions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: data_partitions data_partitions_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.data_partitions
    ADD CONSTRAINT data_partitions_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.data_sources(id);


--
-- Name: data_pipelines data_pipelines_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.data_pipelines
    ADD CONSTRAINT data_pipelines_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: data_pipelines data_pipelines_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.data_pipelines
    ADD CONSTRAINT data_pipelines_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.data_sources(id);


--
-- Name: data_processing_records data_processing_records_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.data_processing_records
    ADD CONSTRAINT data_processing_records_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: data_sources data_sources_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.data_sources
    ADD CONSTRAINT data_sources_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: data_subject_requests data_subject_requests_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.data_subject_requests
    ADD CONSTRAINT data_subject_requests_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: deception_campaigns deception_campaigns_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.deception_campaigns
    ADD CONSTRAINT deception_campaigns_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: deception_campaigns deception_campaigns_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.deception_campaigns
    ADD CONSTRAINT deception_campaigns_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: decoy_interactions decoy_interactions_decoy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.decoy_interactions
    ADD CONSTRAINT decoy_interactions_decoy_id_fkey FOREIGN KEY (decoy_id) REFERENCES public.decoys(id);


--
-- Name: decoy_interactions decoy_interactions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.decoy_interactions
    ADD CONSTRAINT decoy_interactions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: decoys decoys_deployed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.decoys
    ADD CONSTRAINT decoys_deployed_by_fkey FOREIGN KEY (deployed_by) REFERENCES public.users(id);


--
-- Name: decoys decoys_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.decoys
    ADD CONSTRAINT decoys_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: detection_rules detection_rules_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.detection_rules
    ADD CONSTRAINT detection_rules_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: entity_profiles entity_profiles_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.entity_profiles
    ADD CONSTRAINT entity_profiles_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: evidence_packages evidence_packages_framework_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.evidence_packages
    ADD CONSTRAINT evidence_packages_framework_id_fkey FOREIGN KEY (framework_id) REFERENCES public.compliance_frameworks(id);


--
-- Name: evidence_packages evidence_packages_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.evidence_packages
    ADD CONSTRAINT evidence_packages_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: exposure_assets exposure_assets_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.exposure_assets
    ADD CONSTRAINT exposure_assets_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: exposure_scans exposure_scans_initiated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.exposure_scans
    ADD CONSTRAINT exposure_scans_initiated_by_fkey FOREIGN KEY (initiated_by) REFERENCES public.users(id);


--
-- Name: exposure_scans exposure_scans_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.exposure_scans
    ADD CONSTRAINT exposure_scans_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: exposure_vulnerabilities exposure_vulnerabilities_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.exposure_vulnerabilities
    ADD CONSTRAINT exposure_vulnerabilities_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: forensic_artifacts forensic_artifacts_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.forensic_artifacts
    ADD CONSTRAINT forensic_artifacts_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.forensic_cases(id);


--
-- Name: forensic_artifacts forensic_artifacts_evidence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.forensic_artifacts
    ADD CONSTRAINT forensic_artifacts_evidence_id_fkey FOREIGN KEY (evidence_id) REFERENCES public.forensic_evidence(id);


--
-- Name: forensic_cases forensic_cases_lead_investigator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.forensic_cases
    ADD CONSTRAINT forensic_cases_lead_investigator_id_fkey FOREIGN KEY (lead_investigator_id) REFERENCES public.users(id);


--
-- Name: forensic_evidence forensic_evidence_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.forensic_evidence
    ADD CONSTRAINT forensic_evidence_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.forensic_cases(id);


--
-- Name: forensic_timeline forensic_timeline_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.forensic_timeline
    ADD CONSTRAINT forensic_timeline_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.forensic_cases(id);


--
-- Name: forensic_timeline forensic_timeline_source_evidence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.forensic_timeline
    ADD CONSTRAINT forensic_timeline_source_evidence_id_fkey FOREIGN KEY (source_evidence_id) REFERENCES public.forensic_evidence(id);


--
-- Name: honey_tokens honey_tokens_deployed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.honey_tokens
    ADD CONSTRAINT honey_tokens_deployed_by_fkey FOREIGN KEY (deployed_by) REFERENCES public.users(id);


--
-- Name: honey_tokens honey_tokens_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.honey_tokens
    ADD CONSTRAINT honey_tokens_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: hunt_findings hunt_findings_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.hunt_findings
    ADD CONSTRAINT hunt_findings_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: hunt_findings hunt_findings_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.hunt_findings
    ADD CONSTRAINT hunt_findings_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.hunt_sessions(id);


--
-- Name: hunt_hypotheses hunt_hypotheses_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.hunt_hypotheses
    ADD CONSTRAINT hunt_hypotheses_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: hunt_hypotheses hunt_hypotheses_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.hunt_hypotheses
    ADD CONSTRAINT hunt_hypotheses_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: hunt_notebooks hunt_notebooks_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.hunt_notebooks
    ADD CONSTRAINT hunt_notebooks_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.hunt_sessions(id);


--
-- Name: hunt_sessions hunt_sessions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.hunt_sessions
    ADD CONSTRAINT hunt_sessions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: hunt_sessions hunt_sessions_hypothesis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.hunt_sessions
    ADD CONSTRAINT hunt_sessions_hypothesis_id_fkey FOREIGN KEY (hypothesis_id) REFERENCES public.hunt_hypotheses(id);


--
-- Name: identified_threats identified_threats_component_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.identified_threats
    ADD CONSTRAINT identified_threats_component_id_fkey FOREIGN KEY (component_id) REFERENCES public.threat_model_components(id);


--
-- Name: identified_threats identified_threats_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.identified_threats
    ADD CONSTRAINT identified_threats_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.threat_models(id);


--
-- Name: identified_threats identified_threats_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.identified_threats
    ADD CONSTRAINT identified_threats_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: identity_threats identity_threats_identity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.identity_threats
    ADD CONSTRAINT identity_threats_identity_id_fkey FOREIGN KEY (identity_id) REFERENCES public.identity_profiles(id);


--
-- Name: image_vulnerabilities image_vulnerabilities_image_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.image_vulnerabilities
    ADD CONSTRAINT image_vulnerabilities_image_id_fkey FOREIGN KEY (image_id) REFERENCES public.container_images(id);


--
-- Name: image_vulnerabilities image_vulnerabilities_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.image_vulnerabilities
    ADD CONSTRAINT image_vulnerabilities_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: incident_timeline incident_timeline_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.incident_timeline
    ADD CONSTRAINT incident_timeline_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.war_rooms(id);


--
-- Name: incidents incidents_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.incidents
    ADD CONSTRAINT incidents_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: indicator_sightings indicator_sightings_indicator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.indicator_sightings
    ADD CONSTRAINT indicator_sightings_indicator_id_fkey FOREIGN KEY (indicator_id) REFERENCES public.threat_indicators(id);


--
-- Name: indicator_sightings indicator_sightings_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.indicator_sightings
    ADD CONSTRAINT indicator_sightings_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: installed_integrations installed_integrations_connector_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.installed_integrations
    ADD CONSTRAINT installed_integrations_connector_id_fkey FOREIGN KEY (connector_id) REFERENCES public.integration_connectors(id);


--
-- Name: integration_actions integration_actions_connector_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.integration_actions
    ADD CONSTRAINT integration_actions_connector_id_fkey FOREIGN KEY (connector_id) REFERENCES public.integration_connectors(id);


--
-- Name: integration_executions integration_executions_action_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.integration_executions
    ADD CONSTRAINT integration_executions_action_id_fkey FOREIGN KEY (action_id) REFERENCES public.integration_actions(id);


--
-- Name: integration_executions integration_executions_installed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.integration_executions
    ADD CONSTRAINT integration_executions_installed_id_fkey FOREIGN KEY (installed_id) REFERENCES public.installed_integrations(id);


--
-- Name: intel_reports intel_reports_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.intel_reports
    ADD CONSTRAINT intel_reports_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: intel_reports intel_reports_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.intel_reports
    ADD CONSTRAINT intel_reports_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: investigations investigations_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.investigations
    ADD CONSTRAINT investigations_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.soc_agents(id);


--
-- Name: investigations investigations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.investigations
    ADD CONSTRAINT investigations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: k8s_security_findings k8s_security_findings_cluster_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.k8s_security_findings
    ADD CONSTRAINT k8s_security_findings_cluster_id_fkey FOREIGN KEY (cluster_id) REFERENCES public.kubernetes_clusters(id);


--
-- Name: k8s_security_findings k8s_security_findings_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.k8s_security_findings
    ADD CONSTRAINT k8s_security_findings_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: kubernetes_clusters kubernetes_clusters_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.kubernetes_clusters
    ADD CONSTRAINT kubernetes_clusters_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: legal_holds legal_holds_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.legal_holds
    ADD CONSTRAINT legal_holds_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.forensic_cases(id);


--
-- Name: log_entries log_entries_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.log_entries
    ADD CONSTRAINT log_entries_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: ml_models ml_models_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT ml_models_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: nl_queries nl_queries_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.nl_queries
    ADD CONSTRAINT nl_queries_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: nl_queries nl_queries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.nl_queries
    ADD CONSTRAINT nl_queries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: organization_members organization_members_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.organization_members
    ADD CONSTRAINT organization_members_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: organization_members organization_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.organization_members
    ADD CONSTRAINT organization_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: ot_alerts ot_alerts_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ot_alerts
    ADD CONSTRAINT ot_alerts_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.ot_assets(id);


--
-- Name: ot_alerts ot_alerts_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ot_alerts
    ADD CONSTRAINT ot_alerts_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: ot_assets ot_assets_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ot_assets
    ADD CONSTRAINT ot_assets_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: ot_incidents ot_incidents_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ot_incidents
    ADD CONSTRAINT ot_incidents_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: ot_policy_rules ot_policy_rules_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ot_policy_rules
    ADD CONSTRAINT ot_policy_rules_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: ot_zones ot_zones_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ot_zones
    ADD CONSTRAINT ot_zones_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: patch_operations patch_operations_vulnerability_instance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.patch_operations
    ADD CONSTRAINT patch_operations_vulnerability_instance_id_fkey FOREIGN KEY (vulnerability_instance_id) REFERENCES public.vulnerability_instances(id);


--
-- Name: peer_groups peer_groups_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.peer_groups
    ADD CONSTRAINT peer_groups_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: phishing_campaigns phishing_campaigns_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.phishing_campaigns
    ADD CONSTRAINT phishing_campaigns_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: phishing_campaigns phishing_campaigns_target_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.phishing_campaigns
    ADD CONSTRAINT phishing_campaigns_target_group_id_fkey FOREIGN KEY (target_group_id) REFERENCES public.target_groups(id);


--
-- Name: phishing_campaigns phishing_campaigns_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.phishing_campaigns
    ADD CONSTRAINT phishing_campaigns_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.phishing_templates(id);


--
-- Name: phishing_templates phishing_templates_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.phishing_templates
    ADD CONSTRAINT phishing_templates_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: playbook_edges playbook_edges_playbook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.playbook_edges
    ADD CONSTRAINT playbook_edges_playbook_id_fkey FOREIGN KEY (playbook_id) REFERENCES public.visual_playbooks(id);


--
-- Name: playbook_executions playbook_executions_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.playbook_executions
    ADD CONSTRAINT playbook_executions_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.incidents(id);


--
-- Name: playbook_executions playbook_executions_playbook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.playbook_executions
    ADD CONSTRAINT playbook_executions_playbook_id_fkey FOREIGN KEY (playbook_id) REFERENCES public.playbooks(id);


--
-- Name: playbook_node_executions playbook_node_executions_execution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.playbook_node_executions
    ADD CONSTRAINT playbook_node_executions_execution_id_fkey FOREIGN KEY (execution_id) REFERENCES public.visual_playbook_executions(id);


--
-- Name: playbook_nodes playbook_nodes_playbook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.playbook_nodes
    ADD CONSTRAINT playbook_nodes_playbook_id_fkey FOREIGN KEY (playbook_id) REFERENCES public.visual_playbooks(id);


--
-- Name: poams poams_control_id_ref_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.poams
    ADD CONSTRAINT poams_control_id_ref_fkey FOREIGN KEY (control_id_ref) REFERENCES public.compliance_controls(id);


--
-- Name: poams poams_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.poams
    ADD CONSTRAINT poams_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: privacy_impact_assessments privacy_impact_assessments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.privacy_impact_assessments
    ADD CONSTRAINT privacy_impact_assessments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: privacy_incidents privacy_incidents_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.privacy_incidents
    ADD CONSTRAINT privacy_incidents_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: privileged_access_events privileged_access_events_identity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.privileged_access_events
    ADD CONSTRAINT privileged_access_events_identity_id_fkey FOREIGN KEY (identity_id) REFERENCES public.identity_profiles(id);


--
-- Name: query_jobs query_jobs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.query_jobs
    ADD CONSTRAINT query_jobs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: reasoning_steps reasoning_steps_investigation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.reasoning_steps
    ADD CONSTRAINT reasoning_steps_investigation_id_fkey FOREIGN KEY (investigation_id) REFERENCES public.investigations(id);


--
-- Name: reasoning_steps reasoning_steps_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.reasoning_steps
    ADD CONSTRAINT reasoning_steps_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: remediation_actions remediation_actions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.remediation_actions
    ADD CONSTRAINT remediation_actions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: remediation_executions remediation_executions_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.remediation_executions
    ADD CONSTRAINT remediation_executions_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: remediation_executions remediation_executions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.remediation_executions
    ADD CONSTRAINT remediation_executions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: remediation_executions remediation_executions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.remediation_executions
    ADD CONSTRAINT remediation_executions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: remediation_executions remediation_executions_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.remediation_executions
    ADD CONSTRAINT remediation_executions_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES public.remediation_policies(id);


--
-- Name: remediation_integrations remediation_integrations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.remediation_integrations
    ADD CONSTRAINT remediation_integrations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: remediation_playbooks remediation_playbooks_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.remediation_playbooks
    ADD CONSTRAINT remediation_playbooks_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: remediation_playbooks remediation_playbooks_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.remediation_playbooks
    ADD CONSTRAINT remediation_playbooks_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: remediation_policies remediation_policies_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.remediation_policies
    ADD CONSTRAINT remediation_policies_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: remediation_policies remediation_policies_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.remediation_policies
    ADD CONSTRAINT remediation_policies_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: remediation_tickets remediation_tickets_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.remediation_tickets
    ADD CONSTRAINT remediation_tickets_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: runtime_alerts runtime_alerts_cluster_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.runtime_alerts
    ADD CONSTRAINT runtime_alerts_cluster_id_fkey FOREIGN KEY (cluster_id) REFERENCES public.kubernetes_clusters(id);


--
-- Name: runtime_alerts runtime_alerts_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.runtime_alerts
    ADD CONSTRAINT runtime_alerts_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: sbom_components sbom_components_component_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.sbom_components
    ADD CONSTRAINT sbom_components_component_id_fkey FOREIGN KEY (component_id) REFERENCES public.software_components(id);


--
-- Name: sbom_components sbom_components_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.sbom_components
    ADD CONSTRAINT sbom_components_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: sbom_components sbom_components_sbom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.sbom_components
    ADD CONSTRAINT sbom_components_sbom_id_fkey FOREIGN KEY (sbom_id) REFERENCES public.sboms(id);


--
-- Name: sboms sboms_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.sboms
    ADD CONSTRAINT sboms_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: scap_profiles scap_profiles_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.scap_profiles
    ADD CONSTRAINT scap_profiles_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: security_awareness_scores security_awareness_scores_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.security_awareness_scores
    ADD CONSTRAINT security_awareness_scores_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: security_posture_scores security_posture_scores_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.security_posture_scores
    ADD CONSTRAINT security_posture_scores_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: security_posture_scores security_posture_scores_simulation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.security_posture_scores
    ADD CONSTRAINT security_posture_scores_simulation_id_fkey FOREIGN KEY (simulation_id) REFERENCES public.attack_simulations(id);


--
-- Name: shared_artifacts shared_artifacts_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.shared_artifacts
    ADD CONSTRAINT shared_artifacts_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.war_rooms(id);


--
-- Name: siem_data_sources siem_data_sources_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.siem_data_sources
    ADD CONSTRAINT siem_data_sources_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: siem_saved_searches siem_saved_searches_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.siem_saved_searches
    ADD CONSTRAINT siem_saved_searches_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: simulation_tests simulation_tests_simulation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.simulation_tests
    ADD CONSTRAINT simulation_tests_simulation_id_fkey FOREIGN KEY (simulation_id) REFERENCES public.attack_simulations(id);


--
-- Name: simulation_tests simulation_tests_technique_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.simulation_tests
    ADD CONSTRAINT simulation_tests_technique_id_fkey FOREIGN KEY (technique_id) REFERENCES public.attack_techniques(id);


--
-- Name: soc_agents soc_agents_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.soc_agents
    ADD CONSTRAINT soc_agents_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: software_components software_components_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.software_components
    ADD CONSTRAINT software_components_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: software_components software_components_parent_component_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.software_components
    ADD CONSTRAINT software_components_parent_component_id_fkey FOREIGN KEY (parent_component_id) REFERENCES public.software_components(id);


--
-- Name: stig_benchmarks stig_benchmarks_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.stig_benchmarks
    ADD CONSTRAINT stig_benchmarks_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: stig_rules stig_rules_benchmark_id_ref_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.stig_rules
    ADD CONSTRAINT stig_rules_benchmark_id_ref_fkey FOREIGN KEY (benchmark_id_ref) REFERENCES public.stig_benchmarks(id);


--
-- Name: stig_rules stig_rules_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.stig_rules
    ADD CONSTRAINT stig_rules_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: stig_scan_results stig_scan_results_benchmark_id_ref_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.stig_scan_results
    ADD CONSTRAINT stig_scan_results_benchmark_id_ref_fkey FOREIGN KEY (benchmark_id_ref) REFERENCES public.stig_benchmarks(id);


--
-- Name: stig_scan_results stig_scan_results_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.stig_scan_results
    ADD CONSTRAINT stig_scan_results_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: supply_chain_risks supply_chain_risks_component_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.supply_chain_risks
    ADD CONSTRAINT supply_chain_risks_component_id_fkey FOREIGN KEY (component_id) REFERENCES public.software_components(id);


--
-- Name: supply_chain_risks supply_chain_risks_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.supply_chain_risks
    ADD CONSTRAINT supply_chain_risks_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: target_groups target_groups_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.target_groups
    ADD CONSTRAINT target_groups_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: team_members team_members_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: team_members team_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: teams teams_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: threat_actors threat_actors_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_actors
    ADD CONSTRAINT threat_actors_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: threat_campaigns threat_campaigns_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_campaigns
    ADD CONSTRAINT threat_campaigns_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.threat_actors(id);


--
-- Name: threat_campaigns threat_campaigns_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_campaigns
    ADD CONSTRAINT threat_campaigns_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: threat_feeds threat_feeds_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_feeds
    ADD CONSTRAINT threat_feeds_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: threat_indicators threat_indicators_feed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_indicators
    ADD CONSTRAINT threat_indicators_feed_id_fkey FOREIGN KEY (feed_id) REFERENCES public.threat_feeds(id);


--
-- Name: threat_indicators threat_indicators_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_indicators
    ADD CONSTRAINT threat_indicators_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: threat_mitigations threat_mitigations_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_mitigations
    ADD CONSTRAINT threat_mitigations_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: threat_mitigations threat_mitigations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_mitigations
    ADD CONSTRAINT threat_mitigations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: threat_mitigations threat_mitigations_threat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_mitigations
    ADD CONSTRAINT threat_mitigations_threat_id_fkey FOREIGN KEY (threat_id) REFERENCES public.identified_threats(id);


--
-- Name: threat_model_components threat_model_components_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_model_components
    ADD CONSTRAINT threat_model_components_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.threat_models(id);


--
-- Name: threat_model_components threat_model_components_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_model_components
    ADD CONSTRAINT threat_model_components_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: threat_models threat_models_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_models
    ADD CONSTRAINT threat_models_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: threat_models threat_models_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_models
    ADD CONSTRAINT threat_models_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: threat_models threat_models_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_models
    ADD CONSTRAINT threat_models_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: threat_predictions threat_predictions_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_predictions
    ADD CONSTRAINT threat_predictions_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ml_models(id);


--
-- Name: threat_predictions threat_predictions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.threat_predictions
    ADD CONSTRAINT threat_predictions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: ticket_comments ticket_comments_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ticket_comments
    ADD CONSTRAINT ticket_comments_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: ueba_risk_alerts ueba_risk_alerts_entity_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ueba_risk_alerts
    ADD CONSTRAINT ueba_risk_alerts_entity_profile_id_fkey FOREIGN KEY (entity_profile_id) REFERENCES public.entity_profiles(id);


--
-- Name: ueba_risk_alerts ueba_risk_alerts_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.ueba_risk_alerts
    ADD CONSTRAINT ueba_risk_alerts_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: unified_data_models unified_data_models_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.unified_data_models
    ADD CONSTRAINT unified_data_models_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: vendor_assessments vendor_assessments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.vendor_assessments
    ADD CONSTRAINT vendor_assessments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: visual_playbook_executions visual_playbook_executions_parent_execution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.visual_playbook_executions
    ADD CONSTRAINT visual_playbook_executions_parent_execution_id_fkey FOREIGN KEY (parent_execution_id) REFERENCES public.visual_playbook_executions(id);


--
-- Name: visual_playbook_executions visual_playbook_executions_playbook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.visual_playbook_executions
    ADD CONSTRAINT visual_playbook_executions_playbook_id_fkey FOREIGN KEY (playbook_id) REFERENCES public.visual_playbooks(id);


--
-- Name: vulnerability_exceptions vulnerability_exceptions_vulnerability_instance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.vulnerability_exceptions
    ADD CONSTRAINT vulnerability_exceptions_vulnerability_instance_id_fkey FOREIGN KEY (vulnerability_instance_id) REFERENCES public.vulnerability_instances(id);


--
-- Name: vulnerability_instances vulnerability_instances_vulnerability_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.vulnerability_instances
    ADD CONSTRAINT vulnerability_instances_vulnerability_id_fkey FOREIGN KEY (vulnerability_id) REFERENCES public.vulnerabilities(id);


--
-- Name: war_room_messages war_room_messages_parent_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.war_room_messages
    ADD CONSTRAINT war_room_messages_parent_message_id_fkey FOREIGN KEY (parent_message_id) REFERENCES public.war_room_messages(id);


--
-- Name: war_room_messages war_room_messages_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.war_room_messages
    ADD CONSTRAINT war_room_messages_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.war_rooms(id);


--
-- Name: war_rooms war_rooms_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.war_rooms
    ADD CONSTRAINT war_rooms_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.incidents(id);


--
-- Name: webhook_endpoints webhook_endpoints_installed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pysoar
--

ALTER TABLE ONLY public.webhook_endpoints
    ADD CONSTRAINT webhook_endpoints_installed_id_fkey FOREIGN KEY (installed_id) REFERENCES public.installed_integrations(id);


--
-- PostgreSQL database dump complete
--

\unrestrict wv5J7uNvAbqllU1xbqZl7dr9TTlZ2HgOrgquutl7oYbGaKHF6FjpcZ3BOMUFv9v

